package me.shinkuan.akagiandroid;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.concurrent.atomic.AtomicBoolean;

public final class MainActivity extends Activity {
    private static final String DEFAULT_URL = "https://mahjongsoul.game.yo-star.com/";

    private WebView webView;
    private TextView status;
    private TextView advice;
    private TextView detail;
    private LinearLayout overlay;
    private String hookScript;
    private final AtomicBoolean hookReady = new AtomicBoolean(false);
    private MajsoulState state;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        state = new MajsoulState(s -> runOnUiThread(() -> render(s)));
        hookScript = readAsset("ws_hook.js");

        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        buildOverlay(root);
        setContentView(root);

        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setAllowFileAccess(false);
        ws.setAllowContentAccess(false);
        ws.setSupportZoom(false);
        ws.setUseWideViewPort(true);
        ws.setLoadWithOverviewMode(true);
        ws.setJavaScriptCanOpenWindowsAutomatically(true);
        ws.setSupportMultipleWindows(false);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.addJavascriptInterface(new CaptureBridge(), "AkagiCapture");
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(webView, hookScript, Collections.singleton("*"));
        }

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                hookReady.set(false);
                // Fallback for WebView providers without document-start API.
                view.evaluateJavascript(hookScript, null);
            }
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (!hookReady.get()) view.evaluateJavascript(hookScript, null);
            }
        });

        String url = getPreferences(MODE_PRIVATE).getString("game_url", DEFAULT_URL);
        webView.loadUrl(url);
    }

    private void buildOverlay(FrameLayout root) {
        overlay = new LinearLayout(this);
        overlay.setOrientation(LinearLayout.VERTICAL);
        overlay.setPadding(dp(10), dp(8), dp(10), dp(8));
        overlay.setBackgroundColor(0xCC111111);

        status = label(13, Color.LTGRAY);
        advice = label(20, Color.WHITE);
        detail = label(12, 0xFFE0E0E0);
        overlay.addView(status);
        overlay.addView(advice);
        overlay.addView(detail);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        Button reload = button("새로고침");
        reload.setOnClickListener(v -> { state.reset(); webView.reload(); });
        Button url = button("주소");
        url.setOnClickListener(v -> editUrl());
        Button hide = button("접기");
        hide.setOnClickListener(v -> {
            boolean compact = detail.getVisibility() == View.GONE;
            detail.setVisibility(compact ? View.VISIBLE : View.GONE);
            status.setVisibility(compact ? View.VISIBLE : View.GONE);
            hide.setText(compact ? "접기" : "펼치기");
        });
        buttons.addView(reload); buttons.addView(url); buttons.addView(hide);
        overlay.addView(buttons);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(360), ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.leftMargin = dp(8); lp.topMargin = dp(8);
        root.addView(overlay, lp);

        advice.setText("Akagi Android: 연결 대기");
        status.setText("WebSocket hook 준비 중");
        detail.setText("작혼 웹 페이지에서 로그인 후 대국에 들어가세요.");
    }

    private TextView label(int sp, int color) {
        TextView t = new TextView(this);
        t.setTextSize(sp); t.setTextColor(color);
        t.setPadding(0, dp(2), 0, dp(2));
        return t;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text); b.setTextSize(11); b.setAllCaps(false);
        b.setMinHeight(0); b.setMinimumHeight(0);
        return b;
    }

    private void editUrl() {
        final android.widget.EditText e = new android.widget.EditText(this);
        e.setSingleLine(true);
        e.setText(webView.getUrl() == null ? DEFAULT_URL : webView.getUrl());
        new AlertDialog.Builder(this)
                .setTitle("작혼 웹 주소")
                .setView(e)
                .setPositiveButton("열기", (d, w) -> {
                    String u = e.getText().toString().trim();
                    if (!u.startsWith("https://")) u = "https://" + u;
                    getPreferences(MODE_PRIVATE).edit().putString("game_url", u).apply();
                    state.reset(); webView.loadUrl(u);
                })
                .setNegativeButton("취소", null).show();
    }

    private void render(MajsoulState.Snapshot s) {
        status.setText("프레임 " + s.frames + " · 좌석 " + (s.selfSeat < 0 ? "?" : s.selfSeat)
                + " · 남은패 " + (s.leftTiles < 0 ? "?" : s.leftTiles)
                + " · " + s.note);

        if (s.analysis != null) {
            String sh = s.analysis.shanten < 0 ? "화료" : s.analysis.shanten + "샹텐";
            if (s.analysis.discard != null) {
                advice.setText("추천: " + s.analysis.discard + "  ·  " + sh + "  ·  유효 " + s.analysis.ukeire + "장");
            } else {
                advice.setText(sh);
            }
        } else advice.setText("대국 데이터 대기 중");

        StringBuilder d = new StringBuilder();
        d.append("손패: ").append(String.join(" ", s.hand)).append('\n');
        d.append("도라: ").append(String.join(" ", s.doras)).append('\n');
        d.append("마지막: ").append(s.lastAction).append('\n');
        if (s.analysis != null && !s.analysis.improvers.isEmpty())
            d.append("개선패: ").append(String.join(" ", s.analysis.improvers)).append('\n');
        d.append("method: ").append(s.lastMethod);
        detail.setText(d.toString());
    }

    private String readAsset(String name) {
        StringBuilder s = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(getAssets().open(name), StandardCharsets.UTF_8))) {
            String line; while ((line = r.readLine()) != null) s.append(line).append('\n');
        } catch (Exception e) { throw new RuntimeException(e); }
        return s.toString();
    }

    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("AkagiCapture");
            webView.destroy();
        }
        super.onDestroy();
    }

    private final class CaptureBridge {
        @JavascriptInterface public void onHookReady(String page) {
            hookReady.set(true);
            runOnUiThread(() -> status.setText("WebSocket hook 활성화 · 대국 접속 대기"));
        }

        @JavascriptInterface public void onFrame(String direction, String url, String kind, String payload) {
            if (!"binary".equals(kind) || payload == null) return;
            try {
                byte[] bytes = Base64.decode(payload, Base64.DEFAULT);
                state.onBinary("out".equals(direction), bytes);
            } catch (IllegalArgumentException ignored) {}
        }
    }
}
