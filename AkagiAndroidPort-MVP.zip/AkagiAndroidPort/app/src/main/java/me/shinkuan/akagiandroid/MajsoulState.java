package me.shinkuan.akagiandroid;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

final class MajsoulState {
    interface Listener { void onState(Snapshot s); }

    static final class Snapshot {
        final long frames;
        final String lastMethod;
        final String lastAction;
        final int selfSeat;
        final List<String> hand;
        final List<String> doras;
        final int leftTiles;
        final Shanten.Analysis analysis;
        final String note;

        Snapshot(long frames, String lastMethod, String lastAction, int selfSeat,
                 List<String> hand, List<String> doras, int leftTiles,
                 Shanten.Analysis analysis, String note) {
            this.frames = frames;
            this.lastMethod = lastMethod;
            this.lastAction = lastAction;
            this.selfSeat = selfSeat;
            this.hand = hand;
            this.doras = doras;
            this.leftTiles = leftTiles;
            this.analysis = analysis;
            this.note = note;
        }
    }

    private final Map<Integer,String> requestMethods = new HashMap<>();
    private final Map<Integer,Long> requestAccountIds = new HashMap<>();
    private final Listener listener;
    private long frames;
    private String lastMethod = "-";
    private String lastAction = "-";
    private long accountId = -1;
    private int selfSeat = -1;
    private final ArrayList<String> hand = new ArrayList<>();
    private final ArrayList<String> doras = new ArrayList<>();
    private final int[] visible = new int[34];
    private int leftTiles = -1;
    private String note = "대기 중";

    MajsoulState(Listener listener) { this.listener = listener; }

    synchronized void reset() {
        requestMethods.clear();
        requestAccountIds.clear();
        frames = 0;
        lastMethod = lastAction = "-";
        accountId = -1;
        selfSeat = -1;
        hand.clear(); doras.clear(); Arrays.fill(visible, 0);
        leftTiles = -1;
        note = "대기 중";
        publish();
    }

    synchronized void onBinary(boolean outbound, byte[] frame) {
        frames++;
        if (frame == null || frame.length < 2) { publish(); return; }
        int type = frame[0] & 0xff;
        int offset;
        int reqId = -1;
        if (type == 1) offset = 1;
        else if (type == 2 || type == 3) {
            if (frame.length < 4) { publish(); return; }
            reqId = (frame[1] & 0xff) | ((frame[2] & 0xff) << 8);
            offset = 3;
        } else { publish(); return; }

        byte[] wrapper = Arrays.copyOfRange(frame, offset, frame.length);
        List<Proto.Field> wf = Proto.parse(wrapper);
        String method = Proto.firstString(wf, 1, "");
        byte[] payload = Proto.firstBytes(wf, 2);

        if (type == 2) {
            if (!method.isEmpty()) requestMethods.put(reqId, method);
            if (".lq.FastTest.authGame".equals(method) && payload != null) {
                long id = Proto.firstVarint(Proto.parse(payload), 1, -1);
                if (id >= 0) {
                    accountId = id;
                    requestAccountIds.put(reqId, id);
                    note = "대국 인증 요청 감지";
                }
            }
        } else if (type == 3) {
            if (method.isEmpty()) method = requestMethods.remove(reqId);
            if (method == null) method = "";
            if (".lq.FastTest.authGame".equals(method) && payload != null) parseAuthResponse(reqId, payload);
        }

        if (!method.isEmpty()) lastMethod = method;
        if (".lq.ActionPrototype".equals(method) && payload != null) parseActionPrototype(payload);
        publish();
    }

    private void parseAuthResponse(int reqId, byte[] payload) {
        Long mappedId = requestAccountIds.remove(reqId);
        long id = mappedId == null ? accountId : mappedId;
        if (id >= 0) accountId = id;
        List<Proto.Field> fs = Proto.parse(payload);
        List<Long> seats = Proto.repeatedUInt(fs, 3);
        if (accountId >= 0 && !seats.isEmpty()) {
            for (int i = 0; i < seats.size(); i++) {
                if (seats.get(i) == accountId) {
                    selfSeat = i;
                    note = "내 좌석 확인: " + i;
                    return;
                }
            }
        }
    }

    private void parseActionPrototype(byte[] payload) {
        List<Proto.Field> af = Proto.parse(payload);
        String action = Proto.firstString(af, 2, "");
        byte[] data = Proto.firstBytes(af, 3);
        if (action.isEmpty() || data == null) return;
        lastAction = action;
        List<Proto.Field> f = Proto.parse(data);

        switch (action) {
            case "ActionNewRound" -> {
                hand.clear(); doras.clear(); Arrays.fill(visible, 0);
                hand.addAll(cleanTiles(Proto.strings(f, 4)));
                String dora = Proto.firstString(f, 5, "");
                if (!dora.isEmpty()) doras.add(dora);
                for (String d : Proto.strings(f, 14)) if (!doras.contains(d)) doras.add(d);
                leftTiles = (int) Proto.firstVarint(f, 13, -1);
                for (String t : hand) markVisible(t);
                for (String d : doras) markVisible(d);
                note = hand.isEmpty() ? "새 국 감지 (손패 대기)" : "새 국 / 손패 추적 시작";
            }
            case "ActionDealTile" -> {
                int seat = (int) Proto.firstVarint(f, 1, -1);
                String tile = Proto.firstString(f, 2, "");
                leftTiles = (int) Proto.firstVarint(f, 3, leftTiles);
                if (!tile.isEmpty()) {
                    // The server normally reveals tile identity only to the drawing player.
                    if (selfSeat < 0) {
                        selfSeat = seat;
                        note = "내 좌석 추정: " + seat;
                    }
                    if (seat == selfSeat) {
                        hand.add(tile);
                        markVisible(tile);
                    }
                }
                addDoras(Proto.strings(f, 6));
            }
            case "ActionDiscardTile" -> {
                int seat = (int) Proto.firstVarint(f, 1, -1);
                String tile = Proto.firstString(f, 2, "");
                if (!tile.isEmpty()) {
                    if (seat == selfSeat) removeOne(tile);
                    else markVisible(tile);
                }
                addDoras(Proto.strings(f, 8));
            }
            case "ActionChiPengGang" -> {
                int seat = (int) Proto.firstVarint(f, 1, -1);
                List<String> tiles = cleanTiles(Proto.strings(f, 3));
                List<Long> froms = Proto.repeatedUInt(f, 4);
                if (froms.size() == tiles.size()) {
                    for (int i = 0; i < tiles.size(); i++) {
                        long origin = froms.get(i);
                        // Tiles originating in another player's concealed hand become newly visible.
                        // A called discard was already counted by ActionDiscardTile.
                        if (origin == seat && seat != selfSeat) markVisible(tiles.get(i));
                        if (seat == selfSeat && origin == selfSeat) removeOne(tiles.get(i));
                    }
                } else if (seat == selfSeat) {
                    // Fallback: remove at most two matching concealed tiles.
                    int removed = 0;
                    for (String t : tiles) if (removed < 2 && removeOne(t)) removed++;
                } else {
                    for (String t : tiles) markVisible(t);
                }
            }
            case "ActionAnGangAddGang" -> {
                int seat = (int) Proto.firstVarint(f, 1, -1);
                String tile = Proto.firstString(f, 3, "");
                if (seat == selfSeat && !tile.isEmpty()) {
                    int normal = Tile.parse(tile);
                    int count = 0;
                    for (String h : hand) if (Tile.parse(h) == normal) count++;
                    int remove = count >= 4 ? 4 : Math.min(1, count);
                    for (int i = 0; i < remove; i++) removeOne(tile);
                }
                addDoras(Proto.strings(f, 6));
            }
            case "ActionBaBei" -> {
                int seat = (int) Proto.firstVarint(f, 1, -1);
                if (seat == selfSeat) {
                    removeOne("4z");
                }
                addDoras(Proto.strings(f, 6));
            }
            case "ActionHule", "ActionNoTile", "ActionLiuJu" -> note = "국 종료";
            default -> { }
        }
    }

    private List<String> cleanTiles(List<String> xs) {
        ArrayList<String> out = new ArrayList<>();
        for (String s : xs) if (Tile.parse(s) >= 0) out.add(s);
        return out;
    }

    private void addDoras(List<String> ds) {
        for (String d : ds) {
            if (Tile.parse(d) >= 0 && !doras.contains(d)) {
                doras.add(d); markVisible(d);
            }
        }
    }

    private void markVisible(String tile) {
        int t = Tile.parse(tile);
        if (t >= 0 && visible[t] < 4) visible[t]++;
    }

    private boolean removeOne(String tile) {
        int wanted = Tile.parse(tile);
        if (wanted < 0) return false;
        for (int i = 0; i < hand.size(); i++) {
            if (Tile.parse(hand.get(i)) == wanted) {
                hand.remove(i);
                return true;
            }
        }
        return false;
    }

    private void publish() {
        if (listener == null) return;
        List<String> h = new ArrayList<>(hand);
        Shanten.Analysis a = h.isEmpty() ? null : Shanten.analyzeDiscard(h, visible.clone());
        listener.onState(new Snapshot(frames, lastMethod, lastAction, selfSeat,
                h, new ArrayList<>(new LinkedHashSet<>(doras)), leftTiles, a, note));
    }
}
