package me.shinkuan.akagiandroid;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

final class Shanten {
    private Shanten() {}

    static int calculate(int[] counts) {
        int std = standard(counts.clone());
        int chiitoi = chiitoi(counts);
        int kokushi = kokushi(counts);
        return Math.min(std, Math.min(chiitoi, kokushi));
    }

    private static int chiitoi(int[] c) {
        int pairs = 0, unique = 0;
        for (int n : c) {
            if (n > 0) unique++;
            if (n >= 2) pairs++;
        }
        return 6 - pairs + Math.max(0, 7 - unique);
    }

    private static int kokushi(int[] c) {
        int[] yaochu = {0,8,9,17,18,26,27,28,29,30,31,32,33};
        int unique = 0;
        boolean pair = false;
        for (int i : yaochu) {
            if (c[i] > 0) unique++;
            if (c[i] > 1) pair = true;
        }
        return 13 - unique - (pair ? 1 : 0);
    }

    private static int standard(int[] c) {
        Best best = new Best();
        dfs(c, 0, 0, 0, 0, best);
        return best.value;
    }

    private static final class Best { int value = 8; }

    private static void dfs(int[] c, int idx, int meld, int taatsu, int pair, Best best) {
        while (idx < 34 && c[idx] == 0) idx++;
        if (idx >= 34) {
            int t = Math.min(taatsu, 4 - meld);
            int sh = 8 - meld * 2 - t - pair;
            if (sh < best.value) best.value = sh;
            return;
        }

        // Isolated tile skip.
        c[idx]--;
        dfs(c, idx, meld, taatsu, pair, best);
        c[idx]++;

        // Pair / head.
        if (c[idx] >= 2) {
            c[idx] -= 2;
            if (pair == 0) dfs(c, idx, meld, taatsu, 1, best);
            dfs(c, idx, meld, taatsu + 1, pair, best);
            c[idx] += 2;
        }

        // Triplet.
        if (c[idx] >= 3) {
            c[idx] -= 3;
            dfs(c, idx, meld + 1, taatsu, pair, best);
            c[idx] += 3;
        }

        if (idx < 27) {
            int pos = idx % 9;
            // Sequence.
            if (pos <= 6 && c[idx + 1] > 0 && c[idx + 2] > 0) {
                c[idx]--; c[idx + 1]--; c[idx + 2]--;
                dfs(c, idx, meld + 1, taatsu, pair, best);
                c[idx]++; c[idx + 1]++; c[idx + 2]++;
            }
            // Ryanmen/penchan taatsu.
            if (pos <= 7 && c[idx + 1] > 0) {
                c[idx]--; c[idx + 1]--;
                dfs(c, idx, meld, taatsu + 1, pair, best);
                c[idx]++; c[idx + 1]++;
            }
            // Kanchan taatsu.
            if (pos <= 6 && c[idx + 2] > 0) {
                c[idx]--; c[idx + 2]--;
                dfs(c, idx, meld, taatsu + 1, pair, best);
                c[idx]++; c[idx + 2]++;
            }
        }
    }

    static Analysis analyzeDiscard(List<String> hand, int[] visible) {
        int[] base = Tile.counts(hand);
        int current = calculate(base);
        if (hand.size() % 3 != 2) {
            return new Analysis(current, null, 0, List.of(), new LinkedHashMap<>());
        }

        String bestDiscard = null;
        int bestShanten = Integer.MAX_VALUE;
        int bestUkeire = -1;
        List<String> bestImprovers = List.of();
        LinkedHashMap<String,Integer> table = new LinkedHashMap<>();

        for (int d = 0; d < 34; d++) {
            if (base[d] == 0) continue;
            int[] after = base.clone();
            after[d]--;
            int sh = calculate(after);
            int ukeire = 0;
            ArrayList<String> improvers = new ArrayList<>();
            for (int t = 0; t < 34; t++) {
                if (after[t] >= 4) continue;
                after[t]++;
                int next = calculate(after);
                after[t]--;
                if (next < sh) {
                    int used = visible == null ? base[t] : Math.max(base[t], visible[t]);
                    int left = Math.max(0, 4 - used);
                    if (left > 0) {
                        ukeire += left;
                        improvers.add(Tile.name(t));
                    }
                }
            }
            String dn = Tile.name(d);
            table.put(dn, ukeire);
            if (sh < bestShanten || (sh == bestShanten && ukeire > bestUkeire)) {
                bestShanten = sh;
                bestUkeire = ukeire;
                bestDiscard = dn;
                bestImprovers = improvers;
            }
        }
        return new Analysis(bestShanten == Integer.MAX_VALUE ? current : bestShanten,
                bestDiscard, Math.max(0, bestUkeire), bestImprovers, table);
    }

    static final class Analysis {
        final int shanten;
        final String discard;
        final int ukeire;
        final List<String> improvers;
        final Map<String,Integer> candidates;

        Analysis(int shanten, String discard, int ukeire, List<String> improvers, Map<String,Integer> candidates) {
            this.shanten = shanten;
            this.discard = discard;
            this.ukeire = ukeire;
            this.improvers = improvers;
            this.candidates = candidates;
        }
    }
}
