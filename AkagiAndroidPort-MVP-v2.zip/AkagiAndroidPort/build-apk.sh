#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ ! -f gradle/wrapper/gradle-wrapper.jar ]]; then
  if command -v gradle >/dev/null 2>&1; then
    gradle wrapper --gradle-version 9.6.0
  else
    echo "Gradle wrapper JAR가 없습니다. Android Studio에서 프로젝트를 열어 Sync/Build 하거나 Gradle 9.6을 설치한 뒤 다시 실행하세요." >&2
    exit 2
  fi
fi
./gradlew assembleDebug
printf '\nAPK: app/build/outputs/apk/debug/app-debug.apk\n'
