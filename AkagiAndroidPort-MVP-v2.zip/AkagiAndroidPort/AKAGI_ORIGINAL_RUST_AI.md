# Akagi original Rust AI (Android bridge)

This Android port uses Akagi v3.7.2's original `native_bot` crate as a pinned Cargo git dependency.
The Android app maps Mahjong Soul protobuf actions to mjai JSON events and feeds those events to
`native_bot::engine::Engine` over JNI. Observation encoding, legal-action enumeration, action codec,
Candle model inference, and bundled model weights therefore come from the upstream Akagi v3.7.2
Rust implementation.

Auto-play / automatic clicking is intentionally not connected. The JNI bridge returns recommendations only.

Android build target: arm64-v8a.
