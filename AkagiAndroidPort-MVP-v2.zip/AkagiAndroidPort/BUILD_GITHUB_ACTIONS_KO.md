# GitHub Actions로 APK 만들기

로컬 PC에 Android Studio가 없어도 이 프로젝트를 GitHub 저장소에 올리면 `.github/workflows/android-build.yml`이 APK를 빌드합니다.

1. 이 폴더 전체를 새 GitHub 저장소에 업로드합니다.
2. 저장소의 **Actions → Build Android APK → Run workflow**를 누릅니다.
3. 완료 후 실행 결과의 **Artifacts → AkagiAndroid-MVP-debug**를 받습니다.
4. 압축 안의 `app-debug.apk`를 Android 기기에 설치합니다.

워크플로는 Ubuntu runner에서 JDK 17, Gradle 9.6, Android SDK 37을 준비하고 `:app:assembleDebug`를 실행합니다.
