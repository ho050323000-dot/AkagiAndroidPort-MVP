# Android Full Helper 0.4 변경사항

- Akagi 원본 3p/4p native_bot 가중치 탑재
- 원본 CNN 순수 Java 추론
- 원본 AI 타패 TOP3 / 행동 추천
- 화료율 / 상대 텐파이율
- 원본 통계 위험도 엔진 이식
- 공격/수비 혼합 추천
- 대기패 / 유효패 / 개선패
- 한글 패 이름
- 내 패 위 `▲ 버림` 추천 표시
- History / Inspector 강화
- live ActionPrototype XOR + GameRestore 복구
- 고정 debug signing key

AutoPlay와 자동 클릭은 포함하지 않습니다.
