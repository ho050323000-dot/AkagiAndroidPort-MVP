use jni::objects::{JClass, JString};
use jni::sys::{jboolean, jint, jlong, jstring, JNI_FALSE, JNI_TRUE};
use jni::JNIEnv;
use native_bot::engine::{BotAction, Decision, Engine};
use serde_json::{json, Value};
use std::panic::{catch_unwind, AssertUnwindSafe};

fn engine_mut<'a>(handle: jlong) -> Option<&'a mut Engine> {
    if handle == 0 { return None; }
    unsafe { (handle as *mut Engine).as_mut() }
}

fn tile_or_null(v: &str) -> Value {
    if v.is_empty() { Value::Null } else { Value::String(v.to_string()) }
}

fn action_json(action: &BotAction, probability: Option<f32>) -> Value {
    let mut v = match action {
        BotAction::Dahai { pai, tsumogiri } => json!({"type":"dahai","pai":pai,"tsumogiri":tsumogiri}),
        BotAction::Reach { pai } => json!({"type":"reach","pai":tile_or_null(pai)}),
        BotAction::Pon { target, pai, consumed } => json!({"type":"pon","target":target,"pai":pai,"consumed":consumed}),
        BotAction::Chi { target, pai, consumed } => json!({"type":"chi","target":target,"pai":pai,"consumed":consumed}),
        BotAction::Daiminkan { target, pai, consumed } => json!({"type":"daiminkan","target":target,"pai":pai,"consumed":consumed}),
        BotAction::Ankan { consumed } => json!({"type":"ankan","consumed":consumed}),
        BotAction::Kakan { pai, consumed } => json!({"type":"kakan","pai":pai,"consumed":consumed}),
        BotAction::Hora { target } => json!({"type":"hora","target":target}),
        BotAction::Kyushu => json!({"type":"kyushu"}),
        BotAction::Kita => json!({"type":"kita"}),
        BotAction::Pass => json!({"type":"pass"}),
    };
    if let (Some(p), Some(obj)) = (probability, v.as_object_mut()) {
        obj.insert("probability".into(), json!(p));
    }
    v
}

fn decision_json(d: Decision) -> String {
    let candidates: Vec<Value> = d.candidates.iter().map(|(a,p)| action_json(a, Some(*p))).collect();
    json!({
        "action": action_json(&d.action, None),
        "candidates": candidates,
        "forced": d.forced
    }).to_string()
}

fn to_jstring(mut env: JNIEnv, text: String) -> jstring {
    match env.new_string(text) {
        Ok(s) => s.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}

#[no_mangle]
pub extern "system" fn Java_me_shinkuan_akagiandroid_AkagiRustNativeBot_nativeCreate(
    _env: JNIEnv,
    _class: JClass,
    players: jint,
    seat: jint,
) -> jlong {
    catch_unwind(AssertUnwindSafe(|| {
        let p: u8 = if players == 3 { 3 } else { 4 };
        let s = seat.clamp(0, (p - 1) as i32) as u8;
        match native_bot::defaults::engine(p, s) {
            Ok(engine) => Box::into_raw(Box::new(engine)) as jlong,
            Err(_) => 0,
        }
    })).unwrap_or(0)
}

#[no_mangle]
pub extern "system" fn Java_me_shinkuan_akagiandroid_AkagiRustNativeBot_nativeDestroy(
    _env: JNIEnv,
    _class: JClass,
    handle: jlong,
) {
    if handle == 0 { return; }
    let _ = catch_unwind(AssertUnwindSafe(|| unsafe {
        drop(Box::from_raw(handle as *mut Engine));
    }));
}

#[no_mangle]
pub extern "system" fn Java_me_shinkuan_akagiandroid_AkagiRustNativeBot_nativeReset(
    _env: JNIEnv,
    _class: JClass,
    handle: jlong,
) {
    let _ = catch_unwind(AssertUnwindSafe(|| {
        if let Some(engine) = engine_mut(handle) { engine.reset(); }
    }));
}

#[no_mangle]
pub extern "system" fn Java_me_shinkuan_akagiandroid_AkagiRustNativeBot_nativeSetSeat(
    _env: JNIEnv,
    _class: JClass,
    handle: jlong,
    seat: jint,
) {
    let _ = catch_unwind(AssertUnwindSafe(|| {
        if let Some(engine) = engine_mut(handle) {
            let max = engine.num_players().saturating_sub(1) as i32;
            engine.set_seat(seat.clamp(0, max) as u8);
        }
    }));
}

#[no_mangle]
pub extern "system" fn Java_me_shinkuan_akagiandroid_AkagiRustNativeBot_nativeFeed(
    mut env: JNIEnv,
    _class: JClass,
    handle: jlong,
    line: JString,
) -> jboolean {
    catch_unwind(AssertUnwindSafe(|| {
        let Some(engine) = engine_mut(handle) else { return JNI_FALSE; };
        let line: String = match env.get_string(&line) {
            Ok(s) => s.into(),
            Err(_) => return JNI_FALSE,
        };
        if engine.feed_line(&line) { JNI_TRUE } else { JNI_FALSE }
    })).unwrap_or(JNI_FALSE)
}

#[no_mangle]
pub extern "system" fn Java_me_shinkuan_akagiandroid_AkagiRustNativeBot_nativeDecide(
    env: JNIEnv,
    _class: JClass,
    handle: jlong,
) -> jstring {
    let out = catch_unwind(AssertUnwindSafe(|| {
        let Some(engine) = engine_mut(handle) else { return "".to_string(); };
        match engine.decide() {
            Ok(Some(d)) => decision_json(d),
            Ok(None) => "".to_string(),
            Err(e) => json!({"error":e.to_string()}).to_string(),
        }
    })).unwrap_or_else(|_| "{\"error\":\"native panic\"}".to_string());
    to_jstring(env, out)
}
