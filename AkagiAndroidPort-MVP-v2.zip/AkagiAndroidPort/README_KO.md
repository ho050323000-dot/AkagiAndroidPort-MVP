# Akagi Android Full Helper 0.4

Akagi V3 3.7.2의 **모바일 실시간 분석/추천 기능**을 Android WebView 구조로 옮긴 빌드입니다.
Windows 실행 파일을 APK로 변환한 것이 아니라, Android에서 Mahjong Soul 웹 클라이언트의 WebSocket/Liqi 이벤트를 읽고 모바일용 분석 엔진을 구동합니다.

## 포함된 헬퍼 기능

- 4인 / 3인 Mahjong Soul 대국 추적
- `authGame` 좌석 확인, `ActionPrototype` 라이브 XOR 해제
- `syncGame` / `enterGame`의 `GameRestore` 중간 재접속 복구
- 손패 / 도라표시패 / 남은 패 / 점수 / 후로 / 리치 / 버림패 추적
- 일반형 + 치또이 + 국사무쌍 샹텐
- 대기패 / 유효패 / 개선패
- Akagi 3.7.2 실행 파일에 내장된 **원본 native_bot 3인/4인 safetensors 가중치**
- Akagi V3와 동일한 CNN 구조(Conv1d + residual blocks + FC/head)를 Java로 추론
- 원본 AI 타패 TOP3 + 확률
- 작혼 `OptionalOperationList`를 이용한 리치 / 치 / 퐁 / 깡 / 화료 / 패스 / 북빼기 추천 표시
- Akagi V3 통계표 기반 화료율
- Akagi V3 통계표 기반 상대 텐파이율
- Akagi V3 위험도 코어 기반 방총 위험 분석
  - 현물 / 스지
  - 노찬스 / 더블 노찬스
  - 도라 위험 보정
  - 상대 텐파이율 가중
  - 예상 론 타점 보정
- 원본 AI와 위험도를 섞은 공격/수비 추천
- 내 패 오버레이 + 추천 버릴 패 `▲ 버림` 표시
- 패 이름 한글 표시 (`1만`, `5통`, `동`, `백`, `발`, `중` 등)
- 세션 통계와 완료 대국 기록
- Protocol / State Inspector
- 인증 팝업을 별도 WebView로 열고 게임 화면으로 복귀

## 의도적으로 제외

사용자 요청에 따라 아래 기능은 넣지 않았습니다.

- AutoPlay
- 자동 클릭 / 자동 타패 / 자동 치퐁깡 / 자동 화료
- 클릭 우회, 탐지 회피, 제재 회피 기능

PC용 프록시/Chromium 프로세스 제어, 데스크톱 창 관리, 업데이터 같은 **데스크톱 런타임 기능**도 Android 구조에는 필요하지 않아 포함하지 않습니다.

## 원본 AI에 대해

`native_bot` 원본은 Rust/Candle로 작성되어 있지만 Android판은 NDK 의존성을 줄이기 위해 같은 safetensors 가중치와 같은 네트워크 구조를 순수 Java로 계산합니다. 모델 forward 결과는 기준 계산과 교차검증했습니다.

AI는 추천만 표시하며 게임 입력을 보내지 않습니다.

## 빌드

GitHub Actions에서 저장소 루트의 `AkagiAndroidPort-MVP-v2.zip`을 풀어 APK를 만듭니다.
현재 workflow가 SDK 36으로 패치해서 빌드하므로 원본 프로젝트의 compile/target 37 설정은 그대로 두어도 됩니다.

APK 결과:

```text
app/build/outputs/apk/debug/app-debug.apk
```

0.4부터 고정 디버그 서명키를 프로젝트에 포함해 이후 0.4 계열 빌드는 덮어설치가 가능합니다. 이전 임시 빌드와 서명이 다를 수 있으므로 **0.4를 처음 설치할 때만 기존 Akagi Android를 삭제한 뒤 설치**해야 할 수 있습니다.

## 사용

1. 앱 실행 후 Mahjong Soul 로그인.
2. 대국 진입.
3. 상단 HUD에서 손패/샹텐/화료율/상대 텐파이율/위험도를 확인.
4. `원본AI TOP3`에서 타패 정책 확률 확인.
5. 치/퐁/리치/화료 등 선택지가 생기면 `행동AI`에 가능한 행동만 표시됨.
6. 화면 아래 내 패 가이드에서 `▲ 버림`이 붙은 패를 확인.
7. `기록` 버튼으로 완료 국/대국 기록 확인.
8. `인스펙터` 버튼으로 좌석·점수·국·후로·리치·마지막 프로토콜 이벤트 확인.

## 주의

게임 운영사의 이용약관이나 공정 플레이 정책에서 실시간 보조 도구 사용을 제한할 수 있습니다. 계정 제재 위험을 확인하고 사용하세요.

WebSocket 프레임은 메모리에서 게임 상태 해석에 사용하며 raw 로그인/세션 프레임을 파일로 저장하지 않습니다.
