# Akagi Android Port MVP

이 프로젝트는 Akagi 3.7.2의 Android 포팅을 위한 **실행 가능한 1차 모바일 구현**입니다.
Windows용 `akagi.exe`를 APK로 변환한 것이 아니라, Android WebView 안에서 Mahjong Soul 웹 클라이언트를 실행하고 WebSocket을 문서 시작 시점에 관찰하는 방식으로 PC의 Chromium/CDP 캡처를 대체합니다.

## 현재 구현됨

- Android WebView에서 Mahjong Soul 웹 버전 실행
- WebSocket send/message를 원본 동작을 변경하지 않고 복제(capture)
- Liqi 프레임 타입 0x01 Notify / 0x02 Request / 0x03 Response 해석
- Request/Response 16-bit little-endian ID 연결
- `.lq.FastTest.authGame`에서 계정 ID/seat_list로 내 좌석 탐지
- `.lq.ActionPrototype` 해석
- `ActionNewRound`, `ActionDealTile`, `ActionDiscardTile`, `ActionChiPengGang`, `ActionAnGangAddGang`, `ActionBaBei`의 핵심 공개 필드 추적
- 손패 / 도라 / 남은 패 수 표시
- 일반형 + 치또이 + 국사무쌍 샹텐 계산
- 14장 손패에서 샹텐 우선, 유효패 수 차선 기준 추천 버림패 표시
- Android 화면 상단 오버레이

## 아직 Akagi 데스크톱판과 다른 부분

- Akagi 3.7.2의 `native_bot` Candle 신경망은 아직 이 프로젝트에 링크하지 않았습니다. 현재 추천은 샹텐/유효패 기반입니다.
- Akagi의 방총 위험도/공수 판단, cloud inference, History, Inspector UI는 미포팅입니다.
- AutoPlay(자동 클릭)는 구현하지 않았습니다.
- Mahjong Soul 프로토콜이 바뀌면 action field mapping 업데이트가 필요할 수 있습니다.

## 빌드

필요 환경:

- Android Studio (2026.2.x 권장)
- Android SDK 37
- JDK 17+
- 인터넷 연결(Gradle/AndroidX dependency 최초 다운로드)

Android Studio에서 이 폴더를 열고 `app`을 실행하는 것이 가장 간단합니다. 시스템에 Gradle이 설치되어 있다면:

```bash
./build-apk.sh
```

스크립트는 필요한 Gradle wrapper를 만든 뒤 debug APK를 빌드합니다.

APK 예상 위치:

```text
app/build/outputs/apk/debug/app-debug.apk
```

로컬에 Android Studio가 없으면 `BUILD_GITHUB_ACTIONS_KO.md`의 GitHub Actions 빌드 방법을 사용할 수 있습니다.

> 이 작업 환경에는 Android SDK/Gradle 배포본이 설치되어 있지 않아 여기서는 APK 바이너리까지 생성하지 못했습니다.

## 사용

1. 앱 실행.
2. 기본으로 `https://mahjongsoul.game.yo-star.com/`를 엽니다.
3. 다른 지역/호스트면 오버레이의 **주소** 버튼으로 변경합니다.
4. 로그인 후 대국에 들어갑니다.
5. `프레임` 숫자가 증가하고 `ActionNewRound` 등이 표시되면 캡처가 정상입니다.
6. 손패가 14장이 되는 턴에 `추천: 5p · 1샹텐 · 유효 20장` 같은 형태가 표시됩니다.

## Akagi 3.7.2 native_bot 연결 지점

다음 단계는 공식 Akagi 소스의 `native_bot` crate와 `bridge::majsoul`을 Android용 Rust `cdylib`로 분리해 JNI로 연결하는 것입니다. 이 프로젝트에서는 `MajsoulState.onBinary()`가 그 경계입니다. 현재 Java parser 대신 Rust JNI 함수로 raw frame을 전달하면 기존 bridge와 native bot을 재사용할 수 있습니다.

Android에서는 Akagi 데스크톱 구조 중 다음을 제외해야 합니다.

- `hudsucker` MITM/CA
- `chromiumoxide` CDP
- 외부 Chromium process lifecycle
- Python/uv subprocess bot runtime
- desktop window-state/updater integrations

재사용 대상은 다음입니다.

- `src/bridge/majsoul`
- `src/schema/mjai`
- `src/game_state`
- `src/analysis`
- `native_bot`
- event buses 중 Tauri/window 의존성이 없는 부분

## 주의

게임 운영사의 이용약관에 따라 실시간 보조 도구 사용이 제한될 수 있습니다. 계정 제재 가능성을 확인하고 사용하세요.


## 개인정보/로그인 프레임

WebSocket hook은 원본 프레임을 수정하지 않지만 로그인/세션 관련 프레임도 메모리에서 관찰할 수 있습니다. 이 MVP는 raw 프레임을 파일이나 로그로 저장하지 않으며, 필요한 게임 action 필드만 즉시 해석합니다.

## Android+ 0.2 추가

`MOBILE_PLUS_NOTES_KO.md`를 참고하세요. 인증 팝업 복귀, 리치/위험도, 공수 추천, TOP3, 대기패, 세션 통계가 추가되었습니다.
