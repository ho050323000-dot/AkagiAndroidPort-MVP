plugins {
    id("com.android.application")
}

android {
    namespace = "me.shinkuan.akagiandroid"
    compileSdk = 37

    defaultConfig {
        applicationId = "me.shinkuan.akagiandroid"
        minSdk = 24
        targetSdk = 37
        versionCode = 5
        versionName = "0.4.1-stability-fix"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    signingConfigs {
        create("akagiDebug") {
            storeFile = file("akagi-debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("akagiDebug")
        }
        release {
            isMinifyEnabled = false
        }
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.18.0")
}
