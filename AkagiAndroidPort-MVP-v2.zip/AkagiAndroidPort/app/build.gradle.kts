plugins {
    id("com.android.application")
}

android {
    namespace = "me.shinkuan.akagiandroid"
    compileSdk = 37

    defaultConfig {
        applicationId = "me.shinkuan.akagiandroid"
        minSdk = 24
        targetSdk = 37
        versionCode = 2
        versionName = "0.2.0-mobile-helper"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.18.0")
}
