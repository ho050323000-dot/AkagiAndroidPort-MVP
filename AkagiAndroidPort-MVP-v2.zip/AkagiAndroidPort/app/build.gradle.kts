plugins {
    id("com.android.application")
}

android {
    namespace = "me.shinkuan.akagiandroid"
    compileSdk = 37

    defaultConfig {
        applicationId = "me.shinkuan.akagiandroid"
        minSdk = 24
        targetSdk = 37
        versionCode = 7
        versionName = "0.5.0-akagi-rust-native"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    signingConfigs {
        create("akagiDebug") {
            storeFile = file("akagi-debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("akagiDebug")
        }
        release {
            isMinifyEnabled = false
        }
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.18.0")
}


val rustBuildScript = """
    set -euo pipefail
    export PATH="${'$'}HOME/.cargo/bin:${'$'}PATH"
    if ! command -v cargo >/dev/null 2>&1; then
      curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --profile minimal
      . "${'$'}HOME/.cargo/env"
    fi
    rustup target add aarch64-linux-android
    if ! command -v cargo-ndk >/dev/null 2>&1; then
      cargo install cargo-ndk --locked
    fi
    if [ -z "${'$'}{ANDROID_NDK_HOME:-}" ]; then
      SDK="${'$'}{ANDROID_SDK_ROOT:-${'$'}{ANDROID_HOME:-/usr/local/lib/android/sdk}}"
      NDK="${'$'}(ls -d "${'$'}SDK"/ndk/* 2>/dev/null | sort -V | tail -n1 || true)"
      if [ -z "${'$'}NDK" ]; then
        yes | "${'$'}SDK/cmdline-tools/latest/bin/sdkmanager" --licenses >/dev/null || true
        "${'$'}SDK/cmdline-tools/latest/bin/sdkmanager" "ndk;27.2.12479018"
        NDK="${'$'}SDK/ndk/27.2.12479018"
      fi
      export ANDROID_NDK_HOME="${'$'}NDK"
      export ANDROID_NDK_ROOT="${'$'}NDK"
    fi
    mkdir -p ../../app/src/main/jniLibs
    cargo ndk -t arm64-v8a -o ../../app/src/main/jniLibs build --release
""".trimIndent()

val buildAkagiRust by tasks.registering(Exec::class) {
    group = "build"
    description = "Build Akagi v3.7.2 original Rust native_bot JNI bridge for Android arm64-v8a"
    workingDir(rootProject.file("rust/akagi_native_bridge"))
    commandLine("bash", "-lc", rustBuildScript)
}

tasks.named("preBuild") {
    dependsOn(buildAkagiRust)
}
