package me.shinkuan.akagiandroid;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** JNI wrapper around Akagi v3.7.2's original Rust native_bot Engine. */
final class AkagiRustNativeBot implements AutoCloseable {
    static final class Candidate {
        final String type;
        final String tile;
        final String label;
        final double probability;

        Candidate(String type, String tile, String label, double probability) {
            this.type = type;
            this.tile = tile;
            this.label = label;
            this.probability = probability;
        }
    }

    static final class Decision {
        final String type;
        final String tile;
        final String label;
        final boolean forced;
        final List<Candidate> candidates;

        Decision(String type, String tile, String label, boolean forced, List<Candidate> candidates) {
            this.type = type;
            this.tile = tile;
            this.label = label;
            this.forced = forced;
            this.candidates = candidates;
        }

        boolean isDiscard() { return "dahai".equals(type); }
        boolean isCallLike() {
            return "chi".equals(type) || "pon".equals(type) || "daiminkan".equals(type)
                    || "ankan".equals(type) || "kakan".equals(type) || "hora".equals(type)
                    || "pass".equals(type) || "kita".equals(type) || "kyushu".equals(type)
                    || "reach".equals(type);
        }
    }

    private static final boolean AVAILABLE;
    static {
        boolean ok;
        try {
            System.loadLibrary("akagi_native_bridge");
            ok = true;
        } catch (Throwable t) {
            android.util.Log.e("AkagiRustBot", "native library unavailable", t);
            ok = false;
        }
        AVAILABLE = ok;
    }

    static boolean isAvailable() { return AVAILABLE; }

    private long handle;
    private final int players;

    AkagiRustNativeBot(int players, int seat) {
        this.players = players == 3 ? 3 : 4;
        if (AVAILABLE) handle = nativeCreate(this.players, seat);
    }

    synchronized boolean ready() { return handle != 0; }

    synchronized boolean feed(String jsonLine) {
        if (handle == 0 || jsonLine == null || jsonLine.isEmpty()) return false;
        try { return nativeFeed(handle, jsonLine); }
        catch (Throwable t) {
            android.util.Log.e("AkagiRustBot", "feed failed: " + jsonLine, t);
            return false;
        }
    }

    synchronized void setSeat(int seat) {
        if (handle != 0) nativeSetSeat(handle, seat);
    }

    synchronized void reset() {
        if (handle != 0) nativeReset(handle);
    }

    synchronized Decision decide() {
        if (handle == 0) return null;
        try {
            String raw = nativeDecide(handle);
            if (raw == null || raw.isEmpty()) return null;
            JSONObject root = new JSONObject(raw);
            if (root.has("error")) {
                android.util.Log.w("AkagiRustBot", "native decide: " + root.optString("error"));
                return null;
            }
            JSONObject action = root.optJSONObject("action");
            if (action == null) return null;
            String type = action.optString("type", "");
            String tile = mjaiToMs(action.optString("pai", ""));
            ArrayList<Candidate> candidates = new ArrayList<>();
            JSONArray arr = root.optJSONArray("candidates");
            if (arr != null) {
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject c = arr.optJSONObject(i);
                    if (c == null) continue;
                    String ct = c.optString("type", "");
                    String cpai = mjaiToMs(c.optString("pai", ""));
                    double p = c.optDouble("probability", 0.0);
                    candidates.add(new Candidate(ct, cpai, labelFor(c), p));
                }
            }
            return new Decision(type, tile, labelFor(action), root.optBoolean("forced", false), Collections.unmodifiableList(candidates));
        } catch (Throwable t) {
            android.util.Log.e("AkagiRustBot", "decision parse failed", t);
            return null;
        }
    }

    private static String labelFor(JSONObject a) {
        String type = a.optString("type", "");
        String pai = mjaiToMs(a.optString("pai", ""));
        return switch (type) {
            case "dahai" -> "타패 " + pai;
            case "reach" -> pai.isEmpty() ? "리치" : "리치 후 " + pai;
            case "chi" -> "치";
            case "pon" -> "퐁";
            case "daiminkan" -> "대명깡";
            case "ankan" -> "암깡";
            case "kakan" -> "가깡";
            case "hora" -> "론/쯔모";
            case "kyushu" -> "구종구패";
            case "kita" -> "북빼기";
            case "pass" -> "패스";
            default -> type;
        };
    }

    static String msToMjai(String tile) {
        if (tile == null || tile.isEmpty()) return "?";
        if (tile.length() == 2) {
            char n = tile.charAt(0), suit = tile.charAt(1);
            if (suit == 'm' || suit == 'p' || suit == 's') {
                if (n == '0') return "5" + suit + "r";
                return "" + n + suit;
            }
            if (suit == 'z') {
                return switch (n) {
                    case '1' -> "E";
                    case '2' -> "S";
                    case '3' -> "W";
                    case '4' -> "N";
                    case '5' -> "P";
                    case '6' -> "F";
                    case '7' -> "C";
                    default -> "?";
                };
            }
        }
        return tile;
    }

    static String mjaiToMs(String tile) {
        if (tile == null || tile.isEmpty() || "?".equals(tile)) return "";
        return switch (tile) {
            case "E" -> "1z";
            case "S" -> "2z";
            case "W" -> "3z";
            case "N" -> "4z";
            case "P" -> "5z";
            case "F" -> "6z";
            case "C" -> "7z";
            case "5mr" -> "0m";
            case "5pr" -> "0p";
            case "5sr" -> "0s";
            default -> tile;
        };
    }

    @Override public synchronized void close() {
        if (handle != 0) {
            nativeDestroy(handle);
            handle = 0;
        }
    }

    private static native long nativeCreate(int players, int seat);
    private static native void nativeDestroy(long handle);
    private static native void nativeReset(long handle);
    private static native void nativeSetSeat(long handle, int seat);
    private static native boolean nativeFeed(long handle, String line);
    private static native String nativeDecide(long handle);
}
