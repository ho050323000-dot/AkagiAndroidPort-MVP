package me.shinkuan.akagiandroid;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

final class DefenseAnalyzer {
    private DefenseAnalyzer() {}

    static final class Opponent {
        final int seat;
        final boolean riichi;
        final double tenpaiRate;
        final List<String> river;

        Opponent(int seat, boolean riichi, List<String> river) {
            this(seat, riichi, riichi ? 100.0 : 0.0, river);
        }
        Opponent(int seat, boolean riichi, double tenpaiRate, List<String> river) {
            this.seat = seat;
            this.riichi = riichi;
            this.tenpaiRate = Math.max(0.0, Math.min(100.0, tenpaiRate));
            this.river = river;
        }
    }

    static final class Pick {
        final String discard;
        final int risk;
        final String mode;
        final List<String> top;

        Pick(String discard, int risk, String mode, List<String> top) {
            this.discard = discard;
            this.risk = risk;
            this.mode = mode;
            this.top = top;
        }
    }

    static Pick choose(Shanten.Analysis a, int[] visible, List<Opponent> opponents) {
        if (a == null || a.candidateList.isEmpty()) return new Pick(null, 0, "대기", List.of());
        boolean threat = false;
        for (Opponent o : opponents) if (o.riichi || o.tenpaiRate >= 55.0) { threat = true; break; }

        ArrayList<Scored> scored = new ArrayList<>();
        for (Shanten.Candidate c : a.candidateList) {
            int risk = risk(c.discard, visible, opponents);
            double offense = -c.shanten * 1000.0 + c.ukeire * 12.0;
            double penalty;
            if (!threat) penalty = risk * 0.15;
            else if (c.shanten <= 0) penalty = risk * 1.2;
            else if (c.shanten == 1) penalty = risk * 3.0;
            else penalty = risk * 6.0;
            if (risk <= 5) offense += 90;
            scored.add(new Scored(c, risk, offense - penalty));
        }
        scored.sort(Comparator.comparingDouble((Scored s) -> s.score).reversed());
        Scored best = scored.get(0);
        String mode = !threat ? "공격" : (best.c.shanten >= 2 || best.risk >= 55 ? "수비" : "공수");
        ArrayList<String> top = new ArrayList<>();
        for (int i = 0; i < Math.min(3, scored.size()); i++) {
            Scored s = scored.get(i);
            top.add(s.c.discard + "(" + s.c.shanten + "샹텐/유효" + s.c.ukeire + "/위험" + s.risk + ")");
        }
        return new Pick(best.c.discard, best.risk, mode, top);
    }


    /** Choose using Akagi V3's mixed statistical risk vector. */
    static Pick chooseWithMixed(Shanten.Analysis a, double[] mixed) {
        if (a == null || a.candidateList.isEmpty()) return new Pick(null, 0, "대기", List.of());
        ArrayList<Scored> scored = new ArrayList<>();
        for (Shanten.Candidate c : a.candidateList) {
            int t = Tile.parse(c.discard);
            int risk = t < 0 || mixed == null ? 100 : (int)Math.round(Math.max(0.0, mixed[t]));
            double offense = -c.shanten * 1000.0 + c.ukeire * 12.0;
            double penalty;
            if (risk <= 1) offense += 90;
            if (c.shanten <= 0) penalty = risk * 1.1;
            else if (c.shanten == 1) penalty = risk * 3.0;
            else penalty = risk * 6.0;
            scored.add(new Scored(c, risk, offense - penalty));
        }
        scored.sort(Comparator.comparingDouble((Scored x) -> x.score).reversed());
        Scored best = scored.get(0);
        String mode = best.risk >= 15 && best.c.shanten >= 2 ? "수비" : (best.risk >= 8 ? "공수" : "공격");
        ArrayList<String> top = new ArrayList<>();
        for (int i=0;i<Math.min(3,scored.size());i++) {
            Scored x=scored.get(i);
            top.add(x.c.discard+"("+x.c.shanten+"샹텐/유효"+x.c.ukeire+"/위험"+x.risk+")");
        }
        return new Pick(best.c.discard,best.risk,mode,top);
    }

    static int risk(String tile, int[] visible, List<Opponent> opponents) {
        int t = Tile.parse(tile);
        if (t < 0) return 100;
        int max = 0;
        boolean anyRiichi = false;
        for (Opponent o : opponents) {
            if (o.tenpaiRate <= 0.0 && !o.riichi) continue;
            anyRiichi = true;
            int raw = riskVs(t, visible, o.river);
            double factor = o.riichi ? 1.0 : (o.tenpaiRate / 100.0);
            int r = (int)Math.round(raw * factor);
            if (r > max) max = r;
        }
        return anyRiichi ? max : 0;
    }

    private static int riskVs(int t, int[] visible, List<String> river) {
        if (containsTile(river, t)) return 0; // genbutsu
        int seen = visible == null ? 0 : Math.max(0, Math.min(4, visible[t]));
        if (t >= 27) {
            if (seen >= 3) return 3;
            if (seen == 2) return 15;
            if (seen == 1) return 35;
            return 62;
        }

        int rank = t % 9 + 1;
        int risk;
        if (rank == 1 || rank == 9) risk = 48;
        else if (rank == 2 || rank == 8) risk = 62;
        else if (rank == 3 || rank == 7) risk = 74;
        else if (rank == 4 || rank == 6) risk = 86;
        else risk = 94;

        if (isSuji(t, river)) risk = (int) Math.round(risk * 0.55);
        if (isKabeReduced(t, visible)) risk = (int) Math.round(risk * 0.67);
        if (seen >= 3) risk = (int) Math.round(risk * 0.45);
        else if (seen == 2) risk = (int) Math.round(risk * 0.72);
        return Math.max(1, Math.min(100, risk));
    }

    private static boolean containsTile(List<String> river, int t) {
        for (String s : river) if (Tile.parse(s) == t) return true;
        return false;
    }

    private static boolean isSuji(int t, List<String> river) {
        if (t >= 27) return false;
        int suit = t / 9;
        int rank = t % 9 + 1;
        for (String s : river) {
            int d = Tile.parse(s);
            if (d < 0 || d >= 27 || d / 9 != suit) continue;
            int dr = d % 9 + 1;
            if (Math.abs(rank - dr) == 3) return true;
        }
        return false;
    }

    private static boolean isKabeReduced(int t, int[] visible) {
        if (visible == null || t >= 27) return false;
        int pos = t % 9;
        int base = (t / 9) * 9;
        if (pos > 0 && visible[base + pos - 1] >= 4) return true;
        if (pos < 8 && visible[base + pos + 1] >= 4) return true;
        return false;
    }

    private static final class Scored {
        final Shanten.Candidate c;
        final int risk;
        final double score;
        Scored(Shanten.Candidate c, int risk, double score) { this.c = c; this.risk = risk; this.score = score; }
    }
}
