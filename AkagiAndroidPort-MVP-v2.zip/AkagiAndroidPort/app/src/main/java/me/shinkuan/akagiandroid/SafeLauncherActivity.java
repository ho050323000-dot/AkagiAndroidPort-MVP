package me.shinkuan.akagiandroid;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Tiny launcher kept independent from the mahjong/AI engine.
 * If the heavy Activity ever crashes before it can render a diagnostic screen,
 * the stack trace is persisted and shown on the next launch.
 */
public final class SafeLauncherActivity extends Activity {
    private Thread.UncaughtExceptionHandler previous;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        installCrashRecorder();
        SharedPreferences p = getSharedPreferences("akagi_boot_diag", MODE_PRIVATE);
        String crash = p.getString("last_crash", null);
        if (crash != null && !getIntent().getBooleanExtra("force_retry", false)) {
            showCrash(crash);
        } else {
            launchHelper();
        }
    }

    private void installCrashRecorder() {
        previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, error) -> {
            try {
                getSharedPreferences("akagi_boot_diag", MODE_PRIVATE).edit()
                        .putString("last_crash", Log.getStackTraceString(error))
                        .putLong("last_crash_time", System.currentTimeMillis()).commit();
            } catch (Throwable ignored) {}
            if (previous != null) previous.uncaughtException(thread, error);
        });
    }

    private void launchHelper() {
        try {
            Intent i = new Intent();
            i.setClassName(getPackageName(), getPackageName() + ".MainActivity");
            startActivity(i);
            finish();
        } catch (Throwable t) {
            getSharedPreferences("akagi_boot_diag", MODE_PRIVATE).edit()
                    .putString("last_crash", Log.getStackTraceString(t)).commit();
            showCrash(Log.getStackTraceString(t));
        }
    }

    private void showCrash(String trace) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(28, 28, 28, 28);
        box.setBackgroundColor(0xFF111111);

        TextView title = new TextView(this);
        title.setText("Akagi Android 안전 부팅\n이전 실행의 실제 크래시를 잡았습니다.");
        title.setTextColor(Color.WHITE);
        title.setTextSize(18);
        box.addView(title);

        TextView body = new TextView(this);
        body.setText(trace + "\n\n이 내용을 캡처해서 보내주세요.");
        body.setTextColor(0xFFE0E0E0);
        body.setTextSize(11);
        body.setTextIsSelectable(true);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(body);
        box.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        Button retry = new Button(this);
        retry.setText("크래시 기록 지우고 헬퍼 다시 실행");
        retry.setOnClickListener(v -> {
            getSharedPreferences("akagi_boot_diag", MODE_PRIVATE).edit().clear().commit();
            launchHelper();
        });
        box.addView(retry);
        setContentView(box);
    }
}
