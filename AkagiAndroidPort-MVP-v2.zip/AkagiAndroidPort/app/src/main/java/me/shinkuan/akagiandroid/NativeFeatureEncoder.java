package me.shinkuan.akagiandroid;

import java.util.List;

/** Feature encoder matching Akagi V3 native_bot/src/obs.rs. */
final class NativeFeatureEncoder {
    private NativeFeatureEncoder() {}

    static float[] encode(
            int players,
            int selfSeat,
            List<String> hand,
            String drawnTile,
            List<String> waits,
            List<String> doraIndicators,
            List<String>[] rivers,
            List<String>[] meldTiles,
            boolean[] riichi,
            String[] riichiTile,
            int[] scores,
            int[] kitaCount,
            String lastDiscard,
            int roundWind,
            int dealerSeat,
            int honba,
            int riichiSticks,
            int turnCount,
            int kyokuIndex) {
        if (players != 3 && players != 4) players = 4;
        if (selfSeat < 0 || selfSeat >= players) return null;
        int t = players == 3 ? 27 : 34;
        int c = players == 3 ? 37 : 39;
        float[] out = new float[c * t];
        int ch = 0;

        int[] hc = new int[t];
        boolean[] aka = new boolean[3];
        if (hand != null) for (String s : hand) {
            int idx = Tile.tileAxisIndex(s, players);
            if (idx >= 0 && idx < t) hc[idx]++;
            if (Tile.isRed(s)) {
                int t34 = Tile.parse(s);
                if (t34 == 4) aka[0] = true;
                else if (t34 == 13) aka[1] = true;
                else if (t34 == 22) aka[2] = true;
            }
        }
        for (int threshold = 1; threshold <= 4; threshold++) {
            for (int i = 0; i < t; i++) if (hc[i] >= threshold) set(out, t, ch, i, 1f);
            ch++;
        }
        int[] red34 = {4, 13, 22};
        for (int i = 0; i < 3; i++) if (aka[i]) {
            int idx = players == 3 ? Tile.compact3p(red34[i]) : red34[i];
            if (idx >= 0) set(out, t, ch, idx, 1f);
        }
        ch++;

        int drawnIdx = Tile.tileAxisIndex(drawnTile, players);
        if (drawnIdx >= 0) set(out, t, ch, drawnIdx, 1f);
        ch++;

        if (waits != null) for (String w : waits) {
            int idx = Tile.tileAxisIndex(w, players);
            if (idx >= 0) set(out, t, ch, idx, 1f);
        }
        ch++;

        if (doraIndicators != null) for (String d : doraIndicators) {
            int idx = Tile.tileAxisIndex(d, players);
            if (idx >= 0) add(out, t, ch, idx, 0.25f);
        }
        ch++;

        if (doraIndicators != null) for (String d : doraIndicators) {
            int d34 = Tile.nextDora34(Tile.parse(d), players);
            int idx = players == 3 ? Tile.compact3p(d34) : d34;
            if (idx >= 0) add(out, t, ch, idx, 0.25f);
        }
        ch++;

        // Per-player discards, self-relative.
        for (int k = 0; k < players; k++) {
            int seat = (selfSeat + k) % players;
            if (rivers != null && seat < rivers.length && rivers[seat] != null) {
                for (String s : rivers[seat]) {
                    int idx = Tile.tileAxisIndex(s, players);
                    if (idx >= 0) add(out, t, ch, idx, 0.25f);
                }
            }
            ch++;
        }

        // Per-player meld tiles.
        for (int k = 0; k < players; k++) {
            int seat = (selfSeat + k) % players;
            if (meldTiles != null && seat < meldTiles.length && meldTiles[seat] != null) {
                for (String s : meldTiles[seat]) {
                    int idx = Tile.tileAxisIndex(s, players);
                    if (idx >= 0) add(out, t, ch, idx, 0.25f);
                }
            }
            ch++;
        }

        // Per-player riichi.
        for (int k = 0; k < players; k++) {
            int seat = (selfSeat + k) % players;
            if (riichi != null && seat < riichi.length && riichi[seat]) broadcast(out, t, ch, 1f);
            ch++;
        }

        // Per-player riichi declaration tile.
        for (int k = 0; k < players; k++) {
            int seat = (selfSeat + k) % players;
            if (riichiTile != null && seat < riichiTile.length) {
                int idx = Tile.tileAxisIndex(riichiTile[seat], players);
                if (idx >= 0) set(out, t, ch, idx, 1f);
            }
            ch++;
        }

        // Per-player score, normalized.
        for (int k = 0; k < players; k++) {
            int seat = (selfSeat + k) % players;
            int score = scores != null && seat < scores.length ? scores[seat] : 25000;
            float v = Math.max(0f, Math.min(4f, score / 50000f));
            broadcast(out, t, ch, v);
            ch++;
        }

        int lastIdx = Tile.tileAxisIndex(lastDiscard, players);
        if (lastIdx >= 0) set(out, t, ch, lastIdx, 1f);
        ch++;

        int rw34 = 27 + Math.max(0, Math.min(3, roundWind));
        int rw = players == 3 ? Tile.compact3p(rw34) : rw34;
        if (rw >= 0) set(out, t, ch, rw, 1f);
        ch++;

        int seatWind = ((selfSeat + players - Math.max(0, dealerSeat)) % players);
        int sw34 = 27 + Math.max(0, Math.min(3, seatWind));
        int sw = players == 3 ? Tile.compact3p(sw34) : sw34;
        if (sw >= 0) set(out, t, ch, sw, 1f);
        ch++;

        broadcast(out, t, ch++, Math.min(2f, Math.max(0, honba) / 4f));
        broadcast(out, t, ch++, Math.min(2f, Math.max(0, riichiSticks) / 4f));
        broadcast(out, t, ch++, Math.min(1f, Math.max(0, turnCount) / 70f));
        boolean isTenpai = waits != null && !waits.isEmpty();
        broadcast(out, t, ch++, isTenpai ? 1f : 0f);
        broadcast(out, t, ch++, selfSeat == dealerSeat ? 1f : 0f);
        broadcast(out, t, ch++, Math.min(1f, Math.max(0, kyokuIndex) / 8f));
        broadcast(out, t, ch++, riichi != null && selfSeat < riichi.length && riichi[selfSeat] ? 1f : 0f);

        if (players == 3) {
            for (int k = 0; k < players; k++) {
                int seat = (selfSeat + k) % players;
                int n = kitaCount != null && seat < kitaCount.length ? kitaCount[seat] : 0;
                broadcast(out, t, ch++, Math.min(1f, Math.max(0, n) / 4f));
            }
        }
        if (ch != c) throw new IllegalStateException("native feature channel mismatch: " + ch + " != " + c);
        return out;
    }

    private static void set(float[] a, int t, int ch, int idx, float v) { a[ch * t + idx] = v; }
    private static void add(float[] a, int t, int ch, int idx, float v) { a[ch * t + idx] += v; }
    private static void broadcast(float[] a, int t, int ch, float v) {
        int base = ch * t;
        for (int i = 0; i < t; i++) a[base + i] = v;
    }
}
