package me.shinkuan.akagiandroid;

import java.util.ArrayList;
import java.util.List;

/** Statistical helper rates ported from Akagi V3's analysis tables. */
final class RateAnalyzer {
    private RateAnalyzer() {}

    private static final double[][] AGARI_NUMBER = {
            {0,11.8,20.3,26.7,31.0}, {0,11.8,20.3,26.7,31.0},
            {0,14.8,25.5,32.0,36.8}, {0,19.2,31.7,38.2,42.0},
            {0,26.3,41.6,50.1,54.0}, {0,12.9,24.7,30.9,35.4},
            {0,12.9,24.7,30.9,35.4}, {0,12.9,24.7,30.9,35.4},
            {0,17.2,33.1,43.5,48.9}, {0,24.9,42.7,51.2,56.5},
            {0,36.1,60.0,67.9,0.0}, {0,16.5,35.5,45.4,50.0},
            {0,16.5,35.5,45.4,50.0}
    };
    private static final double[] HONOR_NON_TANKI = {0,34.0,52.0};
    private static final double[] HONOR_TANKI = {0,47.5,58.0,49.5};
    private static final double FURITEN_BASE = 5.9;
    private static final double HONOR_DORA_MULTI = 35.0 / 48.0;
    private static final double NUMBER_DORA_MULTI = 26.0 / 38.0;
    private static final double RYANMEN_MULTI = 0.91;

    static final class AgariResult {
        final double average;
        final List<String> perWait;
        final boolean furiten;
        AgariResult(double average, List<String> perWait, boolean furiten) {
            this.average = average; this.perWait = perWait; this.furiten = furiten;
        }
    }

    static AgariResult agariRate(List<String> waits, int[] visible, List<String> ownRiver, List<String> indicators, int players) {
        if (waits == null || waits.isEmpty()) return new AgariResult(0, List.of(), false);
        boolean[] ownDiscard = new boolean[34];
        if (ownRiver != null) for (String s : ownRiver) { int t = Tile.parse(s); if (t >= 0) ownDiscard[t] = true; }
        boolean furiten = false;
        for (String w : waits) { int t = Tile.parse(w); if (t >= 0 && ownDiscard[t]) furiten = true; }

        boolean[] dora = new boolean[34];
        if (indicators != null) for (String s : indicators) {
            int t = Tile.parse(s); int d = Tile.nextDora34(t, players); if (d >= 0) dora[d] = true;
        }
        int[] cls = classify(ownDiscard);
        ArrayList<String> detail = new ArrayList<>();
        double agg = 0;
        ArrayList<Integer> waitTiles = new ArrayList<>();
        for (String w : waits) {
            int t = Tile.parse(w); if (t < 0) continue;
            int seen = visible == null ? 0 : Math.max(0, Math.min(4, visible[t]));
            int left = Math.max(0, 4 - seen);
            waitTiles.add(t);
            double rate;
            if (furiten) {
                rate = 0;
                for (int i = 0; i < left; i++) rate = compose(rate, FURITEN_BASE);
            } else if (waits.size() == 1 && t >= 27) {
                rate = HONOR_TANKI[Math.min(left, HONOR_TANKI.length - 1)];
                if (dora[t]) rate *= HONOR_DORA_MULTI;
            } else if (t >= 27) {
                rate = HONOR_NON_TANKI[Math.min(left, HONOR_NON_TANKI.length - 1)];
                if (dora[t]) rate *= HONOR_DORA_MULTI;
            } else {
                rate = AGARI_NUMBER[cls[t]][Math.min(left, 4)];
                if (dora[t]) rate *= NUMBER_DORA_MULTI;
            }
            agg = compose(agg, rate);
            detail.add(Tile.name(t) + " " + Math.round(rate) + "%/" + left + "장");
        }
        if (!furiten && (waitTiles.size() == 2 || waitTiles.size() == 3)) {
            boolean numbers = true, sameSuit = true, ladder = true;
            int suit = waitTiles.get(0) / 9;
            waitTiles.sort(Integer::compareTo);
            for (int t : waitTiles) if (t >= 27) numbers = false;
            for (int t : waitTiles) if (t / 9 != suit) sameSuit = false;
            for (int i = 1; i < waitTiles.size(); i++) if (waitTiles.get(i) != waitTiles.get(i - 1) + 3) ladder = false;
            if (numbers && sameSuit && ladder) agg *= RYANMEN_MULTI;
        }
        return new AgariResult(Math.max(0, Math.min(100, agg)), detail, furiten);
    }

    private static double compose(double a, double b) { return a + b - a * b / 100.0; }

    /** 0..12 index matching Akagi's TileTypeKind number-tile rows. */
    private static int[] classify(boolean[] safe) {
        int[] out = new int[27];
        for (int suit = 0; suit < 3; suit++) {
            int b = suit * 9;
            // ranks 1,2,3 depend on rank+3 safe
            out[b]   = safe[b+3] ? 10 : 4; // 1 -> Suji19 / NoSuji19
            out[b+1] = safe[b+4] ? 9  : 3; // 2 -> Suji28 / NoSuji28
            out[b+2] = safe[b+5] ? 8  : 2; // 3 -> Suji37 / NoSuji37
            // rank 4: safe 1 and/or 7; rank 5: safe 2 and/or 8; rank 6: safe 3 and/or 9
            out[b+3] = pattern46(safe[b], safe[b+6], false);
            out[b+4] = pattern5(safe[b+1], safe[b+7]);
            out[b+5] = pattern46(safe[b+2], safe[b+8], true);
            out[b+6] = safe[b+3] ? 8  : 2;
            out[b+7] = safe[b+4] ? 9  : 3;
            out[b+8] = safe[b+5] ? 10 : 4;
        }
        return out;
    }

    private static int pattern5(boolean low, boolean high) {
        if (low && high) return 11;
        if (low || high) return 5;
        return 0;
    }
    private static int pattern46(boolean low, boolean high, boolean rank6) {
        if (low && high) return 12;
        if (!low && !high) return 1;
        // Exact A/B distinction does not alter agari table values, but preserve enum row shape.
        if (rank6) return low ? 6 : 7;
        return low ? 7 : 6;
    }

    static double tenpaiRate(int openMelds, int discardCount, int tedashiAfterLastCall, boolean riichi, int players) {
        if (riichi) return 100.0;
        double r;
        if (openMelds <= 0) r = Math.min(100, Math.max(0, discardCount));
        else if (openMelds >= 4) r = 100.0;
        else {
            double[][] table = openMelds == 1 ? TENPAI1 : openMelds == 2 ? TENPAI2 : TENPAI3;
            int turn = Math.min(Math.max(0, discardCount), table.length - 1);
            double[] row = table[turn];
            if (row.length == 0) r = 0;
            else r = row[Math.min(Math.max(0, tedashiAfterLastCall), row.length - 1)];
        }
        if (players == 3) r = r * (2.0 - r / 100.0);
        return Math.max(0, Math.min(100, r));
    }

    private static final double[][] TENPAI1 = {
            {0.0},{1.05},{1.72,3.37},{2.90,5.60,8.53},{5.26,9.34,13.45,17.86},
            {8.56,14.42,19.88,25.19,31.25},{13.05,21.04,27.89,33.85,40.21,47.34},
            {18.34,28.05,35.71,42.58,48.71,55.85,63.21},{24.38,35.07,43.76,51.24,57.73,63.48,68.56,74.68},
            {30.11,41.25,50.79,58.60,64.60,70.18,74.26,78.25,80.23},
            {36.12,47.47,57.50,64.90,71.13,76.06,79.35,82.00,83.50,83.50},
            {41.39,53.62,62.82,69.87,75.56,79.85,83.07,85.42,87.92,89.02},
            {46.38,58.24,66.75,74.18,80.05,84.12,87.14,89.50,91.41,92.73},
            {49.21,61.84,70.55,78.84,82.92,86.07,88.99,91.38,93.44,94.63,96.42},
            {52.07,63.94,73.27,81.35,85.42,88.85,91.24,93.14,94.28},
            {56.89,68.11,75.01,81.98,84.55,87.98,90.60,92.04,93.63},
            {62.86,73.24,79.46,83.20,86.56,90.76,92.81},{67.42,75.09,80.07,80.07,80.07,86.71},{69.02,84.51,84.51}
    };
    private static final double[][] TENPAI2 = {
            {0.0},{0.0},{9.92},{12.10,17.72},{17.54,25.55,32.77},{23.24,32.99,41.82,53.61},
            {30.32,41.77,51.53,62.77,68.97},{37.55,49.50,60.05,69.07,74.40,76.53},
            {43.52,56.91,67.17,75.04,79.34,80.43,88.26},{50.28,63.58,73.48,80.34,83.85,84.45,89.63,89.63},
            {55.06,69.27,77.62,84.93,88.26,89.04,90.73,93.82,96.91},
            {62.00,74.63,82.16,88.18,91.51,92.42,94.17,97.08,98.54,98.54},
            {66.04,78.10,85.15,89.57,93.22,94.76,95.51,98.20},{70.83,81.37,88.29,91.52,94.40,96.40,97.20,98.60},
            {72.52,82.80,89.17,92.46,94.97,96.52,96.52},{75.00,85.45,90.74,94.57,95.85,96.68,96.68,96.68},
            {76.98,85.15,89.27,93.44,94.38,95.18,95.18},{81.56,88.65,91.89,96.76,96.76},{84.01}
    };
    private static final double[][] TENPAI3 = {
            {0.0},{0.0},{0.0},{43.81},{52.07,63.48},{61.44,70.28,87.26},{68.20,77.06,90.17},
            {72.56,82.85,88.56,88.56},{77.58,87.59,90.93},{81.16,90.22,92.74,97.58},
            {84.53,91.37,94.75},{86.23,92.28,96.31,98.15},{87.26,93.05,96.53,98.26,99.99},
            {87.24,94.11,96.83},{87.35,94.58,95.93},{87.66,93.15,94.29},{89.03,91.77,93.42,93.42},{89.54,89.54},{90.19}
    };
}
