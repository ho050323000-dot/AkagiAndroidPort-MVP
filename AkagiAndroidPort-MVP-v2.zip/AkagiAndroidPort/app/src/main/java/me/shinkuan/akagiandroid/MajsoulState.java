package me.shinkuan.akagiandroid;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

final class MajsoulState {
    interface Listener { void onState(Snapshot s); }

    static final class Snapshot {
        final long frames; final String lastMethod; final String lastAction;
        final int selfSeat; final int playerCount; final List<String> hand; final List<String> doras;
        final int leftTiles; final Shanten.Analysis analysis; final DefenseAnalyzer.Pick pick;
        final AkagiNativeModel.Prediction ai; final AkagiNativeModel.ActionPrediction aiAction; final RateAnalyzer.AgariResult agari;
        final String finalDiscard; final String finalSource;
        final String opponents; final String stats; final String note; final String inspector;
        final long historyVersion; final String historyLine;
        Snapshot(long frames, String lastMethod, String lastAction, int selfSeat, int playerCount,
                 List<String> hand, List<String> doras, int leftTiles, Shanten.Analysis analysis,
                 DefenseAnalyzer.Pick pick, AkagiNativeModel.Prediction ai, AkagiNativeModel.ActionPrediction aiAction, RateAnalyzer.AgariResult agari,
                 String finalDiscard, String finalSource, String opponents, String stats, String note,
                 String inspector, long historyVersion, String historyLine) {
            this.frames=frames; this.lastMethod=lastMethod; this.lastAction=lastAction; this.selfSeat=selfSeat;
            this.playerCount=playerCount; this.hand=hand; this.doras=doras; this.leftTiles=leftTiles;
            this.analysis=analysis; this.pick=pick; this.ai=ai; this.aiAction=aiAction; this.agari=agari;
            this.finalDiscard=finalDiscard; this.finalSource=finalSource; this.opponents=opponents;
            this.stats=stats; this.note=note; this.inspector=inspector;
            this.historyVersion=historyVersion; this.historyLine=historyLine;
        }
    }

    private final Map<Integer,String> requestMethods = new HashMap<>();
    private final Map<Integer,Long> requestAccountIds = new HashMap<>();
    private final Listener listener;
    private final AkagiNativeModel model3, model4;
    private static final class OperationOffer {
        final int type; final List<String> combinations; final List<String> changeTiles;
        OperationOffer(int type,List<String> combinations,List<String> changeTiles){this.type=type;this.combinations=combinations;this.changeTiles=changeTiles;}
    }
    private final ArrayList<OperationOffer> operationOffers = new ArrayList<>();
    private long frames; private String lastMethod="-", lastAction="-"; private long accountId=-1;
    private int selfSeat=-1, playerCount=4;
    private final ArrayList<String> hand = new ArrayList<>();
    /** Majsoul 'doras' are dora indicators/markers. */
    private final ArrayList<String> doras = new ArrayList<>();
    private final int[] visible = new int[34];
    @SuppressWarnings("unchecked") private final ArrayList<String>[] rivers = new ArrayList[]{new ArrayList<>(),new ArrayList<>(),new ArrayList<>(),new ArrayList<>()};
    @SuppressWarnings("unchecked") private final ArrayList<String>[] meldTiles = new ArrayList[]{new ArrayList<>(),new ArrayList<>(),new ArrayList<>(),new ArrayList<>()};
    private final boolean[] riichi = new boolean[4]; private final String[] riichiTile = new String[4];
    private final boolean[][] postRiichiSafe = new boolean[4][34];
    private final int[] openMelds = new int[4]; private final int[] tedashiAfterCall = new int[4]; private final int[] kitaCount = new int[4];
    private final int[] scores = {25000,25000,25000,25000};
    private int leftTiles=-1, selfMelds=0, lastDiscardSeat=-1;
    private String lastDiscard=null, drawnTile=null;
    private int roundWind=0, dealerSeat=0, honba=0, riichiSticks=0, kyokuIndex=0;
    private boolean roundEnded=true, selfRiichiRound=false, selfFuuroRound=false;
    private int rounds,wins,dealIns,riichis,fuuros,draws,matches,yakumanWins;
    private long winPointsTotal,dealInPointsTotal,winTurnTotal;
    private final int[] rankCounts = new int[4];
    private String note="대기 중";
    private long historyVersion=0; private String historyLine="";

    MajsoulState(Listener listener, AkagiNativeModel model3, AkagiNativeModel model4) {
        this.listener=listener; this.model3=model3; this.model4=model4;
    }

    synchronized void reset() {
        requestMethods.clear(); requestAccountIds.clear(); operationOffers.clear(); frames=0; lastMethod=lastAction="-"; accountId=-1; selfSeat=-1; playerCount=4;
        hand.clear(); doras.clear(); Arrays.fill(visible,0); clearRoundPublic();
        rounds=wins=dealIns=riichis=fuuros=draws=matches=yakumanWins=0; winPointsTotal=dealInPointsTotal=winTurnTotal=0; Arrays.fill(rankCounts,0); leftTiles=-1; note="대기 중"; roundEnded=true; publish();
    }

    private void clearRoundPublic() {
        for (int i=0;i<4;i++) { rivers[i].clear(); meldTiles[i].clear(); riichi[i]=false; riichiTile[i]=null; Arrays.fill(postRiichiSafe[i],false); openMelds[i]=0; tedashiAfterCall[i]=0; kitaCount[i]=0; }
        lastDiscardSeat=-1; lastDiscard=null; drawnTile=null; selfRiichiRound=false; selfFuuroRound=false;
    }

    synchronized void onBinary(boolean outbound, byte[] frame) {
        frames++;
        if (frame==null || frame.length<2) { publish(); return; }
        int type=frame[0]&0xff, offset, reqId=-1;
        if (type==1) offset=1;
        else if (type==2 || type==3) { if (frame.length<4) { publish(); return; } reqId=(frame[1]&0xff)|((frame[2]&0xff)<<8); offset=3; }
        else { publish(); return; }
        List<Proto.Field> wf=Proto.parse(Arrays.copyOfRange(frame,offset,frame.length));
        String method=Proto.firstString(wf,1,""); byte[] payload=Proto.firstBytes(wf,2);
        if (type==2) {
            if (!method.isEmpty()) requestMethods.put(reqId,method);
            if (".lq.FastTest.authGame".equals(method) && payload!=null) {
                long id=Proto.firstVarint(Proto.parse(payload),1,-1); if(id>=0){accountId=id;requestAccountIds.put(reqId,id);note="대국 인증 요청 감지";}
            }
        } else if (type==3) {
            if (method.isEmpty()) method=requestMethods.remove(reqId); if(method==null) method="";
            if(payload!=null){
                if(".lq.FastTest.authGame".equals(method)) parseAuthResponse(reqId,payload);
                else if(".lq.FastTest.syncGame".equals(method)||".lq.FastTest.enterGame".equals(method)) parseGameRestoreResponse(payload);
            }
        }
        if(!method.isEmpty()) lastMethod=method;
        if(".lq.ActionPrototype".equals(method)&&payload!=null) parseActionPrototype(payload,false);
        else if(".lq.NotifyGameEndResult".equals(method)&&payload!=null) parseGameEnd(payload);
        publish();
    }

    private void parseGameRestoreResponse(byte[] payload) {
        byte[] restore=Proto.firstBytes(Proto.parse(payload),4); if(restore==null)return;
        int replayed=0; for(Proto.Field x:Proto.parse(restore)) if(x.number==2&&x.wireType==2&&x.bytes!=null){parseActionPrototype(x.bytes,true);replayed++;}
        if(replayed>0) note="대국 복구 완료 · 액션 "+replayed+"개 재생";
    }

    private static void wtfDecode(byte[] data) {
        final int[] keys={0x84,0x5E,0x4E,0x42,0x39,0xA2,0x1F,0x60,0x1C}; int base=23^data.length;
        for(int i=0;i<data.length;i++) data[i]=(byte)((data[i]&0xff)^((base+5*i+keys[i%keys.length])&0xff));
    }

    private void parseAuthResponse(int reqId, byte[] payload) {
        Long mappedId=requestAccountIds.remove(reqId); long id=mappedId==null?accountId:mappedId; if(id>=0)accountId=id;
        List<Proto.Field> fs=Proto.parse(payload); List<Long> seats=Proto.repeatedUInt(fs,3);
        if(!seats.isEmpty())playerCount=Math.max(3,Math.min(4,seats.size()));
        if(accountId>=0&&!seats.isEmpty()) for(int i=0;i<seats.size();i++) if(seats.get(i)==accountId){selfSeat=i;note="내 좌석 확인: "+i+" / "+playerCount+"인";return;}
    }

    private void parseActionPrototype(byte[] payload, boolean restoreAction) {
        List<Proto.Field> af=Proto.parse(payload); String action=Proto.firstString(af,2,""); byte[] data=Proto.firstBytes(af,3);
        if(action.isEmpty()||data==null)return; lastAction=action; byte[] decoded=data.clone(); if(!restoreAction)wtfDecode(decoded); List<Proto.Field> f=Proto.parse(decoded);
        operationOffers.clear();
        int opTag = switch(action){
            case "ActionNewRound" -> 7;
            case "ActionDealTile", "ActionDiscardTile", "ActionAnGangAddGang", "ActionBaBei" -> 4;
            case "ActionChiPengGang" -> 6;
            default -> -1;
        };
        if(opTag>0)captureOperations(f,opTag);
        switch(action){
            case "ActionNewRound" -> {
                hand.clear();doras.clear();Arrays.fill(visible,0);clearRoundPublic();selfMelds=0;roundEnded=false;
                roundWind=(int)Proto.firstVarint(f,1,0); dealerSeat=(int)Proto.firstVarint(f,2,0); honba=(int)Proto.firstVarint(f,3,0);
                hand.addAll(cleanTiles(Proto.strings(f,4))); String dora=Proto.firstString(f,5,""); if(!dora.isEmpty())doras.add(dora);
                List<Integer> sc=int32s(f,6); for(int i=0;i<Math.min(sc.size(),4);i++)scores[i]=sc.get(i);
                riichiSticks=(int)Proto.firstVarint(f,8,0); for(String d:Proto.strings(f,14))if(!doras.contains(d))doras.add(d);
                leftTiles=(int)Proto.firstVarint(f,13,-1); kyokuIndex=roundWind*Math.max(3,playerCount)+dealerSeat;
                if(selfSeat==dealerSeat&&hand.size()%3==2&&!hand.isEmpty())drawnTile=hand.get(hand.size()-1);
                for(String t:hand)markVisible(t);for(String d:doras)markVisible(d);
                note=hand.isEmpty()?"새 국 감지 (손패 대기)":"새 국 / 원본 AI 분석 시작";
            }
            case "ActionDealTile" -> {
                int seat=(int)Proto.firstVarint(f,1,-1);String tile=Proto.firstString(f,2,"");leftTiles=(int)Proto.firstVarint(f,3,leftTiles);lastDiscard=null;
                if(!tile.isEmpty()){if(selfSeat<0){selfSeat=seat;note="내 좌석 추정: "+seat;}if(seat==selfSeat){hand.add(tile);markVisible(tile);drawnTile=tile;}}
                addDoras(Proto.strings(f,6));
            }
            case "ActionDiscardTile" -> {
                int seat=(int)Proto.firstVarint(f,1,-1);String tile=Proto.firstString(f,2,"");boolean declared=Proto.firstVarint(f,3,0)!=0||Proto.firstVarint(f,9,0)!=0;boolean tsumogiri=Proto.firstVarint(f,5,0)!=0;
                if(seat>=0&&seat<4&&!tile.isEmpty()){rivers[seat].add(Tile.name(Tile.parse(tile)));if(!tsumogiri)tedashiAfterCall[seat]++;}
                int discarded34=Tile.parse(tile);
                if(discarded34>=0){for(int op=0;op<Math.min(playerCount,4);op++)if(op!=seat&&riichi[op])postRiichiSafe[op][discarded34]=true;}
                lastDiscardSeat=seat;lastDiscard=tile;if(!tile.isEmpty()){if(seat==selfSeat){removeOne(tile);drawnTile=null;}else markVisible(tile);}
                if(declared&&seat>=0&&seat<4){riichi[seat]=true;riichiTile[seat]=tile;riichiSticks++;if(seat==selfSeat&&!selfRiichiRound){selfRiichiRound=true;riichis++;}note=seat==selfSeat?"리치 선언":"상대 "+seat+" 리치 · 위험도 반영";}
                addDoras(Proto.strings(f,8)); List<Integer> sc=int32s(f,13); for(int i=0;i<Math.min(sc.size(),4);i++)scores[i]=sc.get(i);
            }
            case "ActionChiPengGang" -> {
                int seat=(int)Proto.firstVarint(f,1,-1);List<String> tiles=cleanTiles(Proto.strings(f,3));List<Long> froms=Proto.repeatedUInt(f,4);
                if(seat>=0&&seat<4){openMelds[seat]++;tedashiAfterCall[seat]=0;meldTiles[seat].addAll(tiles);}
                if(seat==selfSeat){selfMelds++;if(!selfFuuroRound){selfFuuroRound=true;fuuros++;}}
                if(froms.size()==tiles.size()){
                    for(int i=0;i<tiles.size();i++){
                        long origin=froms.get(i);
                        if(origin==seat&&seat==selfSeat)removeOne(tiles.get(i));
                        else if(origin==seat&&seat!=selfSeat)markVisible(tiles.get(i));
                    }
                } else if(seat==selfSeat){int removed=0;for(String t:tiles)if(removed<3&&removeOne(t))removed++;}
                else {for(String t:tiles)markVisible(t);}
            }
            case "ActionAnGangAddGang" -> {
                int seat=(int)Proto.firstVarint(f,1,-1);String tile=Proto.firstString(f,3,"");int gangType=(int)Proto.firstVarint(f,2,-1);
                if(seat>=0&&seat<4){tedashiAfterCall[seat]=0;int copies=gangType==3?4:1;for(int i=0;i<copies;i++)meldTiles[seat].add(tile);if(seat!=selfSeat&&!tile.isEmpty())for(int i=0;i<copies;i++)markVisible(tile);}
                if(seat==selfSeat){if(gangType==3)selfMelds++;if(!selfFuuroRound){selfFuuroRound=true;fuuros++;}if(!tile.isEmpty()){int normal=Tile.parse(tile),count=0;for(String h:hand)if(Tile.parse(h)==normal)count++;int remove=count>=4?4:Math.min(1,count);for(int i=0;i<remove;i++)removeOne(tile);}}
                addDoras(Proto.strings(f,6));
            }
            case "ActionBaBei" -> {int seat=(int)Proto.firstVarint(f,1,-1);if(seat>=0&&seat<4)kitaCount[seat]++;if(seat==selfSeat)removeOne("4z");else if(seat>=0)markVisible("4z");addDoras(Proto.strings(f,6));}
            case "ActionHule" -> {parseHule(f);finishRound("화료로 국 종료");}
            case "ActionNoTile" -> {draws++;finishRound("유국");}
            case "ActionLiuJu" -> {draws++;finishRound("도중유국");}
            default -> {}
        }
    }

    private void parseHule(List<Proto.Field> f){
        boolean selfWon=false,selfDealt=false;
        for(Proto.Field x:f){
            if(x.number!=1||x.wireType!=2||x.bytes==null)continue;
            List<Proto.Field> h=Proto.parse(x.bytes);
            int winner=(int)Proto.firstVarint(h,4,-1); boolean zimo=Proto.firstVarint(h,5,0)!=0;
            long pointRong=Proto.firstVarint(h,15,0); long pointSum=Proto.firstVarint(h,19,0); boolean yakuman=Proto.firstVarint(h,10,0)!=0;
            if(winner==selfSeat){
                selfWon=true; long gained=pointSum>0?pointSum:pointRong; if(gained>0)winPointsTotal+=gained;
                winTurnTotal += selfSeat>=0&&selfSeat<4 ? rivers[selfSeat].size()+1L : 0L;
                if(yakuman)yakumanWins++;
            } else if(!zimo&&lastDiscardSeat==selfSeat){
                selfDealt=true; if(pointRong>0)dealInPointsTotal+=pointRong;
            }
        }
        if(selfWon)wins++; if(selfDealt)dealIns++;
    }

    private void finishRound(String why){if(!roundEnded){rounds++;roundEnded=true;historyVersion++;historyLine="국 "+rounds+" · "+why+" · 승"+wins+" 방총"+dealIns+" 리치"+riichis+" 후로"+fuuros;}note=why;}

    private void parseGameEnd(byte[] payload){
        byte[] result=Proto.firstBytes(Proto.parse(payload),1);if(result==null)return;ArrayList<int[]> ps=new ArrayList<>();
        for(Proto.Field x:Proto.parse(result))if(x.number==1&&x.wireType==2&&x.bytes!=null){List<Proto.Field> pf=Proto.parse(x.bytes);ps.add(new int[]{(int)Proto.firstVarint(pf,1,-1),(int)Proto.firstVarint(pf,2,0)});}
        ps.sort((a,b)->Integer.compare(b[1],a[1]));int rank=0,point=0;for(int i=0;i<ps.size();i++)if(ps.get(i)[0]==selfSeat){rank=i+1;point=ps.get(i)[1];}
        matches++; if(rank>=1&&rank<=4)rankCounts[rank-1]++;
        historyVersion++;historyLine="대국 종료 · "+(rank>0?rank+"위 · ":"")+"점수 "+point+" · "+statsSummary();note=historyLine;
    }

    private void captureOperations(List<Proto.Field> actionFields,int tag){
        byte[] list=Proto.firstBytes(actionFields,tag); if(list==null)return;
        List<Proto.Field> lf=Proto.parse(list); int seat=(int)Proto.firstVarint(lf,1,-1);
        if(selfSeat>=0&&seat>=0&&seat!=selfSeat)return;
        for(Proto.Field x:lf){
            if(x.number!=2||x.wireType!=2||x.bytes==null)continue;
            List<Proto.Field> of=Proto.parse(x.bytes); int type=(int)Proto.firstVarint(of,1,0);
            operationOffers.add(new OperationOffer(type,new ArrayList<>(Proto.strings(of,2)),new ArrayList<>(Proto.strings(of,3))));
        }
    }

    private List<AkagiNativeModel.ActionOption> buildActionOptions(AkagiNativeModel model,List<String> h){
        ArrayList<AkagiNativeModel.ActionOption> out=new ArrayList<>();
        if(model==null)return out;
        if(h!=null&&h.size()%3==2){
            java.util.HashSet<Integer> seen=new java.util.HashSet<>();
            for(String t:h){int idx=model.discardActionIndex(t);if(idx>=0&&seen.add(idx))out.add(new AkagiNativeModel.ActionOption(idx,"타패 "+t,t));}
        }
        boolean addPass=false;
        for(OperationOffer o:operationOffers){
            switch(o.type){
                case 1 -> { /* discard options already enumerated */ }
                case 2 -> { // chi: up to three model variants
                    int count=Math.max(1,Math.min(3,o.combinations.size()));
                    for(int i=0;i<count;i++){int idx=model.chiIndex(i);if(idx>=0){String c=o.combinations.isEmpty()?"":o.combinations.get(i);out.add(new AkagiNativeModel.ActionOption(idx,"치"+(c.isEmpty()?"":"("+c+")"),null));}}
                    addPass=true;
                }
                case 3 -> {out.add(new AkagiNativeModel.ActionOption(model.ponIndex(),"퐁",null));addPass=true;}
                case 4 -> { // ankan
                    int[] cnt=Tile.counts(h);for(int t=0;t<34;t++)if(cnt[t]>=4){String tile=Tile.name(t);int idx=model.kanIndex(tile);if(idx>=0)out.add(new AkagiNativeModel.ActionOption(idx,"암깡 "+tile,null));}
                }
                case 5 -> {String tile=lastDiscard;int idx=model.kanIndex(tile);if(idx>=0)out.add(new AkagiNativeModel.ActionOption(idx,"대명깡 "+tile,null));addPass=true;}
                case 6 -> { // kakan - use server hints first, then own hand/meld overlap
                    java.util.LinkedHashSet<String> ts=new java.util.LinkedHashSet<>();ts.addAll(o.changeTiles);
                    for(String c:o.combinations)for(String q:c.split("\\|"))if(Tile.parse(q)>=0)ts.add(q);
                    if(ts.isEmpty())for(String q:h)if(selfSeat>=0&&containsTile(meldTiles[selfSeat],q))ts.add(q);
                    for(String tile:ts){int idx=model.kanIndex(tile);if(idx>=0)out.add(new AkagiNativeModel.ActionOption(idx,"가깡 "+tile,null));}
                }
                case 7 -> out.add(new AkagiNativeModel.ActionOption(model.riichiIndex(),"리치",null));
                case 8 -> out.add(new AkagiNativeModel.ActionOption(model.agariIndex(),"쯔모",null));
                case 9 -> {out.add(new AkagiNativeModel.ActionOption(model.agariIndex(),"론",null));addPass=true;}
                case 10 -> out.add(new AkagiNativeModel.ActionOption(model.kyushuIndex(),"구종구패",null));
                case 11 -> {int idx=model.kitaIndex();if(idx>=0)out.add(new AkagiNativeModel.ActionOption(idx,"북빼기",null));}
                default -> {}
            }
        }
        if(addPass)out.add(new AkagiNativeModel.ActionOption(model.passIndex(),"패스",null));
        return out;
    }
    private static boolean containsTile(List<String> xs,String tile){int t=Tile.parse(tile);if(t<0)return false;for(String x:xs)if(Tile.parse(x)==t)return true;return false;}

    private List<String> cleanTiles(List<String> xs){ArrayList<String>out=new ArrayList<>();for(String s:xs)if(Tile.parse(s)>=0)out.add(s);return out;}
    private void addDoras(List<String> ds){for(String d:ds)if(Tile.parse(d)>=0&&!doras.contains(d)){doras.add(d);markVisible(d);}}
    private void markVisible(String tile){int t=Tile.parse(tile);if(t>=0&&visible[t]<4)visible[t]++;}
    private boolean removeOne(String tile){int wanted=Tile.parse(tile);if(wanted<0)return false;for(int i=0;i<hand.size();i++)if(Tile.parse(hand.get(i))==wanted){hand.remove(i);return true;}return false;}
    private static List<Integer> int32s(List<Proto.Field> fs,int n){ArrayList<Integer>r=new ArrayList<>();for(long v:Proto.repeatedUInt(fs,n))r.add((int)v);return r;}
    private int totalDiscards(){int n=0;for(int i=0;i<Math.min(playerCount,4);i++)n+=rivers[i].size();return n;}
    private static int pct(int a,int b){return b<=0?0:(int)Math.round(a*100.0/b);}
    private String statsSummary(){
        long avgWin=wins<=0?0:winPointsTotal/wins, avgDeal=dealIns<=0?0:dealInPointsTotal/dealIns, avgTurn=wins<=0?0:winTurnTotal/wins;
        return "국"+rounds+" 승률"+pct(wins,rounds)+"% 방총률"+pct(dealIns,rounds)+"% 리치율"+pct(riichis,rounds)+"% 후로율"+pct(fuuros,rounds)+"% 유국률"+pct(draws,rounds)+"% 평균화료"+avgWin+" 평균방총"+avgDeal+" 평균화료순목"+avgTurn+" 역만"+yakumanWins;
    }

    private void publish(){
        if(listener==null)return;
        List<String> h=new ArrayList<>(hand);
        Shanten.Analysis a=h.isEmpty()?null:Shanten.analyzeDiscard(h,visible.clone(),selfMelds);
        int n=Math.max(3,Math.min(4,playerCount));

        ArrayList<AkagiRiskAnalyzer.OpponentRisk> exactRisks=new ArrayList<>();
        StringBuilder os=new StringBuilder();
        double maxTenpai=0;
        for(int seat=0;seat<n;seat++){
            if(seat==selfSeat)continue;
            AkagiRiskAnalyzer.OpponentRisk r=AkagiRiskAnalyzer.forOpponent(
                    seat,n,dealerSeat,roundWind,new ArrayList<>(rivers[seat]),postRiichiSafe[seat],riichi[seat],
                    openMelds[seat],tedashiAfterCall[seat],new ArrayList<>(meldTiles[seat]),visible.clone(),new ArrayList<>(doras));
            exactRisks.add(r); maxTenpai=Math.max(maxTenpai,r.tenpaiRate);
            if(os.length()>0)os.append(" · ");
            os.append("S").append(seat).append(riichi[seat]?" 리치":"").append(" 텐파이").append(Math.round(r.tenpaiRate)).append('%');
        }
        double[] mixedRisk=AkagiRiskAnalyzer.mixed(exactRisks);
        DefenseAnalyzer.Pick pick=DefenseAnalyzer.chooseWithMixed(a,mixedRisk);

        RateAnalyzer.AgariResult agari=(a==null||a.waits.isEmpty()||selfSeat<0)
                ?new RateAnalyzer.AgariResult(0,List.of(),false)
                :RateAnalyzer.agariRate(a.waits,visible.clone(),new ArrayList<>(rivers[selfSeat]),doras,n);

        AkagiNativeModel.Prediction ai=new AkagiNativeModel.Prediction(List.of(),0);
        AkagiNativeModel.ActionPrediction aiAction=new AkagiNativeModel.ActionPrediction(List.of(),0);
        AkagiNativeModel model=n==3?model3:model4;
        if(model!=null&&a!=null&&selfSeat>=0){
            float[] feat=NativeFeatureEncoder.encode(n,selfSeat,h,drawnTile,a.waits,doras,rivers,meldTiles,riichi,riichiTile,scores,kitaCount,lastDiscard,roundWind,dealerSeat,honba,riichiSticks,totalDiscards(),kyokuIndex);
            if(feat!=null)try{
                if(h.size()%3==2)ai=model.rankDiscards(feat,h,3);
                List<AkagiNativeModel.ActionOption> opts=buildActionOptions(model,h);
                if(!opts.isEmpty())aiAction=model.rankOptions(feat,opts,3);
            }catch(RuntimeException ignored){}
        }

        String finalDiscard=pick==null?null:pick.discard,source="공수";
        String aiBest=ai.bestTile();
        if(aiBest!=null){
            double aiRisk=AkagiRiskAnalyzer.riskOf(aiBest,mixedRisk);
            double defRisk=pick==null?100:AkagiRiskAnalyzer.riskOf(pick.discard,mixedRisk);
            boolean hardDefense=maxTenpai>=65.0&&defRisk+3.0<aiRisk;
            if(!hardDefense){finalDiscard=aiBest;source="원본AI";}else source="수비";
        }
        if(finalDiscard!=null){
            int ft=Tile.parse(finalDiscard);
            for(AkagiRiskAnalyzer.OpponentRisk r:exactRisks){
                double rr=ft<0?100:r.risk[ft]*r.tenpaiRate/100.0;
                os.append(" | S").append(r.seat).append(" 방총위험").append(Math.round(rr)).append('%');
            }
        }
        String stats=statsSummary()+" · 대국 "+matches+" · 순위 "+Arrays.toString(rankCounts);
        String inspector="좌석="+selfSeat+"/"+n+" 장풍="+roundWind+" 국="+kyokuIndex+" 친="+dealerSeat+" 본장="+honba+" 리치봉="+riichiSticks+
                "\n점수="+Arrays.toString(Arrays.copyOf(scores,n))+"\n후로="+Arrays.toString(Arrays.copyOf(openMelds,n))+" 리치="+Arrays.toString(Arrays.copyOf(riichi,n))+
                "\n원본위험엔진=ON 모델="+(model==null?"OFF":(n+"p"))+" 가능행동="+operationOffers.size()+"\n마지막="+lastAction+" / "+lastMethod;
        listener.onState(new Snapshot(frames,lastMethod,lastAction,selfSeat,n,h,new ArrayList<>(new LinkedHashSet<>(doras)),leftTiles,a,pick,ai,aiAction,agari,finalDiscard,source,os.toString(),stats,note,inspector,historyVersion,historyLine));
    }

}
