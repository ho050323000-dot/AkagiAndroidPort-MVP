package me.shinkuan.akagiandroid;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

final class MajsoulState {
    interface Listener { void onState(Snapshot s); }

    static final class Snapshot {
        final long frames;
        final String lastMethod;
        final String lastAction;
        final int selfSeat;
        final int playerCount;
        final List<String> hand;
        final List<String> doras;
        final int leftTiles;
        final Shanten.Analysis analysis;
        final DefenseAnalyzer.Pick pick;
        final String opponents;
        final String stats;
        final String note;

        Snapshot(long frames, String lastMethod, String lastAction, int selfSeat, int playerCount,
                 List<String> hand, List<String> doras, int leftTiles, Shanten.Analysis analysis,
                 DefenseAnalyzer.Pick pick, String opponents, String stats, String note) {
            this.frames = frames; this.lastMethod = lastMethod; this.lastAction = lastAction;
            this.selfSeat = selfSeat; this.playerCount = playerCount; this.hand = hand; this.doras = doras;
            this.leftTiles = leftTiles; this.analysis = analysis; this.pick = pick;
            this.opponents = opponents; this.stats = stats; this.note = note;
        }
    }

    private final Map<Integer,String> requestMethods = new HashMap<>();
    private final Map<Integer,Long> requestAccountIds = new HashMap<>();
    private final Listener listener;
    private long frames;
    private String lastMethod = "-";
    private String lastAction = "-";
    private long accountId = -1;
    private int selfSeat = -1;
    private int playerCount = 4;
    private final ArrayList<String> hand = new ArrayList<>();
    private final ArrayList<String> doras = new ArrayList<>();
    private final int[] visible = new int[34];
    @SuppressWarnings("unchecked")
    private final ArrayList<String>[] rivers = new ArrayList[]{new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), new ArrayList<>()};
    private final boolean[] riichi = new boolean[4];
    private int leftTiles = -1;
    private int selfMelds = 0;
    private int lastDiscardSeat = -1;
    private boolean roundEnded = true;
    private boolean selfRiichiRound = false;
    private boolean selfFuuroRound = false;
    private int rounds;
    private int wins;
    private int dealIns;
    private int riichis;
    private int fuuros;
    private String note = "대기 중";

    MajsoulState(Listener listener) { this.listener = listener; }

    synchronized void reset() {
        requestMethods.clear(); requestAccountIds.clear(); frames = 0;
        lastMethod = lastAction = "-"; accountId = -1; selfSeat = -1; playerCount = 4;
        hand.clear(); doras.clear(); Arrays.fill(visible, 0); clearRoundPublic();
        rounds = wins = dealIns = riichis = fuuros = 0;
        leftTiles = -1; note = "대기 중"; roundEnded = true; publish();
    }

    private void clearRoundPublic() {
        for (ArrayList<String> r : rivers) r.clear();
        Arrays.fill(riichi, false); lastDiscardSeat = -1;
        selfRiichiRound = false; selfFuuroRound = false;
    }

    synchronized void onBinary(boolean outbound, byte[] frame) {
        frames++;
        if (frame == null || frame.length < 2) { publish(); return; }
        int type = frame[0] & 0xff; int offset; int reqId = -1;
        if (type == 1) offset = 1;
        else if (type == 2 || type == 3) {
            if (frame.length < 4) { publish(); return; }
            reqId = (frame[1] & 0xff) | ((frame[2] & 0xff) << 8); offset = 3;
        } else { publish(); return; }

        byte[] wrapper = Arrays.copyOfRange(frame, offset, frame.length);
        List<Proto.Field> wf = Proto.parse(wrapper);
        String method = Proto.firstString(wf, 1, "");
        byte[] payload = Proto.firstBytes(wf, 2);

        if (type == 2) {
            if (!method.isEmpty()) requestMethods.put(reqId, method);
            if (".lq.FastTest.authGame".equals(method) && payload != null) {
                long id = Proto.firstVarint(Proto.parse(payload), 1, -1);
                if (id >= 0) { accountId = id; requestAccountIds.put(reqId, id); note = "대국 인증 요청 감지"; }
            }
        } else if (type == 3) {
            if (method.isEmpty()) method = requestMethods.remove(reqId);
            if (method == null) method = "";
            if (".lq.FastTest.authGame".equals(method) && payload != null) parseAuthResponse(reqId, payload);
            if ((".lq.FastTest.syncGame".equals(method) || ".lq.FastTest.enterGame".equals(method)) && payload != null) {
                parseGameRestoreResponse(payload);
            }
        }

        if (!method.isEmpty()) lastMethod = method;
        if (".lq.ActionPrototype".equals(method) && payload != null) parseActionPrototype(payload, true);
        publish();
    }

    private void parseAuthResponse(int reqId, byte[] payload) {
        Long mappedId = requestAccountIds.remove(reqId);
        long id = mappedId == null ? accountId : mappedId;
        if (id >= 0) accountId = id;
        List<Proto.Field> fs = Proto.parse(payload);
        List<Long> seats = Proto.repeatedUInt(fs, 3);
        if (!seats.isEmpty()) playerCount = Math.max(3, Math.min(4, seats.size()));
        if (accountId >= 0 && !seats.isEmpty()) {
            for (int i = 0; i < seats.size(); i++) {
                if (seats.get(i) == accountId) { selfSeat = i; note = "내 좌석 확인: " + i + " / " + playerCount + "인"; return; }
            }
        }
    }

    private void parseGameRestoreResponse(byte[] payload) {
        List<Proto.Field> res = Proto.parse(payload);
        byte[] restoreBytes = Proto.firstBytes(res, 4);
        if (restoreBytes == null) return;
        List<Proto.Field> restore = Proto.parse(restoreBytes);
        int replayed = 0;
        for (Proto.Field field : restore) {
            if (field.number != 2 || field.wireType != 2 || field.bytes == null) continue;
            parseActionPrototype(field.bytes, false);
            replayed++;
        }
        if (replayed > 0) note = "대국 복구 " + replayed + "개 액션 반영";
    }

    private static String normalizeActionName(String action) {
        if (action == null) return "";
        int dot = action.lastIndexOf('.');
        return dot >= 0 ? action.substring(dot + 1) : action;
    }

    private static void decodeLiveAction(byte[] data) {
        final int[] keys = {0x84, 0x5E, 0x4E, 0x42, 0x39, 0xA2, 0x1F, 0x60, 0x1C};
        int base = 23 ^ data.length;
        for (int i = 0; i < data.length; i++) {
            int k = keys[i % keys.length];
            data[i] = (byte) ((data[i] & 0xff) ^ ((base + 5 * i + k) & 0xff));
        }
    }

    private void parseActionPrototype(byte[] payload, boolean live) {
        List<Proto.Field> af = Proto.parse(payload);
        String action = normalizeActionName(Proto.firstString(af, 2, ""));
        byte[] raw = Proto.firstBytes(af, 3);
        if (action.isEmpty() || raw == null) return;
        byte[] data = raw.clone();
        if (live) decodeLiveAction(data);
        lastAction = action;
        List<Proto.Field> f = Proto.parse(data);
        if (f.isEmpty() && data.length > 0) {
            note = "액션 해독 실패: " + action;
            return;
        }

        switch (action) {
            case "ActionNewRound" -> {
                hand.clear(); doras.clear(); Arrays.fill(visible, 0); clearRoundPublic(); selfMelds = 0; roundEnded = false;
                hand.addAll(cleanTiles(Proto.strings(f, 4)));
                String dora = Proto.firstString(f, 5, ""); if (!dora.isEmpty()) doras.add(dora);
                for (String d : Proto.strings(f, 14)) if (!doras.contains(d)) doras.add(d);
                leftTiles = (int) Proto.firstVarint(f, 13, -1);
                for (String t : hand) markVisible(t); for (String d : doras) markVisible(d);
                note = hand.isEmpty() ? "새 국 감지 (손패 대기)" : "새 국 / 손패 추적 시작";
            }
            case "ActionDealTile" -> {
                int seat = (int) Proto.firstVarint(f, 1, -1); String tile = Proto.firstString(f, 2, "");
                leftTiles = (int) Proto.firstVarint(f, 3, leftTiles);
                if (!tile.isEmpty()) {
                    if (selfSeat < 0) { selfSeat = seat; note = "내 좌석 추정: " + seat; }
                    if (seat == selfSeat) { hand.add(tile); markVisible(tile); }
                }
                addDoras(Proto.strings(f, 6));
            }
            case "ActionDiscardTile" -> {
                int seat = (int) Proto.firstVarint(f, 1, -1); String tile = Proto.firstString(f, 2, "");
                boolean declared = Proto.firstVarint(f, 3, 0) != 0 || Proto.firstVarint(f, 9, 0) != 0;
                if (seat >= 0 && seat < 4 && !tile.isEmpty()) rivers[seat].add(Tile.name(Tile.parse(tile)));
                lastDiscardSeat = seat;
                if (!tile.isEmpty()) { if (seat == selfSeat) removeOne(tile); else markVisible(tile); }
                if (declared && seat >= 0 && seat < 4) {
                    riichi[seat] = true;
                    if (seat == selfSeat && !selfRiichiRound) { selfRiichiRound = true; riichis++; }
                    note = seat == selfSeat ? "리치 선언" : "상대 " + seat + " 리치 · 위험도 반영";
                }
                addDoras(Proto.strings(f, 8));
            }
            case "ActionChiPengGang" -> {
                int seat = (int) Proto.firstVarint(f, 1, -1);
                List<String> tiles = cleanTiles(Proto.strings(f, 3)); List<Long> froms = Proto.repeatedUInt(f, 4);
                if (seat == selfSeat) { selfMelds++; if (!selfFuuroRound) { selfFuuroRound = true; fuuros++; } }
                if (froms.size() == tiles.size()) {
                    for (int i = 0; i < tiles.size(); i++) {
                        long origin = froms.get(i);
                        if (origin == seat && seat != selfSeat) markVisible(tiles.get(i));
                        if (seat == selfSeat && origin == selfSeat) removeOne(tiles.get(i));
                    }
                } else if (seat == selfSeat) {
                    int removed = 0; for (String t : tiles) if (removed < 3 && removeOne(t)) removed++;
                } else { for (String t : tiles) markVisible(t); }
            }
            case "ActionAnGangAddGang" -> {
                int seat = (int) Proto.firstVarint(f, 1, -1); String tile = Proto.firstString(f, 3, "");
                int gangType = (int) Proto.firstVarint(f, 2, -1);
                if (seat == selfSeat) { if (gangType == 3) selfMelds++; if (!selfFuuroRound) { selfFuuroRound = true; fuuros++; } }
                if (seat == selfSeat && !tile.isEmpty()) {
                    int normal = Tile.parse(tile), count = 0; for (String h : hand) if (Tile.parse(h) == normal) count++;
                    int remove = count >= 4 ? 4 : Math.min(1, count); for (int i = 0; i < remove; i++) removeOne(tile);
                }
                addDoras(Proto.strings(f, 6));
            }
            case "ActionBaBei" -> {
                int seat = (int) Proto.firstVarint(f, 1, -1); if (seat == selfSeat) removeOne("4z"); addDoras(Proto.strings(f, 6));
            }
            case "ActionHule" -> { parseHule(f); finishRound("화료로 국 종료"); }
            case "ActionNoTile" -> finishRound("유국");
            case "ActionLiuJu" -> finishRound("도중유국");
            default -> { }
        }
    }

    private void parseHule(List<Proto.Field> f) {
        boolean selfWon = false, selfDealt = false;
        for (Proto.Field x : f) {
            if (x.number != 1 || x.wireType != 2 || x.bytes == null) continue;
            List<Proto.Field> h = Proto.parse(x.bytes);
            int winner = (int) Proto.firstVarint(h, 4, -1);
            boolean zimo = Proto.firstVarint(h, 5, 0) != 0;
            if (winner == selfSeat) selfWon = true;
            else if (!zimo && lastDiscardSeat == selfSeat) selfDealt = true;
        }
        if (selfWon) wins++; if (selfDealt) dealIns++;
    }

    private void finishRound(String why) {
        if (!roundEnded) { rounds++; roundEnded = true; }
        note = why;
    }

    private List<String> cleanTiles(List<String> xs) {
        ArrayList<String> out = new ArrayList<>(); for (String s : xs) if (Tile.parse(s) >= 0) out.add(s); return out;
    }
    private void addDoras(List<String> ds) {
        for (String d : ds) if (Tile.parse(d) >= 0 && !doras.contains(d)) { doras.add(d); markVisible(d); }
    }
    private void markVisible(String tile) { int t = Tile.parse(tile); if (t >= 0 && visible[t] < 4) visible[t]++; }
    private boolean removeOne(String tile) {
        int wanted = Tile.parse(tile); if (wanted < 0) return false;
        for (int i = 0; i < hand.size(); i++) if (Tile.parse(hand.get(i)) == wanted) { hand.remove(i); return true; }
        return false;
    }

    private void publish() {
        if (listener == null) return;
        List<String> h = new ArrayList<>(hand);
        Shanten.Analysis a = h.isEmpty() ? null : Shanten.analyzeDiscard(h, visible.clone(), selfMelds);
        ArrayList<DefenseAnalyzer.Opponent> opps = new ArrayList<>();
        StringBuilder os = new StringBuilder();
        int n = Math.max(3, Math.min(4, playerCount));
        for (int seat = 0; seat < n; seat++) {
            if (seat == selfSeat) continue;
            DefenseAnalyzer.Opponent o = new DefenseAnalyzer.Opponent(seat, riichi[seat], new ArrayList<>(rivers[seat]));
            opps.add(o);
            if (os.length() > 0) os.append(" · ");
            os.append("S").append(seat).append(riichi[seat] ? " 리치" : "").append(" 버림").append(rivers[seat].size());
        }
        DefenseAnalyzer.Pick pick = DefenseAnalyzer.choose(a, visible.clone(), opps);
        if (pick.discard != null) {
            for (DefenseAnalyzer.Opponent o : opps) if (o.riichi) {
                int r = DefenseAnalyzer.risk(pick.discard, visible.clone(), List.of(o));
                os.append(" | S").append(o.seat).append("위험").append(r);
            }
        }
        String stats = "국 " + rounds + " · 승 " + wins + " · 방총 " + dealIns + " · 리치 " + riichis + " · 후로 " + fuuros;
        listener.onState(new Snapshot(frames, lastMethod, lastAction, selfSeat, playerCount,
                h, new ArrayList<>(new LinkedHashSet<>(doras)), leftTiles, a, pick, os.toString(), stats, note));
    }
}
