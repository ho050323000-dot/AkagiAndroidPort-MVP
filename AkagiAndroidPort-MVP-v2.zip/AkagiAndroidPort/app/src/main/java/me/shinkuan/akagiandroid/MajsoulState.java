package me.shinkuan.akagiandroid;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

final class MajsoulState {
    interface Listener { void onState(Snapshot s); }

    static final class Snapshot {
        final long frames; final String lastMethod; final String lastAction;
        final int selfSeat; final int playerCount; final List<String> hand; final List<String> doras;
        final int leftTiles; final Shanten.Analysis analysis; final DefenseAnalyzer.Pick pick;
        final AkagiNativeModel.Prediction ai; final AkagiNativeModel.ActionPrediction aiAction; final RateAnalyzer.AgariResult agari;
        final String finalDiscard; final String finalSource; final String lastDiscardTile;
        final String opponents; final String stats; final String note; final String inspector;
        final List<String> callButtons;
        final long historyVersion; final String historyLine;
        Snapshot(long frames, String lastMethod, String lastAction, int selfSeat, int playerCount,
                 List<String> hand, List<String> doras, int leftTiles, Shanten.Analysis analysis,
                 DefenseAnalyzer.Pick pick, AkagiNativeModel.Prediction ai, AkagiNativeModel.ActionPrediction aiAction, RateAnalyzer.AgariResult agari,
                 String finalDiscard, String finalSource, String lastDiscardTile, String opponents, String stats, String note,
                 String inspector, List<String> callButtons, long historyVersion, String historyLine) {
            this.frames=frames; this.lastMethod=lastMethod; this.lastAction=lastAction; this.selfSeat=selfSeat;
            this.playerCount=playerCount; this.hand=hand; this.doras=doras; this.leftTiles=leftTiles;
            this.analysis=analysis; this.pick=pick; this.ai=ai; this.aiAction=aiAction; this.agari=agari;
            this.finalDiscard=finalDiscard; this.finalSource=finalSource; this.lastDiscardTile=lastDiscardTile; this.opponents=opponents;
            this.stats=stats; this.note=note; this.inspector=inspector; this.callButtons=callButtons;
            this.historyVersion=historyVersion; this.historyLine=historyLine;
        }
    }

    private final Map<Integer,String> requestMethods = new HashMap<>();
    private final Map<Integer,Long> requestAccountIds = new HashMap<>();
    private final Listener listener;
    // Legacy Java model is kept only as a no-native fallback. The primary AI is
    // Akagi v3.7.2's original Rust native_bot Engine through JNI.
    private volatile AkagiNativeModel model3, model4;
    private AkagiRustNativeBot rustBot;
    private AkagiRustNativeBot.Decision rustDecision;
    private boolean rustDirty;
    private int rustPlayers = -1;
    private int rustSeat = -1;
    private int pendingRustReachActor = -1;
    private final ArrayList<String> rustDoraMarkers = new ArrayList<>();
    private static final class OperationOffer {
        final int type; final List<String> combinations; final List<String> changeTiles;
        OperationOffer(int type,List<String> combinations,List<String> changeTiles){this.type=type;this.combinations=combinations;this.changeTiles=changeTiles;}
    }
    private final ArrayList<OperationOffer> operationOffers = new ArrayList<>();
    private long frames; private String lastMethod="-", lastAction="-"; private long accountId=-1;
    private int selfSeat=-1, playerCount=4;
    private final ArrayList<String> hand = new ArrayList<>();
    /** Majsoul 'doras' are dora indicators/markers. */
    private final ArrayList<String> doras = new ArrayList<>();
    private final int[] visible = new int[34];
    @SuppressWarnings("unchecked") private final ArrayList<String>[] rivers = new ArrayList[]{new ArrayList<>(),new ArrayList<>(),new ArrayList<>(),new ArrayList<>()};
    @SuppressWarnings("unchecked") private final ArrayList<String>[] meldTiles = new ArrayList[]{new ArrayList<>(),new ArrayList<>(),new ArrayList<>(),new ArrayList<>()};
    private final boolean[] riichi = new boolean[4]; private final String[] riichiTile = new String[4];
    private final boolean[][] postRiichiSafe = new boolean[4][34];
    private final int[] openMelds = new int[4]; private final int[] tedashiAfterCall = new int[4]; private final int[] kitaCount = new int[4];
    private final int[] scores = {25000,25000,25000,25000};
    private int leftTiles=-1, selfMelds=0, lastDiscardSeat=-1;
    private String lastDiscard=null, drawnTile=null;
    private int roundWind=0, dealerSeat=0, honba=0, riichiSticks=0, kyokuIndex=0;
    private boolean roundEnded=true, selfRiichiRound=false, selfFuuroRound=false;
    private int rounds,wins,dealIns,riichis,fuuros,draws,matches,yakumanWins;
    private long winPointsTotal,dealInPointsTotal,winTurnTotal;
    private final int[] rankCounts = new int[4];
    private String note="대기 중";
    private long historyVersion=0; private String historyLine="";

    MajsoulState(Listener listener, AkagiNativeModel model3, AkagiNativeModel model4) {
        this.listener=listener; this.model3=model3; this.model4=model4;
    }

    synchronized void setModels(AkagiNativeModel model3, AkagiNativeModel model4) {
        this.model3 = model3;
        this.model4 = model4;
        if (model3 != null || model4 != null) note = "원본 AI 모델 준비 완료";
        publish();
    }

    synchronized void close() {
        if (rustBot != null) {
            try { rustBot.close(); } catch (Throwable ignored) {}
            rustBot = null;
        }
    }

    synchronized void reset() {
        requestMethods.clear(); requestAccountIds.clear(); operationOffers.clear(); frames=0; lastMethod=lastAction="-"; accountId=-1; selfSeat=-1; playerCount=4;
        hand.clear(); doras.clear(); Arrays.fill(visible,0); clearRoundPublic();
        rounds=wins=dealIns=riichis=fuuros=draws=matches=yakumanWins=0; winPointsTotal=dealInPointsTotal=winTurnTotal=0; Arrays.fill(rankCounts,0); leftTiles=-1; note="대기 중"; roundEnded=true;
        pendingRustReachActor=-1; rustDoraMarkers.clear(); rustDecision=null; rustDirty=false;
        if (rustBot != null) { try { rustBot.close(); } catch (Throwable ignored) {} rustBot=null; }
        rustPlayers=rustSeat=-1;
        publish();
    }

    private void clearRoundPublic() {
        for (int i=0;i<4;i++) { rivers[i].clear(); meldTiles[i].clear(); riichi[i]=false; riichiTile[i]=null; Arrays.fill(postRiichiSafe[i],false); openMelds[i]=0; tedashiAfterCall[i]=0; kitaCount[i]=0; }
        lastDiscardSeat=-1; lastDiscard=null; drawnTile=null; selfRiichiRound=false; selfFuuroRound=false;
    }

    synchronized void onBinary(boolean outbound, byte[] frame) {
        frames++;
        if (frame==null || frame.length<2) { publish(); return; }
        int type=frame[0]&0xff, offset, reqId=-1;
        if (type==1) offset=1;
        else if (type==2 || type==3) { if (frame.length<4) { publish(); return; } reqId=(frame[1]&0xff)|((frame[2]&0xff)<<8); offset=3; }
        else { publish(); return; }
        List<Proto.Field> wf=Proto.parse(Arrays.copyOfRange(frame,offset,frame.length));
        String method=Proto.firstString(wf,1,""); byte[] payload=Proto.firstBytes(wf,2);
        if (type==2) {
            if (!method.isEmpty()) requestMethods.put(reqId,method);
            // A call/pass decision itself may not immediately produce an ActionPrototype.
            // Clear the offered Chi/Pon/Kan UI as soon as the client sends its choice so
            // a stale call recommendation never remains over the next turn.
            if (outbound && (".lq.FastTest.inputOperation".equals(method)
                    || ".lq.FastTest.inputChiPengGang".equals(method))) {
                operationOffers.clear();
                rustDecision = null;
                rustDirty = false;
                note="반응 선택 반영 · 다음 패 갱신 대기";
            }
            if (".lq.FastTest.authGame".equals(method) && payload!=null) {
                long id=Proto.firstVarint(Proto.parse(payload),1,-1); if(id>=0){accountId=id;requestAccountIds.put(reqId,id);note="대국 인증 요청 감지";}
            }
        } else if (type==3) {
            if (method.isEmpty()) method=requestMethods.remove(reqId); if(method==null) method="";
            if(payload!=null){
                if(".lq.FastTest.authGame".equals(method)) parseAuthResponse(reqId,payload);
                else if(".lq.FastTest.syncGame".equals(method)||".lq.FastTest.enterGame".equals(method)) parseGameRestoreResponse(payload);
            }
        }
        if(!method.isEmpty()) lastMethod=method;
        if(".lq.ActionPrototype".equals(method)&&payload!=null) parseActionPrototype(payload,false);
        else if(".lq.NotifyGameEndResult".equals(method)&&payload!=null) parseGameEnd(payload);
        publish();
    }

    private void parseGameRestoreResponse(byte[] payload) {
        byte[] restore=Proto.firstBytes(Proto.parse(payload),4); if(restore==null)return;
        int replayed=0; for(Proto.Field x:Proto.parse(restore)) if(x.number==2&&x.wireType==2&&x.bytes!=null){parseActionPrototype(x.bytes,true);replayed++;}
        if(replayed>0) note="대국 복구 완료 · 액션 "+replayed+"개 재생";
    }

    private static void wtfDecode(byte[] data) {
        final int[] keys={0x84,0x5E,0x4E,0x42,0x39,0xA2,0x1F,0x60,0x1C}; int base=23^data.length;
        for(int i=0;i<data.length;i++) data[i]=(byte)((data[i]&0xff)^((base+5*i+keys[i%keys.length])&0xff));
    }

    private void parseAuthResponse(int reqId, byte[] payload) {
        Long mappedId=requestAccountIds.remove(reqId); long id=mappedId==null?accountId:mappedId; if(id>=0)accountId=id;
        List<Proto.Field> fs=Proto.parse(payload); List<Long> seats=Proto.repeatedUInt(fs,3);
        if(!seats.isEmpty())playerCount=Math.max(3,Math.min(4,seats.size()));
        if(accountId>=0&&!seats.isEmpty()) for(int i=0;i<seats.size();i++) if(seats.get(i)==accountId){
            selfSeat=i; note="내 좌석 확인: "+i+" / "+playerCount+"인";
            ensureRustBot(true);
            return;
        }
    }


    private boolean ensureRustBot(boolean emitStartGame) {
        if (!AkagiRustNativeBot.isAvailable() || selfSeat < 0) return false;
        int n = playerCount == 3 ? 3 : 4;
        if (rustBot == null || !rustBot.ready() || rustPlayers != n || rustSeat != selfSeat) {
            if (rustBot != null) try { rustBot.close(); } catch (Throwable ignored) {}
            rustBot = new AkagiRustNativeBot(n, selfSeat);
            rustPlayers = n;
            rustSeat = selfSeat;
            rustDecision = null;
            rustDirty = false;
            pendingRustReachActor = -1;
            rustDoraMarkers.clear();
            if (!rustBot.ready()) {
                rustBot = null;
                note = "Akagi 원본 Rust AI 로드 실패 · 보조 분석 사용";
                return false;
            }
            note = "Akagi 3.7.2 원본 Rust AI 준비 완료";
            emitStartGame = true;
        }
        if (emitStartGame) rustStartGame();
        return true;
    }

    private void rustStartGame() {
        if (rustBot == null || !rustBot.ready() || selfSeat < 0) return;
        try {
            JSONObject o = new JSONObject();
            o.put("type", "start_game");
            JSONArray names = new JSONArray();
            for (int i = 0; i < rustPlayers; i++) names.put("");
            o.put("names", names);
            o.put("id", selfSeat);
            o.put("num_players", rustPlayers);
            feedRust(o);
        } catch (Throwable t) {
            android.util.Log.e("AkagiRustBot", "start_game build failed", t);
        }
    }

    private void resetRustForRound() {
        if (!ensureRustBot(false)) return;
        rustBot.reset();
        rustDecision = null;
        rustDirty = false;
        pendingRustReachActor = -1;
        rustDoraMarkers.clear();
        rustStartGame();
    }

    private void feedRust(JSONObject event) {
        if (rustBot == null || !rustBot.ready() || event == null) return;
        if (rustBot.feed(event.toString())) rustDirty = true;
    }

    private void feedRustSimple(String type, int actor, String pai) {
        try {
            JSONObject o = new JSONObject().put("type", type).put("actor", actor);
            if (pai != null) o.put("pai", pai);
            feedRust(o);
        } catch (Throwable t) {
            android.util.Log.e("AkagiRustBot", "event build failed: " + type, t);
        }
    }

    private void feedRustReachAcceptedIfPending(String nextAction) {
        if (pendingRustReachActor < 0) return;
        if ("ActionHule".equals(nextAction)) {
            // Ron on the declaration tile voids the riichi acceptance.
            pendingRustReachActor = -1;
            return;
        }
        try {
            feedRust(new JSONObject().put("type", "reach_accepted").put("actor", pendingRustReachActor));
        } catch (Throwable ignored) {}
        pendingRustReachActor = -1;
    }

    private static String rustWind(int chang) {
        return switch (chang) { case 1 -> "S"; case 2 -> "W"; case 3 -> "N"; default -> "E"; };
    }

    private JSONArray rustScores() {
        JSONArray a = new JSONArray();
        int n = playerCount == 3 ? 3 : 4;
        for (int i = 0; i < n; i++) a.put(scores[i]);
        return a;
    }

    private JSONArray rustUnknownHand() {
        JSONArray a = new JSONArray();
        for (int i = 0; i < 13; i++) a.put("?");
        return a;
    }

    private JSONArray rustHand(List<String> xs, int limit) {
        JSONArray a = new JSONArray();
        if (xs == null) return a;
        for (int i = 0; i < Math.min(limit, xs.size()); i++) a.put(AkagiRustNativeBot.msToMjai(xs.get(i)));
        return a;
    }

    private void feedRustNewRound(List<String> rawHand, String firstDora) {
        resetRustForRound();
        if (rustBot == null || !rustBot.ready()) return;
        try {
            int n = playerCount == 3 ? 3 : 4;
            JSONArray tehais = new JSONArray();
            boolean dealerSelf = selfSeat == dealerSeat;
            for (int seat = 0; seat < n; seat++) {
                if (seat == selfSeat) tehais.put(rustHand(rawHand, 13));
                else tehais.put(rustUnknownHand());
            }
            String marker = AkagiRustNativeBot.msToMjai(firstDora);
            if (marker == null || marker.isEmpty() || "?".equals(marker)) marker = "1m";
            JSONObject start = new JSONObject()
                    .put("type", "start_kyoku")
                    .put("bakaze", rustWind(roundWind))
                    .put("dora_marker", marker)
                    .put("kyoku", dealerSeat + 1)
                    .put("honba", honba)
                    .put("kyotaku", riichiSticks)
                    .put("oya", dealerSeat)
                    .put("scores", rustScores())
                    .put("tehais", tehais)
                    .put("num_players", n);
            feedRust(start);
            rustDoraMarkers.add(marker);

            String draw;
            if (dealerSelf && rawHand != null && rawHand.size() >= 14) draw = AkagiRustNativeBot.msToMjai(rawHand.get(13));
            else draw = "?";
            feedRust(new JSONObject().put("type", "tsumo").put("actor", dealerSeat).put("pai", draw));
        } catch (Throwable t) {
            android.util.Log.e("AkagiRustBot", "new round mapping failed", t);
        }
    }

    private void syncRustDoras(List<String> serverDoras) {
        if (rustBot == null || serverDoras == null) return;
        for (String d : serverDoras) {
            String m = AkagiRustNativeBot.msToMjai(d);
            if (m == null || m.isEmpty() || "?".equals(m)) continue;
            if (!rustDoraMarkers.contains(m)) {
                try { feedRust(new JSONObject().put("type", "dora").put("dora_marker", m)); }
                catch (Throwable ignored) {}
                rustDoraMarkers.add(m);
            }
        }
    }

    private static JSONArray jsonTiles(List<String> xs) {
        JSONArray a = new JSONArray();
        if (xs != null) for (String x : xs) a.put(AkagiRustNativeBot.msToMjai(x));
        return a;
    }

    private List<String> matchingTiles(List<String> source, String tile, int count) {
        ArrayList<String> out = new ArrayList<>();
        int wanted = Tile.parse(tile);
        if (source != null) for (String x : source) {
            if (Tile.parse(x) == wanted && out.size() < count) out.add(x);
        }
        while (out.size() < count) out.add(tile);
        return out;
    }

    private void feedRustMeld(int seat, int meldType, List<String> tiles, List<Long> froms) {
        if (rustBot == null || seat < 0 || tiles == null || tiles.isEmpty()) return;
        try {
            int target = -1;
            String called = null;
            ArrayList<String> consumed = new ArrayList<>();
            for (int i = 0; i < tiles.size(); i++) {
                long origin = i < froms.size() ? froms.get(i) : seat;
                if (origin != seat && target < 0) { target = (int) origin; called = tiles.get(i); }
                else consumed.add(tiles.get(i));
            }
            if (target < 0) target = lastDiscardSeat >= 0 ? lastDiscardSeat : 0;
            if (called == null) called = lastDiscard == null ? tiles.get(0) : lastDiscard;
            String type = switch (meldType) { case 0 -> "chi"; case 1 -> "pon"; case 2 -> "daiminkan"; default -> ""; };
            if (type.isEmpty()) return;
            int need = meldType == 2 ? 3 : 2;
            if (consumed.size() < need) consumed = new ArrayList<>(matchingTiles(hand, called, need));
            if (consumed.size() > need) consumed = new ArrayList<>(consumed.subList(0, need));
            JSONObject o = new JSONObject().put("type", type).put("actor", seat).put("target", target)
                    .put("pai", AkagiRustNativeBot.msToMjai(called)).put("consumed", jsonTiles(consumed));
            feedRust(o);
        } catch (Throwable t) {
            android.util.Log.e("AkagiRustBot", "meld mapping failed", t);
        }
    }

    private void feedRustKan(int seat, int gangType, String tile) {
        if (rustBot == null || seat < 0 || tile == null || tile.isEmpty()) return;
        try {
            if (gangType == 3) {
                List<String> four = matchingTiles(seat == selfSeat ? hand : meldTiles[seat], tile, 4);
                if (four.stream().allMatch(Tile::isRed)) {
                    String normal = "5" + tile.charAt(1);
                    four = new ArrayList<>(List.of(tile, normal, normal, normal));
                }
                feedRust(new JSONObject().put("type", "ankan").put("actor", seat).put("consumed", jsonTiles(four)));
            } else if (gangType == 2) {
                List<String> three = matchingTiles(meldTiles[seat], tile, 3);
                // Akagi upstream rule: if the added tile is red, the prior pon
                // was three normals; otherwise a five-pon contains the red copy.
                int t = Tile.parse(tile);
                if (three.stream().allMatch(x -> x.equals(tile)) && t >= 0 && t < 27 && t % 9 == 4) {
                    String normal = "5" + tile.charAt(1);
                    if (Tile.isRed(tile)) three = new ArrayList<>(List.of(normal, normal, normal));
                    else three = new ArrayList<>(List.of("0" + tile.charAt(1), normal, normal));
                }
                feedRust(new JSONObject().put("type", "kakan").put("actor", seat)
                        .put("pai", AkagiRustNativeBot.msToMjai(tile)).put("consumed", jsonTiles(three)));
            }
        } catch (Throwable t) {
            android.util.Log.e("AkagiRustBot", "kan mapping failed", t);
        }
    }

    private void parseActionPrototype(byte[] payload, boolean restoreAction) {
        List<Proto.Field> af=Proto.parse(payload); String action=Proto.firstString(af,2,""); byte[] data=Proto.firstBytes(af,3);
        if(action.isEmpty()||data==null)return; lastAction=action; byte[] decoded=data.clone(); if(!restoreAction)wtfDecode(decoded); List<Proto.Field> f=Proto.parse(decoded);
        feedRustReachAcceptedIfPending(action);
        operationOffers.clear();
        int opTag = switch(action){
            case "ActionNewRound" -> 7;
            case "ActionDealTile", "ActionDiscardTile", "ActionAnGangAddGang", "ActionBaBei" -> 4;
            case "ActionChiPengGang" -> 6;
            default -> -1;
        };
        if(opTag>0)captureOperations(f,opTag);
        switch(action){
            case "ActionNewRound" -> {
                hand.clear();doras.clear();Arrays.fill(visible,0);clearRoundPublic();selfMelds=0;roundEnded=false;
                roundWind=(int)Proto.firstVarint(f,1,0); dealerSeat=(int)Proto.firstVarint(f,2,0); honba=(int)Proto.firstVarint(f,3,0);
                hand.addAll(cleanTiles(Proto.strings(f,4))); String dora=Proto.firstString(f,5,""); if(!dora.isEmpty())doras.add(dora);
                List<Integer> sc=int32s(f,6); for(int i=0;i<Math.min(sc.size(),4);i++)scores[i]=sc.get(i);
                riichiSticks=(int)Proto.firstVarint(f,8,0); for(String d:Proto.strings(f,14))if(!doras.contains(d))doras.add(d);
                leftTiles=(int)Proto.firstVarint(f,13,-1); kyokuIndex=roundWind*Math.max(3,playerCount)+dealerSeat;
                if(selfSeat==dealerSeat&&hand.size()%3==2&&!hand.isEmpty())drawnTile=hand.get(hand.size()-1);
                for(String t:hand)markVisible(t);for(String d:doras)markVisible(d);
                String firstDora = doras.isEmpty() ? "1m" : doras.get(0);
                feedRustNewRound(new ArrayList<>(hand), firstDora);
                if (doras.size() > 1) syncRustDoras(new ArrayList<>(doras));
                note=hand.isEmpty()?"새 국 감지 (손패 대기)":"새 국 / Akagi 원본 Rust AI 분석";
            }
            case "ActionDealTile" -> {
                int seat=(int)Proto.firstVarint(f,1,-1);String tile=Proto.firstString(f,2,"");leftTiles=(int)Proto.firstVarint(f,3,leftTiles);lastDiscard=null;
                if(!tile.isEmpty()){if(selfSeat<0){selfSeat=seat;note="내 좌석 추정: "+seat;ensureRustBot(true);}if(seat==selfSeat){hand.add(tile);markVisible(tile);drawnTile=tile;}}
                List<String> actionDoras = Proto.strings(f,6);
                syncRustDoras(actionDoras);
                try {
                    String rp = (seat==selfSeat && !tile.isEmpty()) ? AkagiRustNativeBot.msToMjai(tile) : "?";
                    feedRust(new JSONObject().put("type","tsumo").put("actor",seat).put("pai",rp));
                } catch (Throwable ignored) {}
                addDoras(actionDoras);
            }
            case "ActionDiscardTile" -> {
                int seat=(int)Proto.firstVarint(f,1,-1);String tile=Proto.firstString(f,2,"");boolean declared=Proto.firstVarint(f,3,0)!=0||Proto.firstVarint(f,9,0)!=0;boolean tsumogiri=Proto.firstVarint(f,5,0)!=0;
                List<String> actionDoras = Proto.strings(f,8);
                syncRustDoras(actionDoras);
                try {
                    if (declared) feedRust(new JSONObject().put("type","reach").put("actor",seat));
                    if (!tile.isEmpty()) feedRust(new JSONObject().put("type","dahai").put("actor",seat)
                            .put("pai",AkagiRustNativeBot.msToMjai(tile)).put("tsumogiri",tsumogiri));
                    if (declared) pendingRustReachActor = seat;
                } catch (Throwable t) { android.util.Log.e("AkagiRustBot","discard mapping failed",t); }
                if(seat>=0&&seat<4&&!tile.isEmpty()){rivers[seat].add(Tile.name(Tile.parse(tile)));if(!tsumogiri)tedashiAfterCall[seat]++;}
                int discarded34=Tile.parse(tile);
                if(discarded34>=0){for(int op=0;op<Math.min(playerCount,4);op++)if(op!=seat&&riichi[op])postRiichiSafe[op][discarded34]=true;}
                lastDiscardSeat=seat;lastDiscard=tile;if(!tile.isEmpty()){if(seat==selfSeat){removeOne(tile);drawnTile=null;}else markVisible(tile);}
                if(declared&&seat>=0&&seat<4){riichi[seat]=true;riichiTile[seat]=tile;riichiSticks++;if(seat==selfSeat&&!selfRiichiRound){selfRiichiRound=true;riichis++;}note=seat==selfSeat?"리치 선언":"상대 "+seat+" 리치 · 위험도 반영";}
                addDoras(actionDoras); List<Integer> sc=int32s(f,13); for(int i=0;i<Math.min(sc.size(),4);i++)scores[i]=sc.get(i);
            }
            case "ActionChiPengGang" -> {
                int seat=(int)Proto.firstVarint(f,1,-1);int meldType=(int)Proto.firstVarint(f,2,-1);List<String> tiles=cleanTiles(Proto.strings(f,3));List<Long> froms=Proto.repeatedUInt(f,4);
                feedRustMeld(seat, meldType, tiles, froms);
                if(seat>=0&&seat<4){openMelds[seat]++;tedashiAfterCall[seat]=0;meldTiles[seat].addAll(tiles);}
                if(seat==selfSeat){selfMelds++;if(!selfFuuroRound){selfFuuroRound=true;fuuros++;}}
                if(froms.size()==tiles.size()){
                    for(int i=0;i<tiles.size();i++){
                        long origin=froms.get(i);
                        if(origin==seat&&seat==selfSeat)removeOne(tiles.get(i));
                        else if(origin==seat&&seat!=selfSeat)markVisible(tiles.get(i));
                    }
                } else if(seat==selfSeat){int removed=0;for(String t:tiles)if(removed<3&&removeOne(t))removed++;}
                else {for(String t:tiles)markVisible(t);}
            }
            case "ActionAnGangAddGang" -> {
                int seat=(int)Proto.firstVarint(f,1,-1);String tile=Proto.firstString(f,3,"");int gangType=(int)Proto.firstVarint(f,2,-1);
                feedRustKan(seat, gangType, tile);
                syncRustDoras(Proto.strings(f,6));
                if(seat>=0&&seat<4){tedashiAfterCall[seat]=0;int copies=gangType==3?4:1;for(int i=0;i<copies;i++)meldTiles[seat].add(tile);if(seat!=selfSeat&&!tile.isEmpty())for(int i=0;i<copies;i++)markVisible(tile);}
                if(seat==selfSeat){if(gangType==3)selfMelds++;if(!selfFuuroRound){selfFuuroRound=true;fuuros++;}if(!tile.isEmpty()){int normal=Tile.parse(tile),count=0;for(String h:hand)if(Tile.parse(h)==normal)count++;int remove=count>=4?4:Math.min(1,count);for(int i=0;i<remove;i++)removeOne(tile);}}
                addDoras(Proto.strings(f,6));
            }
            case "ActionBaBei" -> {
                int seat=(int)Proto.firstVarint(f,1,-1);syncRustDoras(Proto.strings(f,6));
                try { feedRust(new JSONObject().put("type","kita").put("actor",seat).put("pai","N")); } catch (Throwable ignored) {}
                if(seat>=0&&seat<4)kitaCount[seat]++;if(seat==selfSeat)removeOne("4z");else if(seat>=0)markVisible("4z");addDoras(Proto.strings(f,6));
            }
            case "ActionHule" -> {
                try {
                    for(Proto.Field x:f){
                        if(x.number!=1||x.wireType!=2||x.bytes==null)continue;
                        List<Proto.Field> h=Proto.parse(x.bytes);int winner=(int)Proto.firstVarint(h,4,-1);boolean zimo=Proto.firstVarint(h,5,0)!=0;
                        int target=zimo?winner:(lastDiscardSeat>=0?lastDiscardSeat:winner);
                        feedRust(new JSONObject().put("type","hora").put("actor",winner).put("target",target));
                    }
                    feedRust(new JSONObject().put("type","end_kyoku"));
                } catch (Throwable ignored) {}
                parseHule(f);finishRound("화료로 국 종료");
            }
            case "ActionNoTile" -> {
                try { feedRust(new JSONObject().put("type","ryukyoku")); feedRust(new JSONObject().put("type","end_kyoku")); } catch (Throwable ignored) {}
                draws++;finishRound("유국");
            }
            case "ActionLiuJu" -> {
                try { feedRust(new JSONObject().put("type","ryukyoku")); feedRust(new JSONObject().put("type","end_kyoku")); } catch (Throwable ignored) {}
                draws++;finishRound("도중유국");
            }
            default -> {}
        }
    }

    private void parseHule(List<Proto.Field> f){
        boolean selfWon=false,selfDealt=false;
        for(Proto.Field x:f){
            if(x.number!=1||x.wireType!=2||x.bytes==null)continue;
            List<Proto.Field> h=Proto.parse(x.bytes);
            int winner=(int)Proto.firstVarint(h,4,-1); boolean zimo=Proto.firstVarint(h,5,0)!=0;
            long pointRong=Proto.firstVarint(h,15,0); long pointSum=Proto.firstVarint(h,19,0); boolean yakuman=Proto.firstVarint(h,10,0)!=0;
            if(winner==selfSeat){
                selfWon=true; long gained=pointSum>0?pointSum:pointRong; if(gained>0)winPointsTotal+=gained;
                winTurnTotal += selfSeat>=0&&selfSeat<4 ? rivers[selfSeat].size()+1L : 0L;
                if(yakuman)yakumanWins++;
            } else if(!zimo&&lastDiscardSeat==selfSeat){
                selfDealt=true; if(pointRong>0)dealInPointsTotal+=pointRong;
            }
        }
        if(selfWon)wins++; if(selfDealt)dealIns++;
    }

    private void finishRound(String why){if(!roundEnded){rounds++;roundEnded=true;historyVersion++;historyLine="국 "+rounds+" · "+why+" · 승"+wins+" 방총"+dealIns+" 리치"+riichis+" 후로"+fuuros;}note=why;}

    private void parseGameEnd(byte[] payload){
        try { feedRust(new JSONObject().put("type","end_game")); } catch (Throwable ignored) {}
        rustDecision=null;
        byte[] result=Proto.firstBytes(Proto.parse(payload),1);if(result==null)return;ArrayList<int[]> ps=new ArrayList<>();
        for(Proto.Field x:Proto.parse(result))if(x.number==1&&x.wireType==2&&x.bytes!=null){List<Proto.Field> pf=Proto.parse(x.bytes);ps.add(new int[]{(int)Proto.firstVarint(pf,1,-1),(int)Proto.firstVarint(pf,2,0)});}
        ps.sort((a,b)->Integer.compare(b[1],a[1]));int rank=0,point=0;for(int i=0;i<ps.size();i++)if(ps.get(i)[0]==selfSeat){rank=i+1;point=ps.get(i)[1];}
        matches++; if(rank>=1&&rank<=4)rankCounts[rank-1]++;
        historyVersion++;historyLine="대국 종료 · "+(rank>0?rank+"위 · ":"")+"점수 "+point+" · "+statsSummary();note=historyLine;
    }

    private void captureOperations(List<Proto.Field> actionFields,int tag){
        byte[] list=Proto.firstBytes(actionFields,tag); if(list==null)return;
        List<Proto.Field> lf=Proto.parse(list); int seat=(int)Proto.firstVarint(lf,1,-1);
        if(selfSeat>=0&&seat>=0&&seat!=selfSeat)return;
        for(Proto.Field x:lf){
            if(x.number!=2||x.wireType!=2||x.bytes==null)continue;
            List<Proto.Field> of=Proto.parse(x.bytes); int type=(int)Proto.firstVarint(of,1,0);
            operationOffers.add(new OperationOffer(type,new ArrayList<>(Proto.strings(of,2)),new ArrayList<>(Proto.strings(of,3))));
        }
    }

    private List<AkagiNativeModel.ActionOption> buildActionOptions(AkagiNativeModel model,List<String> h){
        ArrayList<AkagiNativeModel.ActionOption> out=new ArrayList<>();
        if(model==null)return out;
        if(h!=null&&h.size()%3==2){
            java.util.HashSet<Integer> seen=new java.util.HashSet<>();
            for(String t:h){int idx=model.discardActionIndex(t);if(idx>=0&&seen.add(idx))out.add(new AkagiNativeModel.ActionOption(idx,"타패 "+t,t));}
        }
        boolean addPass=false;
        for(OperationOffer o:operationOffers){
            switch(o.type){
                case 1 -> { /* discard options already enumerated */ }
                case 2 -> { // chi: up to three model variants
                    int count=Math.max(1,Math.min(3,o.combinations.size()));
                    for(int i=0;i<count;i++){int idx=model.chiIndex(i);if(idx>=0){String c=o.combinations.isEmpty()?"":o.combinations.get(i);out.add(new AkagiNativeModel.ActionOption(idx,"치"+(c.isEmpty()?"":"("+c+")"),null));}}
                    addPass=true;
                }
                case 3 -> {out.add(new AkagiNativeModel.ActionOption(model.ponIndex(),"퐁",null));addPass=true;}
                case 4 -> { // ankan
                    int[] cnt=Tile.counts(h);for(int t=0;t<34;t++)if(cnt[t]>=4){String tile=Tile.name(t);int idx=model.kanIndex(tile);if(idx>=0)out.add(new AkagiNativeModel.ActionOption(idx,"암깡 "+tile,null));}
                }
                case 5 -> {String tile=lastDiscard;int idx=model.kanIndex(tile);if(idx>=0)out.add(new AkagiNativeModel.ActionOption(idx,"대명깡 "+tile,null));addPass=true;}
                case 6 -> { // kakan - use server hints first, then own hand/meld overlap
                    java.util.LinkedHashSet<String> ts=new java.util.LinkedHashSet<>();ts.addAll(o.changeTiles);
                    for(String c:o.combinations)for(String q:c.split("\\|"))if(Tile.parse(q)>=0)ts.add(q);
                    if(ts.isEmpty())for(String q:h)if(selfSeat>=0&&containsTile(meldTiles[selfSeat],q))ts.add(q);
                    for(String tile:ts){int idx=model.kanIndex(tile);if(idx>=0)out.add(new AkagiNativeModel.ActionOption(idx,"가깡 "+tile,null));}
                }
                case 7 -> out.add(new AkagiNativeModel.ActionOption(model.riichiIndex(),"리치",null));
                case 8 -> out.add(new AkagiNativeModel.ActionOption(model.agariIndex(),"쯔모",null));
                case 9 -> {out.add(new AkagiNativeModel.ActionOption(model.agariIndex(),"론",null));addPass=true;}
                case 10 -> out.add(new AkagiNativeModel.ActionOption(model.kyushuIndex(),"구종구패",null));
                case 11 -> {int idx=model.kitaIndex();if(idx>=0)out.add(new AkagiNativeModel.ActionOption(idx,"북빼기",null));}
                default -> {}
            }
        }
        if(addPass)out.add(new AkagiNativeModel.ActionOption(model.passIndex(),"패스",null));
        return out;
    }
    private static boolean containsTile(List<String> xs,String tile){int t=Tile.parse(tile);if(t<0)return false;for(String x:xs)if(Tile.parse(x)==t)return true;return false;}

    private List<String> cleanTiles(List<String> xs){ArrayList<String>out=new ArrayList<>();for(String s:xs)if(Tile.parse(s)>=0)out.add(s);return out;}
    private void addDoras(List<String> ds){for(String d:ds)if(Tile.parse(d)>=0&&!doras.contains(d)){doras.add(d);markVisible(d);}}
    private void markVisible(String tile){int t=Tile.parse(tile);if(t>=0&&visible[t]<4)visible[t]++;}
    private boolean removeOne(String tile){int wanted=Tile.parse(tile);if(wanted<0)return false;for(int i=0;i<hand.size();i++)if(Tile.parse(hand.get(i))==wanted){hand.remove(i);return true;}return false;}
    private static List<Integer> int32s(List<Proto.Field> fs,int n){ArrayList<Integer>r=new ArrayList<>();for(long v:Proto.repeatedUInt(fs,n))r.add((int)v);return r;}
    private int totalDiscards(){int n=0;for(int i=0;i<Math.min(playerCount,4);i++)n+=rivers[i].size();return n;}
    private static int pct(int a,int b){return b<=0?0:(int)Math.round(a*100.0/b);}
    private String statsSummary(){
        long avgWin=wins<=0?0:winPointsTotal/wins, avgDeal=dealIns<=0?0:dealInPointsTotal/dealIns, avgTurn=wins<=0?0:winTurnTotal/wins;
        return "국"+rounds+" 승률"+pct(wins,rounds)+"% 방총률"+pct(dealIns,rounds)+"% 리치율"+pct(riichis,rounds)+"% 후로율"+pct(fuuros,rounds)+"% 유국률"+pct(draws,rounds)+"% 평균화료"+avgWin+" 평균방총"+avgDeal+" 평균화료순목"+avgTurn+" 역만"+yakumanWins;
    }

    private List<String> currentCallButtons() {
        boolean chi=false, pon=false, kan=false, reach=false, tsumo=false, ron=false, kyushu=false, kita=false, pass=false;
        for (OperationOffer o : operationOffers) {
            switch (o.type) {
                case 2 -> { chi=true; pass=true; }
                case 3 -> { pon=true; pass=true; }
                case 4 -> kan=true;
                case 5 -> { kan=true; pass=true; }
                case 6 -> kan=true;
                case 7 -> reach=true;
                case 8 -> { tsumo=true; pass=true; }
                case 9 -> { ron=true; pass=true; }
                case 10 -> kyushu=true;
                case 11 -> kita=true;
                default -> { }
            }
        }
        ArrayList<String> out = new ArrayList<>();
        // Match Mahjong Soul's visual left-to-right action ordering. Pass/Skip
        // is always the right-most control in a response window.
        if (chi) out.add("치");
        if (pon) out.add("퐁");
        if (kan) out.add("깡");
        if (reach) out.add("리치");
        if (tsumo) out.add("쯔모");
        if (ron) out.add("론");
        if (kita) out.add("북빼기");
        if (kyushu) out.add("구종구패");
        if (pass) out.add("패스");
        return out;
    }

    private void publish(){
        if(listener==null)return;
        List<String> h=new ArrayList<>(hand);
        Shanten.Analysis a=h.isEmpty()?null:Shanten.analyzeDiscard(h,visible.clone(),selfMelds);
        int n=Math.max(3,Math.min(4,playerCount));

        ArrayList<AkagiRiskAnalyzer.OpponentRisk> exactRisks=new ArrayList<>();
        StringBuilder os=new StringBuilder();
        double maxTenpai=0;
        for(int seat=0;seat<n;seat++){
            if(seat==selfSeat)continue;
            AkagiRiskAnalyzer.OpponentRisk r=AkagiRiskAnalyzer.forOpponent(
                    seat,n,dealerSeat,roundWind,new ArrayList<>(rivers[seat]),postRiichiSafe[seat],riichi[seat],
                    openMelds[seat],tedashiAfterCall[seat],new ArrayList<>(meldTiles[seat]),visible.clone(),new ArrayList<>(doras));
            exactRisks.add(r); maxTenpai=Math.max(maxTenpai,r.tenpaiRate);
            if(os.length()>0)os.append(" · ");
            os.append("S").append(seat).append(riichi[seat]?" 리치":"").append(" 텐파이").append(Math.round(r.tenpaiRate)).append('%');
        }
        double[] mixedRisk=AkagiRiskAnalyzer.mixed(exactRisks);
        DefenseAnalyzer.Pick pick=DefenseAnalyzer.chooseWithMixed(a,mixedRisk);

        RateAnalyzer.AgariResult agari=(a==null||a.waits.isEmpty()||selfSeat<0)
                ?new RateAnalyzer.AgariResult(0,List.of(),false)
                :RateAnalyzer.agariRate(a.waits,visible.clone(),new ArrayList<>(rivers[selfSeat]),doras,n);

        // Primary recommendation path: Akagi v3.7.2's original Rust native_bot.
        // The Rust engine owns observation encoding, legal action enumeration,
        // action codec and Candle inference; Java only maps Majsoul -> mjai.
        if (rustDirty && rustBot != null && rustBot.ready()) {
            try { rustDecision = rustBot.decide(); }
            catch (Throwable t) { android.util.Log.e("AkagiRustBot","decide failed",t); rustDecision=null; }
            rustDirty = false;
        }

        ArrayList<AkagiNativeModel.Candidate> rustDiscards = new ArrayList<>();
        ArrayList<AkagiNativeModel.ActionCandidate> rustActions = new ArrayList<>();
        if (rustDecision != null) {
            int idx = 0;
            for (AkagiRustNativeBot.Candidate c : rustDecision.candidates) {
                float p = (float)c.probability;
                if ("dahai".equals(c.type) && c.tile != null && !c.tile.isEmpty())
                    rustDiscards.add(new AkagiNativeModel.Candidate(c.tile,p,0f));
                rustActions.add(new AkagiNativeModel.ActionCandidate(idx++,c.label,
                        "dahai".equals(c.type)?c.tile:null,p,0f));
            }
        }
        AkagiNativeModel.Prediction ai=new AkagiNativeModel.Prediction(rustDiscards,0);
        AkagiNativeModel.ActionPrediction aiAction=new AkagiNativeModel.ActionPrediction(rustActions,0);

        String finalDiscard=null,source="Akagi원본";
        if (rustDecision != null) {
            if ("dahai".equals(rustDecision.type) && rustDecision.tile != null && !rustDecision.tile.isEmpty()) {
                finalDiscard=rustDecision.tile;
            } else if ("reach".equals(rustDecision.type) && rustDecision.tile != null && !rustDecision.tile.isEmpty()) {
                finalDiscard=rustDecision.tile;
                source="Akagi원본·리치";
            }
        } else if (rustBot == null || !rustBot.ready()) {
            // Only if the native library cannot load, keep a safe analysis-only fallback.
            finalDiscard=pick==null?null:pick.discard;
            source="보조분석";
        }
        if(finalDiscard!=null){
            int ft=Tile.parse(finalDiscard);
            for(AkagiRiskAnalyzer.OpponentRisk r:exactRisks){
                double rr=ft<0?100:r.risk[ft]*r.tenpaiRate/100.0;
                os.append(" | S").append(r.seat).append(" 방총위험").append(Math.round(rr)).append('%');
            }
        }
        String stats=statsSummary()+" · 대국 "+matches+" · 순위 "+Arrays.toString(rankCounts);
        String inspector="좌석="+selfSeat+"/"+n+" 장풍="+roundWind+" 국="+kyokuIndex+" 친="+dealerSeat+" 본장="+honba+" 리치봉="+riichiSticks+
                "\n점수="+Arrays.toString(Arrays.copyOf(scores,n))+"\n후로="+Arrays.toString(Arrays.copyOf(openMelds,n))+" 리치="+Arrays.toString(Arrays.copyOf(riichi,n))+
                "\nAkagi원본Rust="+(rustBot!=null&&rustBot.ready()?"ON":"OFF")+" 가능행동="+operationOffers.size()+"\n마지막="+lastAction+" / "+lastMethod;
        listener.onState(new Snapshot(frames,lastMethod,lastAction,selfSeat,n,h,new ArrayList<>(new LinkedHashSet<>(doras)),leftTiles,a,pick,ai,aiAction,agari,finalDiscard,source,lastDiscard,os.toString(),stats,note,inspector,currentCallButtons(),historyVersion,historyLine));
    }

}
