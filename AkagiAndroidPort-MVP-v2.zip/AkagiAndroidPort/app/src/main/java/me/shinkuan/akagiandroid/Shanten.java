package me.shinkuan.akagiandroid;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

final class Shanten {
    private Shanten() {}

    static int calculate(int[] counts) { return calculate(counts, 0); }

    static int calculate(int[] counts, int fixedMelds) {
        int std = standard(counts.clone(), fixedMelds);
        int chiitoi = fixedMelds == 0 ? chiitoi(counts) : 99;
        int kokushi = fixedMelds == 0 ? kokushi(counts) : 99;
        return Math.min(std, Math.min(chiitoi, kokushi));
    }

    private static int chiitoi(int[] c) {
        int pairs = 0, unique = 0;
        for (int n : c) { if (n > 0) unique++; if (n >= 2) pairs++; }
        return 6 - pairs + Math.max(0, 7 - unique);
    }

    private static int kokushi(int[] c) {
        int[] yaochu = {0,8,9,17,18,26,27,28,29,30,31,32,33};
        int unique = 0; boolean pair = false;
        for (int i : yaochu) { if (c[i] > 0) unique++; if (c[i] > 1) pair = true; }
        return 13 - unique - (pair ? 1 : 0);
    }

    private static int standard(int[] c, int fixedMelds) {
        Best best = new Best(); dfs(c, 0, fixedMelds, 0, 0, best); return best.value;
    }
    private static final class Best { int value = 8; }

    private static void dfs(int[] c, int idx, int meld, int taatsu, int pair, Best best) {
        while (idx < 34 && c[idx] == 0) idx++;
        if (idx >= 34) {
            int t = Math.min(taatsu, 4 - meld);
            best.value = Math.min(best.value, 8 - meld * 2 - t - pair);
            return;
        }
        c[idx]--; dfs(c, idx, meld, taatsu, pair, best); c[idx]++;
        if (c[idx] >= 2) {
            c[idx] -= 2;
            if (pair == 0) dfs(c, idx, meld, taatsu, 1, best);
            dfs(c, idx, meld, taatsu + 1, pair, best);
            c[idx] += 2;
        }
        if (c[idx] >= 3) { c[idx] -= 3; dfs(c, idx, meld + 1, taatsu, pair, best); c[idx] += 3; }
        if (idx < 27) {
            int pos = idx % 9;
            if (pos <= 6 && c[idx + 1] > 0 && c[idx + 2] > 0) {
                c[idx]--; c[idx + 1]--; c[idx + 2]--; dfs(c, idx, meld + 1, taatsu, pair, best); c[idx]++; c[idx + 1]++; c[idx + 2]++;
            }
            if (pos <= 7 && c[idx + 1] > 0) { c[idx]--; c[idx + 1]--; dfs(c, idx, meld, taatsu + 1, pair, best); c[idx]++; c[idx + 1]++; }
            if (pos <= 6 && c[idx + 2] > 0) { c[idx]--; c[idx + 2]--; dfs(c, idx, meld, taatsu + 1, pair, best); c[idx]++; c[idx + 2]++; }
        }
    }

    static Analysis analyzeDiscard(List<String> hand, int[] visible) { return analyzeDiscard(hand, visible, 0); }

    static Analysis analyzeDiscard(List<String> hand, int[] visible, int fixedMelds) {
        int[] base = Tile.counts(hand);
        int current = calculate(base, fixedMelds);
        List<String> waits = waitingTiles(base, visible, fixedMelds);
        if (hand.size() % 3 != 2) return new Analysis(current, null, 0, waits, List.of(), new LinkedHashMap<>(), List.of());

        ArrayList<Candidate> candidates = new ArrayList<>();
        LinkedHashMap<String,Integer> table = new LinkedHashMap<>();
        boolean[] handled = new boolean[34];
        for (String raw : hand) {
            int d = Tile.parse(raw);
            if (d < 0 || handled[d]) continue;
            handled[d] = true;
            int[] after = base.clone(); after[d]--;
            int sh = calculate(after, fixedMelds);
            int ukeire = 0;
            ArrayList<String> improvers = new ArrayList<>();
            for (int t = 0; t < 34; t++) {
                if (after[t] >= 4) continue;
                after[t]++; int next = calculate(after, fixedMelds); after[t]--;
                if (next < sh) {
                    int used = visible == null ? base[t] : Math.max(base[t], visible[t]);
                    int left = Math.max(0, 4 - used);
                    if (left > 0) { ukeire += left; improvers.add(Tile.name(t)); }
                }
            }
            Candidate c = new Candidate(Tile.name(d), sh, ukeire, improvers);
            candidates.add(c); table.put(c.discard, ukeire);
        }
        candidates.sort(Comparator.comparingInt((Candidate c) -> c.shanten).thenComparing((Candidate c) -> -c.ukeire));
        Candidate best = candidates.isEmpty() ? null : candidates.get(0);
        return new Analysis(best == null ? current : best.shanten,
                best == null ? null : best.discard,
                best == null ? 0 : best.ukeire,
                waits,
                best == null ? List.of() : best.improvers,
                table,
                candidates);
    }

    private static List<String> waitingTiles(int[] counts, int[] visible, int fixedMelds) {
        int sh = calculate(counts, fixedMelds);
        if (sh > 0) return List.of();
        ArrayList<String> waits = new ArrayList<>();
        for (int t = 0; t < 34; t++) {
            if (counts[t] >= 4) continue;
            counts[t]++; int next = calculate(counts, fixedMelds); counts[t]--;
            if (next < sh) {
                int seen = visible == null ? counts[t] : Math.max(counts[t], visible[t]);
                if (seen < 4) waits.add(Tile.name(t));
            }
        }
        return waits;
    }

    static final class Candidate {
        final String discard; final int shanten; final int ukeire; final List<String> improvers;
        Candidate(String discard, int shanten, int ukeire, List<String> improvers) {
            this.discard = discard; this.shanten = shanten; this.ukeire = ukeire; this.improvers = improvers;
        }
    }

    static final class Analysis {
        final int shanten; final String discard; final int ukeire;
        final List<String> waits; final List<String> improvers;
        final Map<String,Integer> candidates; final List<Candidate> candidateList;
        Analysis(int shanten, String discard, int ukeire, List<String> waits, List<String> improvers,
                 Map<String,Integer> candidates, List<Candidate> candidateList) {
            this.shanten = shanten; this.discard = discard; this.ukeire = ukeire; this.waits = waits;
            this.improvers = improvers; this.candidates = candidates; this.candidateList = candidateList;
        }
    }
}
