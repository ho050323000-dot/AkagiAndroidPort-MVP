package me.shinkuan.akagiandroid;

import java.util.ArrayList;
import java.util.List;

/**
 * Java port of Akagi V3's statistical deal-in risk core.
 * Uses the same turn/tile risk table, no-chance / double-no-chance wall fixes,
 * dora multiplier, tenpai weighting and ron-point correction.
 */
final class AkagiRiskAnalyzer {
    private AkagiRiskAnalyzer() {}

    static final class OpponentRisk {
        final int seat;
        final double tenpaiRate;
        final double[] risk;
        OpponentRisk(int seat, double tenpaiRate, double[] risk) {
            this.seat = seat; this.tenpaiRate = tenpaiRate; this.risk = risk;
        }
    }

    // TileTypeKind ordinal matches Akagi V3 src/analysis/data/agari.rs.
    private static final int NO_SUJI_5=0, NO_SUJI_46=1, NO_SUJI_37=2, NO_SUJI_28=3, NO_SUJI_19=4,
            HALF_SUJI_5=5, HALF_SUJI_46A=6, HALF_SUJI_46B=7, SUJI_37=8, SUJI_28=9,
            SUJI_19=10, DOUBLE_SUJI_5=11, DOUBLE_SUJI_46=12,
            YAKUHAI_LEFT3=13, YAKUHAI_LEFT2=14, YAKUHAI_LEFT1=15,
            OTAKAZE_LEFT3=16, OTAKAZE_LEFT2=17, OTAKAZE_LEFT1=18;

    private static final double[][] RISK_RATE = {
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {5.7,5.7,5.8,4.7,3.4,2.5,2.5,3.1,5.6,3.8,1.8,0.8,2.6,2.1,1.2,0.5,2.4,1.4,1.2},
            {6.6,6.9,6.3,5.2,4.0,3.5,3.5,4.1,5.3,3.5,1.9,0.8,2.6,2.3,1.2,0.5,2.7,1.3,0.4},
            {7.7,8.0,6.7,5.8,4.6,4.3,4.1,4.9,5.2,3.6,1.8,1.6,2.0,2.4,1.2,0.3,2.6,1.2,0.3},
            {8.5,8.9,7.1,6.2,5.1,4.8,4.7,5.6,5.2,3.8,1.7,1.6,2.0,2.6,1.1,0.2,2.6,1.2,0.2},
            {9.4,9.7,7.5,6.7,5.5,5.3,5.1,6.0,5.3,3.7,1.7,1.7,2.0,2.9,1.2,0.2,2.8,1.2,0.2},
            {10.2,10.5,7.9,7.1,5.9,5.8,5.6,6.4,5.2,3.7,1.7,1.8,2.0,3.2,1.3,0.2,2.9,1.3,0.2},
            {11.0,11.3,8.4,7.5,6.3,6.3,6.1,6.8,5.3,3.7,1.7,2.0,2.1,3.6,1.4,0.2,3.2,1.4,0.2},
            {11.9,12.2,8.9,8.0,6.8,6.9,6.6,7.4,5.3,3.8,1.7,2.1,2.2,4.0,1.6,0.2,3.5,1.6,0.2},
            {12.8,13.1,9.5,8.6,7.4,7.4,7.2,7.9,5.5,3.9,1.8,2.2,2.3,4.6,1.9,0.3,4.0,1.8,0.2},
            {13.8,14.1,10.1,9.2,8.0,8.0,7.8,8.5,5.6,4.0,1.9,2.4,2.4,5.3,2.2,0.3,4.6,2.1,0.3},
            {14.9,15.1,10.8,9.9,8.7,8.7,8.5,9.2,5.7,4.2,2.0,2.5,2.6,6.0,2.6,0.4,5.1,2.5,0.3},
            {16.0,16.3,11.6,10.6,9.4,9.4,9.2,9.9,6.0,4.4,2.2,2.7,2.7,6.8,3.1,0.4,5.1,2.5,0.3},
            {17.2,17.5,12.4,11.4,10.2,10.2,10.0,10.6,6.2,4.6,2.4,3.0,3.0,7.8,3.7,0.5,6.6,3.7,0.5},
            {18.5,18.8,13.3,12.3,11.1,11.0,10.9,11.4,6.6,4.9,2.7,3.2,3.1,8.8,4.4,0.7,7.4,4.4,0.6},
            {19.9,20.1,14.3,13.3,12.0,11.9,11.8,12.3,7.0,5.3,3.0,3.4,3.4,9.9,5.2,0.8,8.4,5.3,0.8},
            {21.3,21.7,15.4,14.3,13.1,12.9,12.8,13.3,7.4,5.7,3.3,3.7,3.6,11.2,6.2,1.0,9.4,6.5,0.9},
            {22.9,23.2,16.6,15.4,14.2,14.0,13.8,14.4,8.0,6.1,3.6,3.9,3.9,12.4,7.3,1.3,10.5,7.7,1.2},
            {24.7,24.9,17.9,16.7,15.4,15.2,15.0,15.6,8.5,6.6,4.0,4.3,4.2,13.9,8.5,1.7,11.8,9.4,1.6},
            {27.5,27.8,20.4,19.1,17.8,17.5,17.5,17.5,9.8,7.4,5.0,5.1,5.1,18.1,12.1,2.8,14.7,12.6,2.1}
    };

    private static final double[] DORA_MULTI = {
            14.9/12.8*78.0/58.0, 15.0/13.1*78.0/58.0, 12.1/9.5*75.0/56.0,
            10.3/8.6*75.0/54.0, 8.9/7.4*77.0/53.0, 9.7/7.4*81.0/60.0,
            8.9/7.2*81.0/60.0, 10.4/7.9*81.0/60.0, 8.0/5.5*75.0/56.0,
            5.5/3.9*81.0/56.0, 3.5/1.8*92.0/58.0, 4.1/2.2*88.0/62.0,
            4.1/2.3*88.0/62.0, 5.2/4.6*96.0/67.0, 2.9/1.9*96.0/67.0,
            1.1/0.3*96.0/67.0, 5.1/4.0*92.0/56.0, 3.0/1.8*92.0/56.0,
            0.8/0.2*92.0/56.0
    };

    static OpponentRisk forOpponent(int seat, int players, int dealerSeat, int roundWind,
                                    List<String> river, boolean[] extraSafe, boolean riichi,
                                    int openMelds, int tedashiAfterCall, List<String> meldTiles,
                                    int[] visible, List<String> doraIndicators) {
        boolean[] safe = new boolean[34];
        if (river != null) for (String s : river) { int t=Tile.parse(s); if(t>=0)safe[t]=true; }
        if (extraSafe != null) for(int i=0;i<34;i++) safe[i] |= extraSafe[i];
        int[] left = new int[34];
        for (int i=0;i<34;i++) left[i]=Math.max(0,4-(visible==null?0:Math.min(4,visible[i])));
        int[] doraTiles = new int[doraIndicators == null ? 0 : doraIndicators.size()];
        for(int i=0;i<doraTiles.length;i++){int ind=Tile.parse(doraIndicators.get(i));doraTiles[i]=ind<0?-1:Tile.nextDora34(ind,players);}
        int seatWind=(seat-dealerSeat+players)%players;
        double[] risk = baseRisk(river==null?0:river.size(),safe,left,doraTiles,27+Math.min(3,roundWind),27+Math.min(3,seatWind));

        double tenpai=RateAnalyzer.tenpaiRate(openMelds,river==null?0:river.size(),tedashiAfterCall,riichi,players);
        int openDora=0;
        if(meldTiles!=null)for(String m:meldTiles){int t=Tile.parse(m);if(t>=0&&contains(doraTiles,t))openDora++;}
        double point=riichi?5172.0:(openMelds>0?openRonPoint(openDora):4536.0);
        double pointMul=point/5172.0;
        for(int i=0;i<34;i++)risk[i]*=pointMul;
        return new OpponentRisk(seat,tenpai,risk);
    }

    static double[] mixed(List<OpponentRisk> opponents){
        double[] out=new double[34];
        if(opponents==null)return out;
        for(OpponentRisk op:opponents){
            if(op.tenpaiRate<=15.0)continue;
            for(int i=0;i<34;i++){
                double weighted=op.risk[i]*op.tenpaiRate/100.0;
                out[i]=compose(out[i],weighted);
            }
        }
        return out;
    }

    static double riskOf(String tile,double[] mixed){int t=Tile.parse(tile);return t<0||mixed==null?100.0:mixed[t];}

    private static double[] baseRisk(int turns, boolean[] safe, int[] left, int[] doraTiles, int bakaze, int jikaze){
        double[] risk=new double[34]; boolean[] low=calcLowRisk(safe,left); int turn=Math.max(1,Math.min(19,turns));
        for(int suit=0;suit<3;suit++){
            int base=suit*9;
            for(int j=0;j<9;j++){
                int idx=base+j, kind;
                if(j<=2){kind=tileKind(j,low[idx+3]?1:0);risk[idx]=rate(turn,kind)*doraMul(idx,kind,doraTiles);if(j==0&&safe[idx+3]&&left[idx]==0)risk[idx]=0;}
                else if(j<=5){int pat=(low[idx-3]?2:0)|(low[idx+3]?1:0);kind=tileKind(j,pat);risk[idx]=rate(turn,kind)*doraMul(idx,kind,doraTiles);}
                else {kind=tileKind(j,low[idx-3]?1:0);risk[idx]=rate(turn,kind)*doraMul(idx,kind,doraTiles);if(j==8&&safe[idx-3]&&left[idx]==0)risk[idx]=0;}
            }
            if(left[base+4]==0){risk[base+2]=rate(turn,SUJI_37)*doraMul(base+2,SUJI_37,doraTiles);risk[base+6]=rate(turn,SUJI_37)*doraMul(base+6,SUJI_37,doraTiles);}
        }
        for(int i=27;i<34;i++){
            int lc=left[i]; if(lc==0){risk[i]=0;continue;}
            boolean yakuhai=i==bakaze||i==jikaze||i>=31;
            int kind;
            if(yakuhai)kind=lc<=1?YAKUHAI_LEFT1:(lc==2?YAKUHAI_LEFT2:YAKUHAI_LEFT3);
            else kind=lc<=1?OTAKAZE_LEFT1:(lc==2?OTAKAZE_LEFT2:OTAKAZE_LEFT3);
            risk[i]=rate(turn,kind)*doraMul(i,kind,doraTiles);
        }
        for(int idx:noChance(left)){
            int pos=idx%9+1,kind;double mul=1.0;
            if(pos==1||pos==9)kind=SUJI_19;else if(pos==2||pos==8){kind=SUJI_19;mul=1.1;}else if(pos==3||pos==7)kind=SUJI_28;else if(pos==4||pos==6)kind=DOUBLE_SUJI_46;else kind=DOUBLE_SUJI_5;
            risk[idx]=rate(turn,kind)*mul*doraMul(idx,kind,doraTiles);
        }
        for(int idx:doubleNoChanceWithDiscards(left,safe)){
            if(left[idx]==0){risk[idx]=0;continue;}int kind=SUJI_19;risk[idx]=rate(turn,kind)*doraMul(idx,kind,doraTiles);int pos=idx%9;if(pos>0&&pos<8)risk[idx]*=1.1;
        }
        for(int i=0;i<34;i++)if(safe[i])risk[i]=0;
        return risk;
    }

    private static boolean[] calcLowRisk(boolean[] safe,int[] left){
        boolean[] low=new boolean[27];for(int i=0;i<27;i++)low[i]=safe[i];
        for(int s=0;s<3;s++){int b=s*9;if(left[b+1]==0)low[b]=true;if(left[b+2]==0){low[b]=true;low[b+1]=true;}if(left[b+3]==0){low[b+1]=true;low[b+2]=true;}if(left[b+5]==0){low[b+6]=true;low[b+7]=true;}if(left[b+6]==0){low[b+7]=true;low[b+8]=true;}if(left[b+7]==0)low[b+8]=true;}
        return low;
    }

    private static int tileKind(int pos,int pattern){
        return switch(pos){
            case 0,8 -> pattern==0?NO_SUJI_19:SUJI_19;
            case 1,7 -> pattern==0?NO_SUJI_28:SUJI_28;
            case 2,6 -> pattern==0?NO_SUJI_37:SUJI_37;
            case 3 -> switch(pattern){case 0->NO_SUJI_46;case 1->HALF_SUJI_46B;case 2->HALF_SUJI_46A;default->DOUBLE_SUJI_46;};
            case 4 -> pattern==0?NO_SUJI_5:(pattern==3?DOUBLE_SUJI_5:HALF_SUJI_5);
            case 5 -> switch(pattern){case 0->NO_SUJI_46;case 1->HALF_SUJI_46A;case 2->HALF_SUJI_46B;default->DOUBLE_SUJI_46;};
            default -> NO_SUJI_5;
        };
    }
    private static double rate(int turn,int kind){return RISK_RATE[Math.max(1,Math.min(19,turn))][kind];}
    private static double doraMul(int tile,int kind,int[] dora){double m=1;for(int d:dora)if(d==tile)m*=DORA_MULTI[kind];return m;}
    private static boolean contains(int[] xs,int x){for(int v:xs)if(v==x)return true;return false;}
    private static double openRonPoint(int count){double p=3000;for(int i=0;i<Math.min(3,count);i++)p*=1.4;for(int i=0;i<Math.min(2,Math.max(0,count-3));i++)p*=1.3;return p;}
    private static double compose(double a,double b){return a+b-a*b/100.0;}

    private static List<Integer> noChance(int[] left){
        ArrayList<Integer> out=new ArrayList<>();
        for(int s=0;s<3;s++){int b=s*9;
            for(int j=0;j<3;j++){int i=b+j;if(left[i+1]==0||left[i+2]==0)out.add(i);}
            for(int j=3;j<6;j++){int i=b+j;if((left[i-2]==0||left[i-1]==0)&&(left[i+1]==0||left[i+2]==0))out.add(i);}
            for(int j=6;j<9;j++){int i=b+j;if(left[i-2]==0||left[i-1]==0)out.add(i);}
        }return out;
    }
    private static List<Integer> doubleNoChance(int[] left){
        ArrayList<Integer> out=new ArrayList<>();for(int s=0;s<3;s++){int b=s*9;
            if(left[b+1]==0||left[b+2]==0)out.add(b);
            if(left[b+2]==0||(left[b]==0&&left[b+3]==0))out.add(b+1);
            for(int j=2;j<=6;j++){int i=b+j;boolean a=left[i-2]==0&&left[i+1]==0,b1=left[i-1]==0&&left[i+1]==0,c=left[i-1]==0&&left[i+2]==0;if(a||b1||c)out.add(i);}
            if(left[b+6]==0||(left[b+5]==0&&left[b+8]==0))out.add(b+7);
            if(left[b+6]==0||left[b+7]==0)out.add(b+8);
        }return out;
    }
    private static List<Integer> doubleNoChanceWithDiscards(int[] left,boolean[] safe){
        ArrayList<Integer> out=new ArrayList<>(doubleNoChance(left));for(int s=0;s<3;s++){int b=s*9;
            for(int j=1;j<3;j++){int i=b+j;if(left[i-1]==0&&safe[i+3])out.add(i);}
            for(int j=3;j<6;j++){int i=b+j;if((left[i-1]==0&&safe[i+3])||(left[i+1]==0&&safe[i-3]))out.add(i);}
            for(int j=6;j<8;j++){int i=b+j;if(left[i+1]==0&&safe[i-3])out.add(i);}
        }return out;
    }
}
