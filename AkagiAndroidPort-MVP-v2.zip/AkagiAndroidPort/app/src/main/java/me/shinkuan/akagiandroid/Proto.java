package me.shinkuan.akagiandroid;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

final class Proto {
    private Proto() {}

    static final class Field {
        final int number;
        final int wireType;
        final long varint;
        final byte[] bytes;

        Field(int number, int wireType, long varint, byte[] bytes) {
            this.number = number;
            this.wireType = wireType;
            this.varint = varint;
            this.bytes = bytes;
        }

        String stringValue() {
            return bytes == null ? "" : new String(bytes, StandardCharsets.UTF_8);
        }
    }

    static List<Field> parse(byte[] data) {
        if (data == null) return Collections.emptyList();
        ArrayList<Field> out = new ArrayList<>();
        int[] p = {0};
        try {
            while (p[0] < data.length) {
                long key = readVarint(data, p);
                int number = (int) (key >>> 3);
                int wire = (int) (key & 7);
                if (number <= 0) break;
                switch (wire) {
                    case 0 -> out.add(new Field(number, wire, readVarint(data, p), null));
                    case 1 -> {
                        if (p[0] + 8 > data.length) return out;
                        p[0] += 8;
                        out.add(new Field(number, wire, 0, null));
                    }
                    case 2 -> {
                        int len = safeInt(readVarint(data, p));
                        if (len < 0 || p[0] + len > data.length) return out;
                        byte[] b = new byte[len];
                        System.arraycopy(data, p[0], b, 0, len);
                        p[0] += len;
                        out.add(new Field(number, wire, 0, b));
                    }
                    case 5 -> {
                        if (p[0] + 4 > data.length) return out;
                        p[0] += 4;
                        out.add(new Field(number, wire, 0, null));
                    }
                    default -> { return out; }
                }
            }
        } catch (RuntimeException ignored) {}
        return out;
    }

    static long firstVarint(List<Field> fs, int n, long fallback) {
        for (Field f : fs) if (f.number == n && f.wireType == 0) return f.varint;
        return fallback;
    }

    static String firstString(List<Field> fs, int n, String fallback) {
        for (Field f : fs) if (f.number == n && f.wireType == 2) return f.stringValue();
        return fallback;
    }

    static byte[] firstBytes(List<Field> fs, int n) {
        for (Field f : fs) if (f.number == n && f.wireType == 2) return f.bytes;
        return null;
    }

    static List<String> strings(List<Field> fs, int n) {
        ArrayList<String> r = new ArrayList<>();
        for (Field f : fs) if (f.number == n && f.wireType == 2) r.add(f.stringValue());
        return r;
    }

    static List<Long> repeatedUInt(List<Field> fs, int n) {
        ArrayList<Long> r = new ArrayList<>();
        for (Field f : fs) {
            if (f.number != n) continue;
            if (f.wireType == 0) r.add(f.varint);
            else if (f.wireType == 2 && f.bytes != null) {
                int[] p = {0};
                try {
                    while (p[0] < f.bytes.length) r.add(readVarint(f.bytes, p));
                } catch (RuntimeException ignored) {}
            }
        }
        return r;
    }

    private static long readVarint(byte[] data, int[] p) {
        long v = 0;
        int shift = 0;
        for (int i = 0; i < 10; i++) {
            if (p[0] >= data.length) throw new IllegalArgumentException("truncated varint");
            int b = data[p[0]++] & 0xff;
            v |= (long) (b & 0x7f) << shift;
            if ((b & 0x80) == 0) return v;
            shift += 7;
        }
        throw new IllegalArgumentException("bad varint");
    }

    private static int safeInt(long n) {
        return n > Integer.MAX_VALUE ? -1 : (int) n;
    }
}
