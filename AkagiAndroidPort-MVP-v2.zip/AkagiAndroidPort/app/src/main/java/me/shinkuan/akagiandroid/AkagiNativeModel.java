package me.shinkuan.akagiandroid;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Pure-Java inference for Akagi V3's bundled native_bot CNN.
 * Architecture matches native_bot/src/model.rs: Conv1d -> 3 residual blocks -> FC -> head.
 * No autoplay: this class only ranks discard logits for display.
 */
final class AkagiNativeModel {
    static final class Candidate {
        final String tile;
        final float probability;
        final float logit;
        Candidate(String tile, float probability, float logit) {
            this.tile = tile; this.probability = probability; this.logit = logit;
        }
        String label() { return tile + " " + Math.round(probability * 100f) + "%"; }
    }

    static final class Prediction {
        final List<Candidate> top;
        final long inferenceMs;
        Prediction(List<Candidate> top, long inferenceMs) { this.top = top; this.inferenceMs = inferenceMs; }
        String bestTile() { return top.isEmpty() ? null : top.get(0).tile; }
        int bestPercent() { return top.isEmpty() ? 0 : Math.round(top.get(0).probability * 100f); }
    }

    static final class ActionOption {
        final int index;
        final String label;
        final String discardTile;
        ActionOption(int index, String label, String discardTile) { this.index=index; this.label=label; this.discardTile=discardTile; }
    }

    static final class ActionCandidate {
        final int index; final String label; final String discardTile; final float probability; final float logit;
        ActionCandidate(int index,String label,String discardTile,float probability,float logit){this.index=index;this.label=label;this.discardTile=discardTile;this.probability=probability;this.logit=logit;}
    }
    static final class ActionPrediction {
        final List<ActionCandidate> top; final long inferenceMs;
        ActionPrediction(List<ActionCandidate> top,long inferenceMs){this.top=top;this.inferenceMs=inferenceMs;}
        String bestLabel(){return top.isEmpty()?null:top.get(0).label;}
    }

    private static final Pattern TENSOR = Pattern.compile(
            "\\\"([^\\\"]+)\\\":\\{\\\"dtype\\\":\\\"F32\\\",\\\"shape\\\":\\[([^]]*)],\\\"data_offsets\\\":\\[([0-9]+),([0-9]+)]}");
    private static final Pattern META_NUM = Pattern.compile("\\\"(num_players|tile_dim|action_space|channels|conv|fc|blocks)\\\":\\\"([0-9]+)\\\"");

    private static final class Tensor {
        final int[] shape;
        final float[] data;
        Tensor(int[] shape, float[] data) { this.shape = shape; this.data = data; }
    }

    private final int numPlayers;
    private final int tileDim;
    private final int channels;
    private final int actionSpace;
    private final Tensor convInW, convInB, fcW, fcB, headW, headB;
    private final Tensor[] res1W = new Tensor[3], res1B = new Tensor[3], res2W = new Tensor[3], res2B = new Tensor[3];

    private AkagiNativeModel(byte[] file) {
        if (file.length < 16) throw new IllegalArgumentException("safetensors too short");
        ByteBuffer bb = ByteBuffer.wrap(file).order(ByteOrder.LITTLE_ENDIAN);
        long headerLenLong = bb.getLong(0);
        if (headerLenLong <= 0 || headerLenLong > Integer.MAX_VALUE || 8 + headerLenLong > file.length)
            throw new IllegalArgumentException("bad safetensors header");
        int headerLen = (int) headerLenLong;
        String header = new String(file, 8, headerLen, StandardCharsets.UTF_8).trim();
        Map<String,Integer> meta = new LinkedHashMap<>();
        Matcher mm = META_NUM.matcher(header);
        while (mm.find()) meta.put(mm.group(1), Integer.parseInt(mm.group(2)));
        numPlayers = meta.getOrDefault("num_players", 4);
        tileDim = meta.getOrDefault("tile_dim", numPlayers == 3 ? 27 : 34);
        actionSpace = meta.getOrDefault("action_space", numPlayers == 3 ? 60 : 82);
        channels = meta.getOrDefault("channels", numPlayers == 3 ? 37 : 39);
        int dataBase = 8 + headerLen;

        Map<String,Tensor> tensors = new LinkedHashMap<>();
        Matcher tm = TENSOR.matcher(header);
        while (tm.find()) {
            String name = tm.group(1);
            int[] shape = parseShape(tm.group(2));
            int start = Integer.parseInt(tm.group(3));
            int end = Integer.parseInt(tm.group(4));
            if (start < 0 || end < start || dataBase + end > file.length || ((end - start) & 3) != 0)
                throw new IllegalArgumentException("bad tensor " + name);
            int count = (end - start) / 4;
            float[] vals = new float[count];
            ByteBuffer fb = ByteBuffer.wrap(file, dataBase + start, end - start).order(ByteOrder.LITTLE_ENDIAN);
            for (int i = 0; i < count; i++) vals[i] = fb.getFloat();
            tensors.put(name, new Tensor(shape, vals));
        }

        convInW = require(tensors, "conv_in.weight"); convInB = require(tensors, "conv_in.bias");
        fcW = require(tensors, "fc.weight"); fcB = require(tensors, "fc.bias");
        headW = require(tensors, "head.weight"); headB = require(tensors, "head.bias");
        for (int i = 0; i < 3; i++) {
            res1W[i] = require(tensors, "res." + i + ".conv1.weight");
            res1B[i] = require(tensors, "res." + i + ".conv1.bias");
            res2W[i] = require(tensors, "res." + i + ".conv2.weight");
            res2B[i] = require(tensors, "res." + i + ".conv2.bias");
        }
        validate();
    }

    static AkagiNativeModel load(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[64 * 1024];
        int n;
        while ((n = in.read(buf)) >= 0) out.write(buf, 0, n);
        return new AkagiNativeModel(out.toByteArray());
    }

    int numPlayers() { return numPlayers; }
    int channels() { return channels; }
    int tileDim() { return tileDim; }

    Prediction rankDiscards(float[] observation, List<String> hand, int topN) {
        if (observation == null || observation.length != channels * tileDim || hand == null || hand.isEmpty())
            return new Prediction(List.of(), 0);
        long t0 = System.nanoTime();
        float[] logits = forward(observation);
        LinkedHashMap<Integer,String> unique = new LinkedHashMap<>();
        for (String raw : hand) {
            int t34 = Tile.parse(raw);
            if (t34 < 0) continue;
            int idx = actionIndexForDiscard(t34);
            if (idx < 0 || idx >= logits.length) continue;
            String prior = unique.get(idx);
            // Same action id: prefer a non-red copy when available.
            if (prior == null || (Tile.isRed(prior) && !Tile.isRed(raw))) unique.put(idx, raw);
        }
        if (unique.isEmpty()) return new Prediction(List.of(), (System.nanoTime() - t0) / 1_000_000L);

        float max = -Float.MAX_VALUE;
        for (int idx : unique.keySet()) max = Math.max(max, logits[idx]);
        double sum = 0.0;
        LinkedHashMap<Integer,Double> exp = new LinkedHashMap<>();
        for (int idx : unique.keySet()) {
            double e = Math.exp((double) logits[idx] - max);
            exp.put(idx, e); sum += e;
        }
        ArrayList<Candidate> all = new ArrayList<>();
        for (Map.Entry<Integer,String> e : unique.entrySet()) {
            int idx = e.getKey();
            float p = sum <= 0 ? 0f : (float)(exp.get(idx) / sum);
            all.add(new Candidate(e.getValue(), p, logits[idx]));
        }
        all.sort((a,b) -> Float.compare(b.logit, a.logit));
        if (all.size() > topN) all = new ArrayList<>(all.subList(0, topN));
        return new Prediction(all, (System.nanoTime() - t0) / 1_000_000L);
    }

    ActionPrediction rankOptions(float[] observation, List<ActionOption> options, int topN) {
        if (observation == null || observation.length != channels * tileDim || options == null || options.isEmpty())
            return new ActionPrediction(List.of(),0);
        long t0=System.nanoTime();
        float[] logits=forward(observation);
        // Deduplicate exact action ids. For duplicate labels/variants we keep distinct ids,
        // matching the native model's legal-action softmax.
        LinkedHashMap<Integer,ActionOption> unique=new LinkedHashMap<>();
        for(ActionOption o:options) if(o!=null&&o.index>=0&&o.index<logits.length&&!unique.containsKey(o.index)) unique.put(o.index,o);
        if(unique.isEmpty())return new ActionPrediction(List.of(),(System.nanoTime()-t0)/1_000_000L);
        float max=-Float.MAX_VALUE;for(int i:unique.keySet())max=Math.max(max,logits[i]);
        double sum=0;LinkedHashMap<Integer,Double> exps=new LinkedHashMap<>();
        for(int i:unique.keySet()){double e=Math.exp((double)logits[i]-max);exps.put(i,e);sum+=e;}
        ArrayList<ActionCandidate> out=new ArrayList<>();
        for(Map.Entry<Integer,ActionOption> e:unique.entrySet()){
            int i=e.getKey();ActionOption o=e.getValue();float p=sum<=0?0f:(float)(exps.get(i)/sum);
            out.add(new ActionCandidate(i,o.label,o.discardTile,p,logits[i]));
        }
        out.sort((a,b)->Float.compare(b.logit,a.logit));
        if(out.size()>topN)out=new ArrayList<>(out.subList(0,topN));
        return new ActionPrediction(out,(System.nanoTime()-t0)/1_000_000L);
    }

    int discardActionIndex(String tile) { int t=Tile.parse(tile); return t<0?-1:actionIndexForDiscard(t); }
    int riichiIndex(){return numPlayers==3?27:37;}
    int ponIndex(){return numPlayers==3?28:41;}
    int agariIndex(){return numPlayers==3?56:79;}
    int kyushuIndex(){return numPlayers==3?57:80;}
    int passIndex(){return numPlayers==3?58:81;}
    int kitaIndex(){return numPlayers==3?59:-1;}
    int kanIndex(String tile){int t=Tile.parse(tile);if(t<0)return -1;int x=numPlayers==3?Tile.compact3p(t):t;return x<0?-1:(numPlayers==3?29+x:42+x);}
    int chiIndex(int variant){return numPlayers==3?-1:38+Math.max(0,Math.min(2,variant));}

    float[] forward(float[] input) {
        float[] x = conv1d(input, channels, tileDim, convInW.data, 64, convInB.data, true);
        for (int i = 0; i < 3; i++) {
            float[] y = conv1d(x, 64, tileDim, res1W[i].data, 64, res1B[i].data, true);
            y = conv1d(y, 64, tileDim, res2W[i].data, 64, res2B[i].data, false);
            for (int j = 0; j < x.length; j++) x[j] = Math.max(0f, x[j] + y[j]);
        }
        float[] fc = linear(x, fcW.data, 256, fcB.data, true);
        return linear(fc, headW.data, actionSpace, headB.data, false);
    }

    private static float[] conv1d(float[] in, int inC, int len, float[] w, int outC, float[] bias, boolean relu) {
        float[] out = new float[outC * len];
        for (int oc = 0; oc < outC; oc++) {
            int wOc = oc * inC * 3;
            float b = bias[oc];
            int outBase = oc * len;
            for (int t = 0; t < len; t++) {
                float sum = b;
                for (int ic = 0; ic < inC; ic++) {
                    int inBase = ic * len;
                    int wk = wOc + ic * 3;
                    if (t > 0) sum += w[wk] * in[inBase + t - 1];
                    sum += w[wk + 1] * in[inBase + t];
                    if (t + 1 < len) sum += w[wk + 2] * in[inBase + t + 1];
                }
                out[outBase + t] = relu && sum < 0f ? 0f : sum;
            }
        }
        return out;
    }

    private static float[] linear(float[] in, float[] w, int outDim, float[] bias, boolean relu) {
        int inDim = in.length;
        float[] out = new float[outDim];
        for (int o = 0; o < outDim; o++) {
            float sum = bias[o];
            int base = o * inDim;
            for (int i = 0; i < inDim; i++) sum += w[base + i] * in[i];
            out[o] = relu && sum < 0f ? 0f : sum;
        }
        return out;
    }

    private int actionIndexForDiscard(int tile34) {
        if (numPlayers != 3) return tile34;
        return Tile.compact3p(tile34);
    }

    private static Tensor require(Map<String,Tensor> map, String key) {
        Tensor t = map.get(key);
        if (t == null) throw new IllegalArgumentException("missing tensor " + key);
        return t;
    }

    private static int[] parseShape(String s) {
        if (s == null || s.trim().isEmpty()) return new int[0];
        String[] parts = s.split(",");
        int[] out = new int[parts.length];
        for (int i = 0; i < parts.length; i++) out[i] = Integer.parseInt(parts[i].trim());
        return out;
    }

    private void validate() {
        if (convInW.data.length != 64 * channels * 3) throw new IllegalArgumentException("conv_in shape mismatch");
        if (fcW.data.length != 256 * 64 * tileDim) throw new IllegalArgumentException("fc shape mismatch");
        if (headW.data.length != actionSpace * 256) throw new IllegalArgumentException("head shape mismatch");
        for (int i = 0; i < 3; i++) {
            if (res1W[i].data.length != 64 * 64 * 3 || res2W[i].data.length != 64 * 64 * 3)
                throw new IllegalArgumentException("res shape mismatch");
        }
    }
}
