package me.shinkuan.akagiandroid;

import java.util.ArrayList;
import java.util.List;

final class Tile {
    private Tile() {}

    static int parse(String s) {
        if (s == null || s.length() < 2) return -1;
        char num = s.charAt(0);
        char suit = Character.toLowerCase(s.charAt(1));
        int n = num - '0';
        if (n == 0 && (suit == 'm' || suit == 'p' || suit == 's')) n = 5;
        if (suit == 'm' && n >= 1 && n <= 9) return n - 1;
        if (suit == 'p' && n >= 1 && n <= 9) return 9 + n - 1;
        if (suit == 's' && n >= 1 && n <= 9) return 18 + n - 1;
        if (suit == 'z' && n >= 1 && n <= 7) return 27 + n - 1;
        return -1;
    }

    static String name(int t) {
        if (t < 0 || t >= 34) return "?";
        if (t < 9) return (t + 1) + "m";
        if (t < 18) return (t - 8) + "p";
        if (t < 27) return (t - 17) + "s";
        return (t - 26) + "z";
    }

    static boolean isRed(String s) {
        return s != null && s.length() >= 2 && s.charAt(0) == '0' && "mpsMPS".indexOf(s.charAt(1)) >= 0;
    }

    /** Canonical raw 136-space id used by Akagi native_bot features. */
    static int rawId(String s) {
        int t = parse(s);
        if (t < 0) return -1;
        if (isRed(s)) {
            if (t == 4) return 16;
            if (t == 13) return 52;
            if (t == 22) return 88;
        }
        // Pick a stable non-red physical copy. For normal five, avoid the red id at copy 0.
        if (t == 4 || t == 13 || t == 22) return t * 4 + 1;
        return t * 4;
    }

    static int compact3p(int tile34) {
        if (tile34 == 0) return 0;
        if (tile34 >= 1 && tile34 <= 7) return -1;
        if (tile34 == 8) return 1;
        if (tile34 >= 9 && tile34 <= 33) return tile34 - 7;
        return -1;
    }

    static int tileAxisIndex(String s, int players) {
        int t = parse(s);
        return players == 3 ? compact3p(t) : t;
    }

    static int nextDora34(int indicator34, int players) {
        if (indicator34 < 0 || indicator34 >= 34) return -1;
        if (players == 3 && indicator34 == 0) return 8;
        if (players == 3 && indicator34 == 8) return 0;
        if (indicator34 < 27) {
            int suit = indicator34 / 9, r = indicator34 % 9;
            return suit * 9 + ((r + 1) % 9);
        }
        // winds E S W N cycle; dragons P F C cycle.
        if (indicator34 >= 27 && indicator34 <= 30) return 27 + ((indicator34 - 27 + 1) % 4);
        return 31 + ((indicator34 - 31 + 1) % 3);
    }

    static int[] counts(List<String> tiles) {
        int[] c = new int[34];
        if (tiles == null) return c;
        for (String s : tiles) {
            int t = parse(s);
            if (t >= 0) c[t]++;
        }
        return c;
    }

    static List<String> fromCounts(int[] c) {
        ArrayList<String> out = new ArrayList<>();
        for (int i = 0; i < 34; i++) for (int n = 0; n < c[i]; n++) out.add(name(i));
        return out;
    }
}
