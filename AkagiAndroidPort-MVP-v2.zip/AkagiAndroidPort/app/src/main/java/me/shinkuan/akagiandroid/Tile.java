package me.shinkuan.akagiandroid;

import java.util.ArrayList;
import java.util.List;

final class Tile {
    private Tile() {}

    static int parse(String s) {
        if (s == null || s.length() < 2) return -1;
        char num = s.charAt(0);
        char suit = Character.toLowerCase(s.charAt(1));
        int n = num - '0';
        if (n == 0 && (suit == 'm' || suit == 'p' || suit == 's')) n = 5;
        if (suit == 'm' && n >= 1 && n <= 9) return n - 1;
        if (suit == 'p' && n >= 1 && n <= 9) return 9 + n - 1;
        if (suit == 's' && n >= 1 && n <= 9) return 18 + n - 1;
        if (suit == 'z' && n >= 1 && n <= 7) return 27 + n - 1;
        return -1;
    }

    static String name(int t) {
        if (t < 0 || t >= 34) return "?";
        if (t < 9) return (t + 1) + "m";
        if (t < 18) return (t - 8) + "p";
        if (t < 27) return (t - 17) + "s";
        return (t - 26) + "z";
    }

    static int[] counts(List<String> tiles) {
        int[] c = new int[34];
        if (tiles == null) return c;
        for (String s : tiles) {
            int t = parse(s);
            if (t >= 0) c[t]++;
        }
        return c;
    }

    static List<String> fromCounts(int[] c) {
        ArrayList<String> out = new ArrayList<>();
        for (int i = 0; i < 34; i++) for (int n = 0; n < c[i]; n++) out.add(name(i));
        return out;
    }
}
