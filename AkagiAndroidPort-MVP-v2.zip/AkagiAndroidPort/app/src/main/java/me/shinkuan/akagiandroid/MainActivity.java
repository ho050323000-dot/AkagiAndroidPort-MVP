package me.shinkuan.akagiandroid;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Message;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.concurrent.atomic.AtomicBoolean;

public final class MainActivity extends Activity {
    private static final String DEFAULT_URL = "https://mahjongsoul.game.yo-star.com/";

    private FrameLayout root;
    private WebView webView;
    private WebView popupWebView;
    private FrameLayout popupLayer;
    private TextView status;
    private TextView advice;
    private TextView detail;
    private LinearLayout overlay;
    private Button returnGame;
    private LinearLayout handGuide;
    private LinearLayout handGuideRow;
    private FrameLayout callGuide;
    private final ArrayList<TextView> callGuideMarkers = new ArrayList<>();
    private static final Pattern TILE_TOKEN = Pattern.compile("(?<![A-Za-z0-9])([0-9][mpsz])(?![A-Za-z0-9])");
    private String hookScript;
    private String lastGameUrl = DEFAULT_URL;
    private long lastBackPress;
    private final AtomicBoolean hookReady = new AtomicBoolean(false);
    private MajsoulState state;
    private MajsoulState.Snapshot lastSnapshot;
    private long lastHistoryVersion = -1;
    private boolean handGuideEnabled = true;

    private static final class CallHint {
        final String label;
        final ArrayList<Integer> handIndices;
        final boolean pass;

        CallHint(String label, ArrayList<Integer> handIndices, boolean pass) {
            this.label = label;
            this.handIndices = handIndices;
            this.pass = pass;
        }
    }

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            initActivity(savedInstanceState);
        } catch (Throwable t) {
            android.util.Log.e("AkagiAndroid", "fatal during Activity init", t);
            saveCrash(t);
            showFatalScreen(t);
        }
    }

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    private void initActivity(Bundle savedInstanceState) {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        // Start the UI first. Loading both neural-net weight files on the main
        // thread can make some Android devices kill the activity during launch.
        state = new MajsoulState(s -> runOnUiThread(() -> render(s)), null, null);
        hookScript = readAsset("ws_hook.js");

        root = new FrameLayout(this);
        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        buildOverlay(root);
        buildHandGuide(root);
        buildCallGuide(root);
        setContentView(root);

        configureMainWebView();
        String url = getPreferences(MODE_PRIVATE).getString("game_url", DEFAULT_URL);
        lastGameUrl = url;
        webView.loadUrl(url);
    }

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    private void configureMainWebView() {
        configureCommon(webView, true);
        webView.addJavascriptInterface(new CaptureBridge(), "AkagiCapture");
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                WebViewCompat.addDocumentStartJavaScript(webView, hookScript, Collections.singleton("*"));
            }
        } catch (Throwable t) {
            android.util.Log.w("AkagiAndroid", "document-start hook unavailable; page hook fallback will be used", t);
        }
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                openPopup(resultMsg);
                return true;
            }
            @Override public void onCloseWindow(WebView window) { closePopup(); }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                if (isGameUrl(url)) lastGameUrl = url;
                hookReady.set(false);
                view.evaluateJavascript(hookScript, null);
            }
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (!hookReady.get()) view.evaluateJavascript(hookScript, null);
                detectVerificationPage(view, false);
            }
        });
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureCommon(WebView v, boolean multiWindow) {
        WebSettings ws = v.getSettings();
        ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true); ws.setDatabaseEnabled(true);
        ws.setMediaPlaybackRequiresUserGesture(false); ws.setAllowFileAccess(false); ws.setAllowContentAccess(false);
        ws.setSupportZoom(false); ws.setUseWideViewPort(true); ws.setLoadWithOverviewMode(true);
        ws.setJavaScriptCanOpenWindowsAutomatically(true); ws.setSupportMultipleWindows(multiWindow);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(v, true);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void openPopup(Message resultMsg) {
        closePopup();
        popupLayer = new FrameLayout(this);
        popupLayer.setBackgroundColor(Color.WHITE);
        popupWebView = new WebView(this);
        configureCommon(popupWebView, false);
        popupWebView.setWebChromeClient(new WebChromeClient() {
            @Override public void onCloseWindow(WebView window) { closePopup(); }
        });
        popupWebView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                detectVerificationPage(view, true);
            }
        });
        popupLayer.addView(popupWebView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        Button close = button("인증창 닫기 / 게임으로 돌아가기");
        close.setTextSize(12);
        close.setOnClickListener(v -> closePopup());
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(dp(260), dp(48));
        bp.gravity = Gravity.TOP | Gravity.END; bp.topMargin = dp(8); bp.rightMargin = dp(8);
        popupLayer.addView(close, bp);

        root.addView(popupLayer, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
        transport.setWebView(popupWebView); resultMsg.sendToTarget();
        status.setText("인증창 열림 · 인증 완료 후 우측 상단 버튼으로 복귀");
    }

    private void detectVerificationPage(WebView v, boolean popup) {
        String js = "(function(){var t=(document.body&&document.body.innerText)||'';return /Verification Completed|verification result|인증 완료/i.test(t);})()";
        v.evaluateJavascript(js, value -> {
            if (!"true".equals(value)) return;
            runOnUiThread(() -> {
                CookieManager.getInstance().flush();
                advice.setText("인증 완료 · 게임으로 복귀하세요");
                status.setText("인증 성공 감지");
                if (!popup) returnGame.setVisibility(View.VISIBLE);
                else Toast.makeText(this, "인증 완료. 우측 상단 '게임으로 돌아가기'를 누르세요.", Toast.LENGTH_LONG).show();
            });
        });
    }

    private void closePopup() {
        if (popupWebView != null) {
            popupWebView.stopLoading(); popupWebView.destroy(); popupWebView = null;
        }
        if (popupLayer != null) { root.removeView(popupLayer); popupLayer = null; }
        CookieManager.getInstance().flush();
        if (webView != null) {
            webView.requestFocus();
            webView.evaluateJavascript("try{window.focus()}catch(e){}", null);
        }
        status.setText("인증창 닫힘 · 게임 응답 대기");
    }

    private boolean isGameUrl(String u) {
        if (u == null) return false;
        return u.contains("mahjongsoul.game.yo-star.com") || u.contains("game.maj-soul.com");
    }

    private void buildOverlay(FrameLayout root) {
        overlay = new LinearLayout(this); overlay.setOrientation(LinearLayout.VERTICAL);
        overlay.setPadding(dp(10), dp(8), dp(10), dp(8)); overlay.setBackgroundColor(0xD6111111);
        status = label(12, Color.LTGRAY); advice = label(18, Color.WHITE); detail = label(11, 0xFFE0E0E0);
        overlay.addView(status); overlay.addView(advice); overlay.addView(detail);

        LinearLayout buttons = new LinearLayout(this); buttons.setOrientation(LinearLayout.HORIZONTAL);
        Button reload = button("새로고침"); reload.setOnClickListener(v -> { state.reset(); webView.reload(); });
        Button url = button("주소"); url.setOnClickListener(v -> editUrl());
        Button hide = button("접기"); hide.setOnClickListener(v -> {
            boolean compact = detail.getVisibility() == View.GONE;
            detail.setVisibility(compact ? View.VISIBLE : View.GONE); status.setVisibility(compact ? View.VISIBLE : View.GONE);
            hide.setText(compact ? "접기" : "펼치기");
        });
        returnGame = button("게임복귀"); returnGame.setVisibility(View.GONE);
        returnGame.setOnClickListener(v -> {
            returnGame.setVisibility(View.GONE); CookieManager.getInstance().flush(); webView.loadUrl(lastGameUrl == null ? DEFAULT_URL : lastGameUrl);
        });
        buttons.addView(reload); buttons.addView(url); buttons.addView(hide); buttons.addView(returnGame); overlay.addView(buttons);

        LinearLayout tools = new LinearLayout(this); tools.setOrientation(LinearLayout.HORIZONTAL);
        Button history = button("기록"); history.setOnClickListener(v -> showHistory());
        Button inspector = button("인스펙터"); inspector.setOnClickListener(v -> showInspector());
        Button guide = button("패숨김"); guide.setOnClickListener(v -> {
            handGuideEnabled = !handGuideEnabled;
            handGuide.setVisibility(handGuideEnabled && lastSnapshot != null && !lastSnapshot.hand.isEmpty() ? View.VISIBLE : View.GONE);
            guide.setText(handGuideEnabled ? "패숨김" : "패표시");
        });
        tools.addView(history); tools.addView(inspector); tools.addView(guide); overlay.addView(tools);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(470), ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.TOP | Gravity.START; lp.leftMargin = dp(8); lp.topMargin = dp(8); root.addView(overlay, lp);
        advice.setText("Akagi Android+: 연결 대기"); status.setText("WebSocket hook 준비 중");
        detail.setText("로그인 후 대국에 들어가세요. 인증창은 별도 창으로 유지됩니다.");
    }


    private void buildHandGuide(FrameLayout root) {
        // Marker-only overlay: no duplicate white tile cards.  It stays as a very
        // thin transparent strip just above the real Mahjong Soul hand.
        handGuide = new LinearLayout(this);
        handGuide.setOrientation(LinearLayout.HORIZONTAL);
        handGuide.setGravity(Gravity.CENTER);
        handGuide.setPadding(0, 0, 0, 0);
        handGuide.setBackgroundColor(Color.TRANSPARENT);

        handGuideRow = new LinearLayout(this);
        handGuideRow.setOrientation(LinearLayout.HORIZONTAL);
        handGuideRow.setGravity(Gravity.CENTER);
        handGuide.addView(handGuideRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(18)));

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(18));
        lp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        // The old guide covered call buttons because it contained 52dp tile cards.
        // With markers only, this margin places the arrows immediately above the real hand.
        lp.bottomMargin = dp(58);
        root.addView(handGuide, lp);
        handGuide.setVisibility(View.GONE);
    }

    private void buildCallGuide(FrameLayout root) {
        // Full-screen, touch-through marker layer. Marker positions are placed
        // with normalized WebView/root coordinates instead of dp margins so
        // Samsung high-density / split-screen layouts do not shift them.
        callGuide = new FrameLayout(this);
        callGuide.setBackgroundColor(Color.TRANSPARENT);
        callGuide.setClickable(false);
        callGuide.setFocusable(false);
        callGuide.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        root.addView(callGuide, lp);
        callGuide.setVisibility(View.GONE);
    }

    private TextView label(int sp, int color) {
        TextView t = new TextView(this); t.setTextSize(sp); t.setTextColor(color); t.setPadding(0, dp(2), 0, dp(2)); return t;
    }
    private Button button(String text) {
        Button b = new Button(this); b.setText(text); b.setTextSize(10); b.setAllCaps(false); b.setMinHeight(0); b.setMinimumHeight(0); return b;
    }

    private void editUrl() {
        final android.widget.EditText e = new android.widget.EditText(this); e.setSingleLine(true);
        e.setText(webView.getUrl() == null ? DEFAULT_URL : webView.getUrl());
        new AlertDialog.Builder(this).setTitle("작혼 웹 주소").setView(e)
                .setPositiveButton("열기", (d, w) -> {
                    String u = e.getText().toString().trim(); if (!u.startsWith("https://")) u = "https://" + u;
                    getPreferences(MODE_PRIVATE).edit().putString("game_url", u).apply(); lastGameUrl = u; state.reset(); webView.loadUrl(u);
                }).setNegativeButton("취소", null).show();
    }

    private void render(MajsoulState.Snapshot s) {
        lastSnapshot = s;
        if (s.historyVersion > lastHistoryVersion && s.historyLine != null && !s.historyLine.isEmpty()) {
            if (lastHistoryVersion >= 0) appendHistory(s.historyLine);
            lastHistoryVersion = s.historyVersion;
        } else if (lastHistoryVersion < 0) lastHistoryVersion = s.historyVersion;

        status.setText("프레임 " + s.frames + " · " + s.playerCount + "인 · 좌석 " + (s.selfSeat < 0 ? "?" : s.selfSeat)
                + " · 남은패 " + (s.leftTiles < 0 ? "?" : s.leftTiles) + " · " + s.note);

        CallHint callHint = extractCallHint(s);
        if (s.analysis != null) {
            String sh = s.analysis.shanten < 0 ? "화료" : s.analysis.shanten + "샹텐";
            if (s.finalDiscard != null) {
                String ag = s.agari != null && s.agari.average > 0 ? " · 화료율 " + Math.round(s.agari.average) + "%" : "";
                advice.setText(s.finalSource + " 타패: " + tileLabel(s.finalDiscard) + " · " + sh + " · 유효 " + s.analysis.ukeire + ag);
            } else advice.setText(sh);
        } else advice.setText("대국 데이터 대기 중");

        StringBuilder d = new StringBuilder();
        d.append("손패: ").append(joinTiles(s.hand)).append('\n');
        d.append("도라표시: ").append(joinTiles(s.doras)).append('\n');
        if (s.ai != null && !s.ai.top.isEmpty()) {
            d.append("Akagi원본 TOP3: ");
            for (int i = 0; i < s.ai.top.size(); i++) {
                if (i > 0) d.append(" · ");
                AkagiNativeModel.Candidate c = s.ai.top.get(i);
                d.append(tileLabel(c.tile)).append(' ').append(Math.round(c.probability * 100)).append('%');
            }
            d.append(" (").append(s.ai.inferenceMs).append("ms)\n");
        }
        if (s.aiAction != null && !s.aiAction.top.isEmpty()) {
            d.append("Akagi원본 행동: ");
            for (int i = 0; i < s.aiAction.top.size(); i++) {
                if (i > 0) d.append(" · ");
                AkagiNativeModel.ActionCandidate c = s.aiAction.top.get(i);
                d.append(humanizeTileCodes(c.label)).append(' ').append(Math.round(c.probability * 100)).append('%');
            }
            d.append("\n");
        }
        if (s.analysis != null && !s.analysis.waits.isEmpty()) d.append("대기패: ").append(joinTiles(s.analysis.waits)).append('\n');
        if (s.agari != null && !s.agari.perWait.isEmpty()) d.append("화료율: ").append(humanizeTileCodes(String.join(" · ", s.agari.perWait))).append(s.agari.furiten ? " · 후리텐" : "").append('\n');
        if (s.analysis != null && !s.analysis.improvers.isEmpty()) d.append("개선패: ").append(joinTiles(s.analysis.improvers)).append('\n');
        if (s.pick != null && !s.pick.top.isEmpty()) d.append("공수 TOP3: ").append(humanizeTileCodes(String.join(" · ", s.pick.top))).append('\n');
        if (!s.opponents.isEmpty()) d.append("상대: ").append(s.opponents).append('\n');
        d.append("기록: ").append(s.stats).append('\n');
        d.append("마지막: ").append(s.lastAction).append(" / ").append(s.lastMethod);
        detail.setText(d.toString());

        renderHandGuide(s.hand, s.finalDiscard, s.finalSource, callHint);
        renderCallGuide(callHint, s.callButtons);
    }

    private void renderHandGuide(List<String> hand, String recommendedDiscard, String mode, CallHint callHint) {
        if (handGuide == null || handGuideRow == null) return;
        handGuideRow.removeAllViews();
        if (!handGuideEnabled || hand == null || hand.isEmpty()) {
            handGuide.setVisibility(View.GONE);
            return;
        }

        int markedIndex = -1;
        if (recommendedDiscard != null) {
            int wanted = Tile.parse(recommendedDiscard);
            for (int i = 0; i < hand.size(); i++) {
                if (Tile.parse(hand.get(i)) == wanted) { markedIndex = i; break; }
            }
        }
        if (markedIndex < 0) {
            handGuide.setVisibility(View.GONE);
            return;
        }

        int w = root == null ? getResources().getDisplayMetrics().widthPixels : root.getWidth();
        int h = root == null ? getResources().getDisplayMetrics().heightPixels : root.getHeight();
        if (w <= 1 || h <= 1) {
            handGuide.post(() -> renderHandGuide(hand, recommendedDiscard, mode, callHint));
            return;
        }

        // Mahjong Soul's local hand is not centered on wide/Fold layouts; it
        // begins around 14.5% of the table width. Position the one discard
        // marker directly by normalized hand-slot geometry instead of building
        // a centered 13/14-column strip.
        float handLeft = 0.145f;
        float slot = 0.0430f;
        float cx = handLeft + slot * (markedIndex + 0.5f);
        float cy = 0.765f;

        handGuideRow.removeAllViews();
        TextView marker = new TextView(this);
        marker.setText("▼");
        marker.setTextSize(25);
        marker.setTextColor(0xFFFFE066);
        marker.setGravity(Gravity.CENTER);
        marker.setIncludeFontPadding(false);
        marker.setClickable(false);
        marker.setFocusable(false);
        marker.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        handGuideRow.addView(marker, new LinearLayout.LayoutParams(dp(42), dp(42)));

        ViewGroup.LayoutParams raw = handGuide.getLayoutParams();
        if (raw instanceof FrameLayout.LayoutParams lp) {
            lp.width = dp(42);
            lp.height = dp(42);
            lp.gravity = Gravity.TOP | Gravity.START;
            lp.leftMargin = Math.round(w * cx - dp(21));
            lp.topMargin = Math.round(h * cy - dp(21));
            lp.bottomMargin = 0;
            handGuide.setLayoutParams(lp);
        }
        handGuide.setVisibility(View.VISIBLE);
        handGuide.bringToFront();
    }

    private void renderCallGuide(CallHint hint, List<String> buttons) {
        if (callGuide == null) return;
        callGuide.removeAllViews();
        callGuideMarkers.clear();
        if (hint == null || hint.label == null || hint.label.isEmpty() || buttons == null || buttons.isEmpty()) {
            callGuide.setVisibility(View.GONE);
            return;
        }

        String wanted;
        String label = hint.label;
        if (label.startsWith("치")) wanted = "치";
        else if (label.startsWith("퐁")) wanted = "퐁";
        else if (label.contains("깡")) wanted = "깡";
        else if (label.startsWith("패스")) wanted = "패스";
        else if (label.startsWith("론")) wanted = "론";
        else if (label.startsWith("쯔모")) wanted = "쯔모";
        else if (label.startsWith("리치")) wanted = "리치";
        else if (label.startsWith("북빼기")) wanted = "북빼기";
        else if (label.startsWith("구종구패")) wanted = "구종구패";
        else { callGuide.setVisibility(View.GONE); return; }

        int selected = -1;
        for (int i = 0; i < buttons.size(); i++) {
            String b = buttons.get(i);
            if (wanted.equals(b) || (("론".equals(wanted) || "쯔모".equals(wanted)) && ("론".equals(b) || "쯔모".equals(b)))) {
                selected = i;
                break;
            }
        }
        if (selected < 0) {
            callGuide.setVisibility(View.GONE);
            return;
        }

        int w = root == null ? getResources().getDisplayMetrics().widthPixels : root.getWidth();
        int h = root == null ? getResources().getDisplayMetrics().heightPixels : root.getHeight();
        if (w <= 1 || h <= 1) {
            callGuide.post(() -> renderCallGuide(hint, buttons));
            return;
        }

        // Mahjong Soul call controls are right aligned. Public/current mobile
        // layouts keep Skip/Pass at the far right and expand left as more
        // choices appear. These normalized centers stay stable across density,
        // split screen and Fold aspect-ratio changes.
        int n = buttons.size();
        float rightCenter = 0.895f;
        float spacing;
        if (n <= 2) spacing = 0.185f;
        else if (n == 3) spacing = 0.155f;
        else if (n == 4) spacing = 0.130f;
        else spacing = 0.112f;

        float cxNorm = rightCenter - spacing * (n - 1 - selected);
        // Marker center sits immediately above the action-button row, not on
        // top of the buttons, so touch targets remain fully unobstructed.
        float cyNorm = 0.695f;

        int markerBox = Math.max(44, Math.round(Math.min(w, h) * 0.085f));
        TextView marker = new TextView(this);
        marker.setText("▼");
        marker.setTextSize(28);
        marker.setTextColor(0xFFFFE066);
        marker.setGravity(Gravity.CENTER);
        marker.setIncludeFontPadding(false);
        marker.setClickable(false);
        marker.setFocusable(false);
        marker.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);

        FrameLayout.LayoutParams mlp = new FrameLayout.LayoutParams(markerBox, markerBox);
        mlp.leftMargin = Math.round(w * cxNorm - markerBox / 2f);
        mlp.topMargin = Math.round(h * cyNorm - markerBox / 2f);
        callGuide.addView(marker, mlp);
        callGuideMarkers.add(marker);

        callGuide.setVisibility(View.VISIBLE);
        callGuide.bringToFront();
    }

    private String compactCallLabel(String raw) {
        if (raw == null || raw.isEmpty()) return "";
        String label = humanizeTileCodes(raw);
        if (label.startsWith("패스")) return "→ 안 울기";
        if (label.startsWith("치")) return "↗ " + label;
        if (label.startsWith("퐁")) return "↗ " + label;
        if (label.contains("깡")) return "↗ " + label;
        if (label.startsWith("리치")) return "↗ 리치";
        if (label.startsWith("론")) return "↗ 론";
        if (label.startsWith("쯔모")) return "↗ 쯔모";
        return "↗ " + label;
    }

    private CallHint extractCallHint(MajsoulState.Snapshot s) {
        if (s == null || s.aiAction == null || s.aiAction.top == null || s.aiAction.top.isEmpty()) return null;
        // Only the top-ranked original Akagi action is the recommendation.
        // Never point at a runner-up call/pass while the top action is a discard.
        AkagiNativeModel.ActionCandidate chosen = s.aiAction.top.get(0);
        if (chosen == null || chosen.label == null || chosen.label.isEmpty() || chosen.label.startsWith("타패 ")) return null;

        String label = chosen.label;
        boolean pass = label.startsWith("패스");
        ArrayList<Integer> indices = new ArrayList<>();

        if (label.startsWith("퐁")) {
            markPonTiles(indices, s.hand, s.lastDiscardTile);
        } else if (label.startsWith("치")) {
            markChiTiles(indices, s.hand, s.lastDiscardTile, label);
        } else if (label.contains("깡")) {
            markKanTiles(indices, s.hand, s.lastDiscardTile, label);
        }
        return new CallHint(label, indices, pass);
    }

    private void markPonTiles(ArrayList<Integer> out, List<String> hand, String lastDiscardTile) {
        int target = Tile.parse(lastDiscardTile);
        if (target < 0 || hand == null) return;
        for (int i = 0; i < hand.size() && out.size() < 2; i++) {
            if (Tile.parse(hand.get(i)) == target) out.add(i);
        }
    }

    private void markChiTiles(ArrayList<Integer> out, List<String> hand, String lastDiscardTile, String label) {
        if (hand == null) return;
        java.util.LinkedHashMap<Integer, Integer> needed = new java.util.LinkedHashMap<>();
        Matcher m = TILE_TOKEN.matcher(label);
        while (m.find()) {
            int t = Tile.parse(m.group(1));
            if (t >= 0) needed.put(t, needed.getOrDefault(t, 0) + 1);
        }
        int discard = Tile.parse(lastDiscardTile);
        if (discard >= 0 && needed.containsKey(discard)) {
            int left = needed.get(discard) - 1;
            if (left <= 0) needed.remove(discard); else needed.put(discard, left);
        }
        for (int i = 0; i < hand.size(); i++) {
            int t = Tile.parse(hand.get(i));
            Integer left = needed.get(t);
            if (left != null && left > 0) {
                out.add(i);
                if (left == 1) needed.remove(t); else needed.put(t, left - 1);
            }
        }
    }

    private void markKanTiles(ArrayList<Integer> out, List<String> hand, String lastDiscardTile, String label) {
        if (hand == null) return;
        int target = -1;
        Matcher m = TILE_TOKEN.matcher(label);
        if (m.find()) target = Tile.parse(m.group(1));
        if (target < 0) target = Tile.parse(lastDiscardTile);
        if (target < 0) return;
        for (int i = 0; i < hand.size(); i++) {
            if (Tile.parse(hand.get(i)) == target) out.add(i);
        }
    }

    private String joinTiles(List<String> tiles) {
        if (tiles == null || tiles.isEmpty()) return "-";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < tiles.size(); i++) {
            if (i > 0) sb.append(' ');
            sb.append(tileLabel(tiles.get(i)));
        }
        return sb.toString();
    }

    private String tileLabel(String code) {
        if (code == null || code.isEmpty()) return "?";
        int t = Tile.parse(code);
        if (t < 0) return code;
        if (t < 9) {
            int rank = t + 1;
            return (code.charAt(0) == '0' ? "적5" : String.valueOf(rank)) + "만";
        }
        if (t < 18) {
            int rank = t - 8;
            return (code.charAt(0) == '0' ? "적5" : String.valueOf(rank)) + "통";
        }
        if (t < 27) {
            int rank = t - 17;
            return (code.charAt(0) == '0' ? "적5" : String.valueOf(rank)) + "삭";
        }
        return switch (t) {
            case 27 -> "동";
            case 28 -> "남";
            case 29 -> "서";
            case 30 -> "북";
            case 31 -> "백";
            case 32 -> "발";
            case 33 -> "중";
            default -> code;
        };
    }

    private String humanizeTileCodes(String text) {
        if (text == null || text.isEmpty()) return "";
        Matcher m = TILE_TOKEN.matcher(text);
        StringBuffer out = new StringBuffer();
        while (m.find()) {
            m.appendReplacement(out, Matcher.quoteReplacement(tileLabel(m.group(1))));
        }
        m.appendTail(out);
        return out.toString();
    }

    private void saveCrash(Throwable t) {
        try {
            getSharedPreferences("akagi_boot_diag", MODE_PRIVATE).edit()
                    .putString("last_crash", android.util.Log.getStackTraceString(t))
                    .putLong("last_crash_time", System.currentTimeMillis()).commit();
        } catch (Throwable ignored) {}
    }

    private void showFatalScreen(Throwable t) {
        try {
            android.widget.ScrollView scroll = new android.widget.ScrollView(this);
            TextView tv = new TextView(this);
            tv.setTextColor(Color.WHITE);
            tv.setBackgroundColor(0xFF111111);
            tv.setTextSize(12);
            tv.setPadding(dp(16), dp(16), dp(16), dp(16));
            tv.setTextIsSelectable(true);
            tv.setText("Akagi Android 시작 오류\n\n" + android.util.Log.getStackTraceString(t) +
                    "\n\n이 화면을 캡처해서 ChatGPT에 보내주세요.");
            scroll.addView(tv);
            setContentView(scroll);
        } catch (Throwable ignored) {
            finish();
        }
    }

    private void appendHistory(String line) {
        android.content.SharedPreferences p = getSharedPreferences("akagi_history", MODE_PRIVATE);
        String old = p.getString("lines", "");
        String now = new java.text.SimpleDateFormat("MM-dd HH:mm", java.util.Locale.KOREA).format(new java.util.Date());
        String merged = (old + now + "  " + line + "\n");
        String[] rows = merged.split("\n");
        if (rows.length > 100) {
            StringBuilder b = new StringBuilder();
            for (int i = rows.length - 100; i < rows.length; i++) if (!rows[i].isEmpty()) b.append(rows[i]).append('\n');
            merged = b.toString();
        }
        p.edit().putString("lines", merged).apply();
    }

    private void showHistory() {
        String lines = getSharedPreferences("akagi_history", MODE_PRIVATE).getString("lines", "기록 없음");
        if (lines == null || lines.trim().isEmpty()) lines = "기록 없음";
        final String text = lines;
        new AlertDialog.Builder(this).setTitle("Akagi 기록").setMessage(text)
                .setPositiveButton("닫기", null)
                .setNegativeButton("기록 지우기", (d,w) -> getSharedPreferences("akagi_history", MODE_PRIVATE).edit().clear().apply()).show();
    }

    private void showInspector() {
        MajsoulState.Snapshot s = lastSnapshot;
        String text = s == null ? "대국 데이터 없음" : s.inspector + "\n손패=" + joinTiles(s.hand) + "\n도라표시=" + joinTiles(s.doras);
        new AlertDialog.Builder(this).setTitle("Protocol / State Inspector").setMessage(text).setPositiveButton("닫기", null).show();
    }

    private String readAsset(String name) {
        StringBuilder s = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(getAssets().open(name), StandardCharsets.UTF_8))) {
            String line; while ((line = r.readLine()) != null) s.append(line).append('\n');
        } catch (Exception e) { throw new RuntimeException(e); }
        return s.toString();
    }
    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }

    @Override public void onBackPressed() {
        if (popupWebView != null) { closePopup(); return; }
        if (webView != null && webView.canGoBack()) { webView.goBack(); return; }
        long now = System.currentTimeMillis();
        if (now - lastBackPress < 1800) super.onBackPressed();
        else { lastBackPress = now; Toast.makeText(this, "한 번 더 누르면 종료", Toast.LENGTH_SHORT).show(); }
    }

    @Override protected void onDestroy() {
        closePopup();
        if (state != null) state.close();
        if (webView != null) { webView.removeJavascriptInterface("AkagiCapture"); webView.destroy(); }
        super.onDestroy();
    }

    private final class CaptureBridge {
        @JavascriptInterface public void onHookReady(String page) {
            hookReady.set(true); runOnUiThread(() -> status.setText("WebSocket hook 활성화 · 대국 접속 대기"));
        }
        @JavascriptInterface public void onFrame(String direction, String url, String kind, String payload) {
            if (!"binary".equals(kind) || payload == null || state == null) return;
            try {
                state.onBinary("out".equals(direction), Base64.decode(payload, Base64.DEFAULT));
            } catch (Throwable e) {
                // A protocol/version mismatch must never terminate the Activity.
                android.util.Log.e("AkagiAndroid", "frame processing failed", e);
                runOnUiThread(() -> {
                    if (status != null) status.setText("패킷 분석 오류 · 다음 프레임 계속 처리");
                });
            }
        }
    }
}
