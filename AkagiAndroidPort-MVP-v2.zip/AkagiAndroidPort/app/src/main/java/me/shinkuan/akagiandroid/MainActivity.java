package me.shinkuan.akagiandroid;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Message;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.concurrent.atomic.AtomicBoolean;

public final class MainActivity extends Activity {
    private static final String DEFAULT_URL = "https://mahjongsoul.game.yo-star.com/";

    private FrameLayout root;
    private WebView webView;
    private WebView popupWebView;
    private FrameLayout popupLayer;
    private TextView status;
    private TextView advice;
    private TextView detail;
    private LinearLayout overlay;
    private Button returnGame;
    private LinearLayout handGuide;
    private LinearLayout handGuideRow;
    private TextView handGuideTitle;
    private static final Pattern TILE_TOKEN = Pattern.compile("(?<![A-Za-z0-9])([0-9][mpsz])(?![A-Za-z0-9])");
    private String hookScript;
    private String lastGameUrl = DEFAULT_URL;
    private long lastBackPress;
    private final AtomicBoolean hookReady = new AtomicBoolean(false);
    private MajsoulState state;
    private MajsoulState.Snapshot lastSnapshot;
    private long lastHistoryVersion = -1;
    private boolean handGuideEnabled = true;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        AkagiNativeModel model3 = loadNativeModel("native/akagi3p.safetensors");
        AkagiNativeModel model4 = loadNativeModel("native/akagi4p.safetensors");
        state = new MajsoulState(s -> runOnUiThread(() -> render(s)), model3, model4);
        hookScript = readAsset("ws_hook.js");

        root = new FrameLayout(this);
        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        buildOverlay(root);
        buildHandGuide(root);
        setContentView(root);

        configureMainWebView();
        String url = getPreferences(MODE_PRIVATE).getString("game_url", DEFAULT_URL);
        lastGameUrl = url;
        webView.loadUrl(url);
    }

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    private void configureMainWebView() {
        configureCommon(webView, true);
        webView.addJavascriptInterface(new CaptureBridge(), "AkagiCapture");
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(webView, hookScript, Collections.singleton("*"));
        }
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                openPopup(resultMsg);
                return true;
            }
            @Override public void onCloseWindow(WebView window) { closePopup(); }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                if (isGameUrl(url)) lastGameUrl = url;
                hookReady.set(false);
                view.evaluateJavascript(hookScript, null);
            }
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (!hookReady.get()) view.evaluateJavascript(hookScript, null);
                detectVerificationPage(view, false);
            }
        });
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureCommon(WebView v, boolean multiWindow) {
        WebSettings ws = v.getSettings();
        ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true); ws.setDatabaseEnabled(true);
        ws.setMediaPlaybackRequiresUserGesture(false); ws.setAllowFileAccess(false); ws.setAllowContentAccess(false);
        ws.setSupportZoom(false); ws.setUseWideViewPort(true); ws.setLoadWithOverviewMode(true);
        ws.setJavaScriptCanOpenWindowsAutomatically(true); ws.setSupportMultipleWindows(multiWindow);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(v, true);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void openPopup(Message resultMsg) {
        closePopup();
        popupLayer = new FrameLayout(this);
        popupLayer.setBackgroundColor(Color.WHITE);
        popupWebView = new WebView(this);
        configureCommon(popupWebView, false);
        popupWebView.setWebChromeClient(new WebChromeClient() {
            @Override public void onCloseWindow(WebView window) { closePopup(); }
        });
        popupWebView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                detectVerificationPage(view, true);
            }
        });
        popupLayer.addView(popupWebView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        Button close = button("인증창 닫기 / 게임으로 돌아가기");
        close.setTextSize(12);
        close.setOnClickListener(v -> closePopup());
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(dp(260), dp(48));
        bp.gravity = Gravity.TOP | Gravity.END; bp.topMargin = dp(8); bp.rightMargin = dp(8);
        popupLayer.addView(close, bp);

        root.addView(popupLayer, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
        transport.setWebView(popupWebView); resultMsg.sendToTarget();
        status.setText("인증창 열림 · 인증 완료 후 우측 상단 버튼으로 복귀");
    }

    private void detectVerificationPage(WebView v, boolean popup) {
        String js = "(function(){var t=(document.body&&document.body.innerText)||'';return /Verification Completed|verification result|인증 완료/i.test(t);})()";
        v.evaluateJavascript(js, value -> {
            if (!"true".equals(value)) return;
            runOnUiThread(() -> {
                CookieManager.getInstance().flush();
                advice.setText("인증 완료 · 게임으로 복귀하세요");
                status.setText("인증 성공 감지");
                if (!popup) returnGame.setVisibility(View.VISIBLE);
                else Toast.makeText(this, "인증 완료. 우측 상단 '게임으로 돌아가기'를 누르세요.", Toast.LENGTH_LONG).show();
            });
        });
    }

    private void closePopup() {
        if (popupWebView != null) {
            popupWebView.stopLoading(); popupWebView.destroy(); popupWebView = null;
        }
        if (popupLayer != null) { root.removeView(popupLayer); popupLayer = null; }
        CookieManager.getInstance().flush();
        if (webView != null) {
            webView.requestFocus();
            webView.evaluateJavascript("try{window.focus()}catch(e){}", null);
        }
        status.setText("인증창 닫힘 · 게임 응답 대기");
    }

    private boolean isGameUrl(String u) {
        if (u == null) return false;
        return u.contains("mahjongsoul.game.yo-star.com") || u.contains("game.maj-soul.com");
    }

    private void buildOverlay(FrameLayout root) {
        overlay = new LinearLayout(this); overlay.setOrientation(LinearLayout.VERTICAL);
        overlay.setPadding(dp(10), dp(8), dp(10), dp(8)); overlay.setBackgroundColor(0xD6111111);
        status = label(12, Color.LTGRAY); advice = label(18, Color.WHITE); detail = label(11, 0xFFE0E0E0);
        overlay.addView(status); overlay.addView(advice); overlay.addView(detail);

        LinearLayout buttons = new LinearLayout(this); buttons.setOrientation(LinearLayout.HORIZONTAL);
        Button reload = button("새로고침"); reload.setOnClickListener(v -> { state.reset(); webView.reload(); });
        Button url = button("주소"); url.setOnClickListener(v -> editUrl());
        Button hide = button("접기"); hide.setOnClickListener(v -> {
            boolean compact = detail.getVisibility() == View.GONE;
            detail.setVisibility(compact ? View.VISIBLE : View.GONE); status.setVisibility(compact ? View.VISIBLE : View.GONE);
            hide.setText(compact ? "접기" : "펼치기");
        });
        returnGame = button("게임복귀"); returnGame.setVisibility(View.GONE);
        returnGame.setOnClickListener(v -> {
            returnGame.setVisibility(View.GONE); CookieManager.getInstance().flush(); webView.loadUrl(lastGameUrl == null ? DEFAULT_URL : lastGameUrl);
        });
        buttons.addView(reload); buttons.addView(url); buttons.addView(hide); buttons.addView(returnGame); overlay.addView(buttons);

        LinearLayout tools = new LinearLayout(this); tools.setOrientation(LinearLayout.HORIZONTAL);
        Button history = button("기록"); history.setOnClickListener(v -> showHistory());
        Button inspector = button("인스펙터"); inspector.setOnClickListener(v -> showInspector());
        Button guide = button("패숨김"); guide.setOnClickListener(v -> {
            handGuideEnabled = !handGuideEnabled;
            handGuide.setVisibility(handGuideEnabled && lastSnapshot != null && !lastSnapshot.hand.isEmpty() ? View.VISIBLE : View.GONE);
            guide.setText(handGuideEnabled ? "패숨김" : "패표시");
        });
        tools.addView(history); tools.addView(inspector); tools.addView(guide); overlay.addView(tools);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(470), ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.TOP | Gravity.START; lp.leftMargin = dp(8); lp.topMargin = dp(8); root.addView(overlay, lp);
        advice.setText("Akagi Android+: 연결 대기"); status.setText("WebSocket hook 준비 중");
        detail.setText("로그인 후 대국에 들어가세요. 인증창은 별도 창으로 유지됩니다.");
    }


    private void buildHandGuide(FrameLayout root) {
        handGuide = new LinearLayout(this);
        handGuide.setOrientation(LinearLayout.VERTICAL);
        handGuide.setPadding(dp(8), dp(6), dp(8), dp(8));
        handGuide.setBackgroundColor(0xC0111111);

        handGuideTitle = label(12, Color.WHITE);
        handGuideTitle.setText("내 패 위 추천 표시");
        handGuide.addView(handGuideTitle);

        HorizontalScrollView scroller = new HorizontalScrollView(this);
        scroller.setHorizontalScrollBarEnabled(false);
        handGuideRow = new LinearLayout(this);
        handGuideRow.setOrientation(LinearLayout.HORIZONTAL);
        scroller.addView(handGuideRow, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        handGuide.addView(scroller);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        lp.bottomMargin = dp(70);
        root.addView(handGuide, lp);
        handGuide.setVisibility(View.GONE);
    }

    private TextView label(int sp, int color) {
        TextView t = new TextView(this); t.setTextSize(sp); t.setTextColor(color); t.setPadding(0, dp(2), 0, dp(2)); return t;
    }
    private Button button(String text) {
        Button b = new Button(this); b.setText(text); b.setTextSize(10); b.setAllCaps(false); b.setMinHeight(0); b.setMinimumHeight(0); return b;
    }

    private void editUrl() {
        final android.widget.EditText e = new android.widget.EditText(this); e.setSingleLine(true);
        e.setText(webView.getUrl() == null ? DEFAULT_URL : webView.getUrl());
        new AlertDialog.Builder(this).setTitle("작혼 웹 주소").setView(e)
                .setPositiveButton("열기", (d, w) -> {
                    String u = e.getText().toString().trim(); if (!u.startsWith("https://")) u = "https://" + u;
                    getPreferences(MODE_PRIVATE).edit().putString("game_url", u).apply(); lastGameUrl = u; state.reset(); webView.loadUrl(u);
                }).setNegativeButton("취소", null).show();
    }

    private void render(MajsoulState.Snapshot s) {
        lastSnapshot = s;
        if (s.historyVersion > lastHistoryVersion && s.historyLine != null && !s.historyLine.isEmpty()) {
            if (lastHistoryVersion >= 0) appendHistory(s.historyLine);
            lastHistoryVersion = s.historyVersion;
        } else if (lastHistoryVersion < 0) lastHistoryVersion = s.historyVersion;

        status.setText("프레임 " + s.frames + " · " + s.playerCount + "인 · 좌석 " + (s.selfSeat < 0 ? "?" : s.selfSeat)
                + " · 남은패 " + (s.leftTiles < 0 ? "?" : s.leftTiles) + " · " + s.note);

        if (s.analysis != null) {
            String sh = s.analysis.shanten < 0 ? "화료" : s.analysis.shanten + "샹텐";
            if (s.finalDiscard != null) {
                String ag = s.agari != null && s.agari.average > 0 ? " · 화료율 " + Math.round(s.agari.average) + "%" : "";
                String action = "";
                if (s.aiAction != null && !s.aiAction.top.isEmpty()) {
                    AkagiNativeModel.ActionCandidate top = s.aiAction.top.get(0);
                    if (!top.label.startsWith("타패 ")) action = "행동 추천: " + humanizeTileCodes(top.label) + " " + Math.round(top.probability * 100) + "%\n";
                }
                advice.setText(action + s.finalSource + " 타패: " + tileLabel(s.finalDiscard) + " · " + sh + " · 유효 " + s.analysis.ukeire + ag);
            } else if (s.aiAction != null && !s.aiAction.top.isEmpty()) {
                AkagiNativeModel.ActionCandidate top = s.aiAction.top.get(0);
                advice.setText("행동 추천: " + humanizeTileCodes(top.label) + " " + Math.round(top.probability * 100) + "% · " + sh);
            } else advice.setText(sh);
        } else advice.setText("대국 데이터 대기 중");

        StringBuilder d = new StringBuilder();
        d.append("손패: ").append(joinTiles(s.hand)).append('\n');
        d.append("도라표시: ").append(joinTiles(s.doras)).append('\n');
        if (s.ai != null && !s.ai.top.isEmpty()) {
            d.append("원본AI TOP3: ");
            for (int i = 0; i < s.ai.top.size(); i++) {
                if (i > 0) d.append(" · ");
                AkagiNativeModel.Candidate c = s.ai.top.get(i);
                d.append(tileLabel(c.tile)).append(' ').append(Math.round(c.probability * 100)).append('%');
            }
            d.append(" (").append(s.ai.inferenceMs).append("ms)\n");
        }
        if (s.aiAction != null && !s.aiAction.top.isEmpty()) {
            d.append("행동AI: ");
            for (int i = 0; i < s.aiAction.top.size(); i++) {
                if (i > 0) d.append(" · ");
                AkagiNativeModel.ActionCandidate c = s.aiAction.top.get(i);
                d.append(humanizeTileCodes(c.label)).append(' ').append(Math.round(c.probability * 100)).append('%');
            }
            d.append("\n");
        }
        if (s.analysis != null && !s.analysis.waits.isEmpty()) d.append("대기패: ").append(joinTiles(s.analysis.waits)).append('\n');
        if (s.agari != null && !s.agari.perWait.isEmpty()) d.append("화료율: ").append(humanizeTileCodes(String.join(" · ", s.agari.perWait))).append(s.agari.furiten ? " · 후리텐" : "").append('\n');
        if (s.analysis != null && !s.analysis.improvers.isEmpty()) d.append("개선패: ").append(joinTiles(s.analysis.improvers)).append('\n');
        if (s.pick != null && !s.pick.top.isEmpty()) d.append("공수 TOP3: ").append(humanizeTileCodes(String.join(" · ", s.pick.top))).append('\n');
        if (!s.opponents.isEmpty()) d.append("상대: ").append(s.opponents).append('\n');
        d.append("기록: ").append(s.stats).append('\n');
        d.append("마지막: ").append(s.lastAction).append(" / ").append(s.lastMethod);
        detail.setText(d.toString());

        renderHandGuide(s.hand, s.finalDiscard, s.finalSource);
    }

    private void renderHandGuide(List<String> hand, String recommendedDiscard, String mode) {
        if (handGuide == null || handGuideRow == null) return;
        handGuideRow.removeAllViews();
        if (!handGuideEnabled || hand == null || hand.isEmpty()) { handGuide.setVisibility(View.GONE); return; }
        handGuide.setVisibility(View.VISIBLE);
        handGuideTitle.setText(recommendedDiscard == null ? "내 패" : (mode + " 추천 · 버릴 패: " + tileLabel(recommendedDiscard)));

        int markedIndex = -1;
        if (recommendedDiscard != null) {
            for (int i = 0; i < hand.size(); i++) {
                if (recommendedDiscard.equals(hand.get(i))) { markedIndex = i; break; }
            }
        }

        for (int i = 0; i < hand.size(); i++) {
            boolean marked = i == markedIndex;
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER_HORIZONTAL);
            LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            ilp.rightMargin = dp(4);
            item.setLayoutParams(ilp);

            TextView tag = new TextView(this);
            tag.setText(marked ? "▲ 버림" : " ");
            tag.setTextSize(10);
            tag.setTextColor(marked ? 0xFFFFE066 : 0x00FFFFFF);
            tag.setGravity(Gravity.CENTER);
            item.addView(tag);

            TextView tile = new TextView(this);
            tile.setText(tileLabel(hand.get(i)));
            tile.setTextSize(13);
            tile.setTextColor(Color.BLACK);
            tile.setPadding(dp(8), dp(10), dp(8), dp(10));
            tile.setGravity(Gravity.CENTER);
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(Color.WHITE);
            bg.setCornerRadius(dp(6));
            if (marked) {
                bg.setStroke(dp(2), 0xFFFFC107);
            } else {
                bg.setStroke(dp(1), 0xFFBBBBBB);
            }
            tile.setBackground(bg);
            item.addView(tile, new LinearLayout.LayoutParams(dp(44), dp(52)));
            handGuideRow.addView(item);
        }
    }

    private String joinTiles(List<String> tiles) {
        if (tiles == null || tiles.isEmpty()) return "-";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < tiles.size(); i++) {
            if (i > 0) sb.append(' ');
            sb.append(tileLabel(tiles.get(i)));
        }
        return sb.toString();
    }

    private String tileLabel(String code) {
        if (code == null || code.isEmpty()) return "?";
        int t = Tile.parse(code);
        if (t < 0) return code;
        if (t < 9) {
            int rank = t + 1;
            return (code.charAt(0) == '0' ? "적5" : String.valueOf(rank)) + "만";
        }
        if (t < 18) {
            int rank = t - 8;
            return (code.charAt(0) == '0' ? "적5" : String.valueOf(rank)) + "통";
        }
        if (t < 27) {
            int rank = t - 17;
            return (code.charAt(0) == '0' ? "적5" : String.valueOf(rank)) + "삭";
        }
        return switch (t) {
            case 27 -> "동";
            case 28 -> "남";
            case 29 -> "서";
            case 30 -> "북";
            case 31 -> "백";
            case 32 -> "발";
            case 33 -> "중";
            default -> code;
        };
    }

    private String humanizeTileCodes(String text) {
        if (text == null || text.isEmpty()) return "";
        Matcher m = TILE_TOKEN.matcher(text);
        StringBuffer out = new StringBuffer();
        while (m.find()) {
            m.appendReplacement(out, Matcher.quoteReplacement(tileLabel(m.group(1))));
        }
        m.appendTail(out);
        return out.toString();
    }

    private AkagiNativeModel loadNativeModel(String asset) {
        try (java.io.InputStream in = getAssets().open(asset)) {
            return AkagiNativeModel.load(in);
        } catch (Exception e) {
            android.util.Log.e("AkagiAndroid", "native model load failed: " + asset, e);
            return null;
        }
    }

    private void appendHistory(String line) {
        android.content.SharedPreferences p = getSharedPreferences("akagi_history", MODE_PRIVATE);
        String old = p.getString("lines", "");
        String now = new java.text.SimpleDateFormat("MM-dd HH:mm", java.util.Locale.KOREA).format(new java.util.Date());
        String merged = (old + now + "  " + line + "\n");
        String[] rows = merged.split("\n");
        if (rows.length > 100) {
            StringBuilder b = new StringBuilder();
            for (int i = rows.length - 100; i < rows.length; i++) if (!rows[i].isEmpty()) b.append(rows[i]).append('\n');
            merged = b.toString();
        }
        p.edit().putString("lines", merged).apply();
    }

    private void showHistory() {
        String lines = getSharedPreferences("akagi_history", MODE_PRIVATE).getString("lines", "기록 없음");
        if (lines == null || lines.trim().isEmpty()) lines = "기록 없음";
        final String text = lines;
        new AlertDialog.Builder(this).setTitle("Akagi 기록").setMessage(text)
                .setPositiveButton("닫기", null)
                .setNegativeButton("기록 지우기", (d,w) -> getSharedPreferences("akagi_history", MODE_PRIVATE).edit().clear().apply()).show();
    }

    private void showInspector() {
        MajsoulState.Snapshot s = lastSnapshot;
        String text = s == null ? "대국 데이터 없음" : s.inspector + "\n손패=" + joinTiles(s.hand) + "\n도라표시=" + joinTiles(s.doras);
        new AlertDialog.Builder(this).setTitle("Protocol / State Inspector").setMessage(text).setPositiveButton("닫기", null).show();
    }

    private String readAsset(String name) {
        StringBuilder s = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(getAssets().open(name), StandardCharsets.UTF_8))) {
            String line; while ((line = r.readLine()) != null) s.append(line).append('\n');
        } catch (Exception e) { throw new RuntimeException(e); }
        return s.toString();
    }
    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }

    @Override public void onBackPressed() {
        if (popupWebView != null) { closePopup(); return; }
        if (webView != null && webView.canGoBack()) { webView.goBack(); return; }
        long now = System.currentTimeMillis();
        if (now - lastBackPress < 1800) super.onBackPressed();
        else { lastBackPress = now; Toast.makeText(this, "한 번 더 누르면 종료", Toast.LENGTH_SHORT).show(); }
    }

    @Override protected void onDestroy() {
        closePopup();
        if (webView != null) { webView.removeJavascriptInterface("AkagiCapture"); webView.destroy(); }
        super.onDestroy();
    }

    private final class CaptureBridge {
        @JavascriptInterface public void onHookReady(String page) {
            hookReady.set(true); runOnUiThread(() -> status.setText("WebSocket hook 활성화 · 대국 접속 대기"));
        }
        @JavascriptInterface public void onFrame(String direction, String url, String kind, String payload) {
            if (!"binary".equals(kind) || payload == null) return;
            try { state.onBinary("out".equals(direction), Base64.decode(payload, Base64.DEFAULT)); }
            catch (IllegalArgumentException ignored) {}
        }
    }
}
