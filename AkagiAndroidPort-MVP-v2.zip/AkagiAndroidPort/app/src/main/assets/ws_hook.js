(() => {
  if (window.__AKAGI_ANDROID_WS_HOOK__) return;

  const NativeWebSocket = window.WebSocket;
  if (!NativeWebSocket || !window.AkagiCapture) return;
  window.__AKAGI_ANDROID_WS_HOOK__ = true;

  function bytesToBase64(bytes) {
    let out = '';
    const CHUNK = 0x8000;
    for (let i = 0; i < bytes.length; i += CHUNK) {
      out += String.fromCharCode.apply(null, bytes.subarray(i, Math.min(i + CHUNK, bytes.length)));
    }
    return btoa(out);
  }

  function emit(direction, url, data) {
    try {
      if (typeof data === 'string') {
        window.AkagiCapture.onFrame(direction, String(url || ''), 'text', data);
        return;
      }
      if (data instanceof ArrayBuffer) {
        window.AkagiCapture.onFrame(direction, String(url || ''), 'binary', bytesToBase64(new Uint8Array(data)));
        return;
      }
      if (ArrayBuffer.isView(data)) {
        const view = new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
        window.AkagiCapture.onFrame(direction, String(url || ''), 'binary', bytesToBase64(view));
        return;
      }
      if (data instanceof Blob) {
        data.arrayBuffer().then(ab => {
          try {
            window.AkagiCapture.onFrame(direction, String(url || ''), 'binary', bytesToBase64(new Uint8Array(ab)));
          } catch (_) {}
        }).catch(() => {});
      }
    } catch (_) {}
  }

  function WrappedWebSocket(url, protocols) {
    const ws = (arguments.length > 1)
      ? new NativeWebSocket(url, protocols)
      : new NativeWebSocket(url);

    const nativeSend = ws.send;
    ws.send = function(data) {
      emit('out', url, data);
      return nativeSend.apply(this, arguments);
    };

    ws.addEventListener('message', function(ev) {
      emit('in', url, ev.data);
    }, true);

    return ws;
  }

  WrappedWebSocket.prototype = NativeWebSocket.prototype;
  try { Object.setPrototypeOf(WrappedWebSocket, NativeWebSocket); } catch (_) {}
  for (const key of ['CONNECTING', 'OPEN', 'CLOSING', 'CLOSED']) {
    try { Object.defineProperty(WrappedWebSocket, key, { value: NativeWebSocket[key] }); } catch (_) {}
  }

  window.WebSocket = WrappedWebSocket;
  try { window.AkagiCapture.onHookReady(location.href); } catch (_) {}
})();
