# Akagi 3.7.2 native Rust core → Android 연결 계획

## 목표 구조

```
Android WebView
  └─ document-start WebSocket hook
       └─ binary frame
            └─ JNI push_frame(direction, bytes)
                 └─ Akagi bridge::majsoul
                      └─ MjaiBus
                           ├─ game_state::tracker -> analysis
                           └─ native_bot -> BotResponse
                                └─ JNI callback / overlay
```

## Cargo 분리 원칙

Android target에서는 데스크톱 캡처 계층을 컴파일하지 않습니다.

```rust
#[cfg(not(target_os = "android"))]
pub mod proxy;
#[cfg(not(target_os = "android"))]
pub mod capture;
#[cfg(not(target_os = "android"))]
pub mod autoplay;

#[cfg(target_os = "android")]
pub mod mobile_capture;
```

`Cargo.toml`에서는 `hudsucker`, `chromiumoxide`, `opener`, `self-replace` 등을 desktop target dependency로 이동하고 Android용 JNI dependency를 추가합니다.

```toml
[target.'cfg(not(target_os = "android"))'.dependencies]
hudsucker = { version = "0.24", ... }
chromiumoxide = "0.9.1"
opener = { version = "0.8.5", default-features = false }
self-replace = "1"

[target.'cfg(target_os = "android")'.dependencies]
jni = "0.21"
android_logger = "0.15"
```

## JNI API 권장 형태

```rust
#[no_mangle]
pub extern "system" fn Java_me_shinkuan_akagiandroid_NativeCore_pushFrame(
    mut env: JNIEnv,
    _class: JClass,
    outbound: jboolean,
    data: JByteArray,
) {
    let bytes = env.convert_byte_array(data).unwrap_or_default();
    MOBILE_FRAME_TX.send(Frame { outbound: outbound != 0, bytes });
}
```

Android 앱은 `MajsoulState.onBinary()` 대신 `NativeCore.pushFrame(...)`을 호출하고, Rust가 분석 결과를 JSON으로 callback 하면 오버레이에 표시합니다.

## 1차 컴파일 차단 예상 지점

- Tauri desktop-only window APIs
- `tokio::process` 기반 외부 mjai bot runtime
- updater/self-replace
- filesystem root가 executable-adjacent라고 가정한 설정/로그 경로
- `chromiumoxide` patch dependency

이들은 Android cfg에서 제외하고 app-private files dir를 config root로 사용합니다.
